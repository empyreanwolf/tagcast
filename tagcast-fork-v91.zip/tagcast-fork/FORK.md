# This fork: Artist cleanup

Based on Tagcast 0.85.1 (cyberdeliaAI/tagcast, MIT). Adds **Artist cleanup**:
merge duplicate artist entries, split combined names such as `Coldplay/BTS`, and
link guests named in titles such as `(feat. X)`. See `docs/artist-cleanup.md`.

## Downloads (from v9)

**Downloads** in the sidebar. **Check** compares songs/albums (`Artist - Title`, albums
may end with `| 12` for the track count) with your iBroadcast library and download
history. Anything you may already have waits in **Needs your decision**; it is never
downloaded automatically. **Folder & imports** sets the download folder (default: your
Music folder) and imports the Galaxy `history.json` (use **Find it**, or paste the path:
it sits next to the Galaxy app's `app.py`) and the Telegram history from
`%APPDATA%\TelegramAutoDownloader\`. Importing again adds only new songs. Nothing is
uploaded to iBroadcast.

## Run it on Windows

1. Install Python 3.11 or newer from python.org (tick "Add python.exe to PATH"), or uv.
2. Extract this folder anywhere, for example `Documents\tagcast-fork`.
3. Double-click **`start-tagcast-fork.bat`**. The first start installs Tagcast into
   a `.venv` folder next to it; later starts are quick. Your browser opens
   `http://127.0.0.1:8913`.
4. Sign in to iBroadcast as usual. The fork uses the same settings folder
   (`%USERPROFILE%\.tagcast`) as the official app, so an existing sign-in is reused.

The fork runs on port 8913 so it never reuses an official Tagcast already running
on 8912. Close the black window to stop it.

## Suggested order

1. Turn off **Combine Multi-Disc Album Sets** in iBroadcast.
2. **Search & merge** one tiny test first (for example `Lotus ` → `Lotus`), then check in
   the iBroadcast app that the old entry disappeared.
3. **Duplicates** → **Combined names** → **Featured in titles** → **Duplicates** again.
4. Export each report before preparing the next preview if you want to keep it.

## Using it from your phone, anywhere (v25)

Tagcast only answers `http://127.0.0.1` by default -- on purpose, since it holds your
iBroadcast sign-in and any API keys you've added, and can start downloads. To reach it from
your phone from anywhere (not just your home WiFi), without opening it up to anyone else:

1. Install [Tailscale](https://tailscale.com) on this PC and on your phone, and sign in to
   the same Tailscale account on both (free for personal use).
2. On this PC, run `tailscale serve --https=443 127.0.0.1:8913` (use 8913, this fork's
   port). Run `tailscale status` to see this PC's Tailscale name, something like
   `your-pc.tailxxxxx.ts.net`.
3. Set a Windows environment variable `TAGCAST_EXTRA_HOSTS` to that name (System Properties
   → Environment Variables, or `setx TAGCAST_EXTRA_HOSTS your-pc.tailxxxxx.ts.net` in a new
   Command Prompt), then restart Tagcast so it picks it up.
4. On your phone, with the Tailscale app running, open `https://your-pc.tailxxxxx.ts.net` in
   the browser. "Add to Home Screen" there makes it feel like its own app.

If step 4 gives a 403, the error message on the page names the exact Host it saw and didn't
recognize -- add that one to `TAGCAST_EXTRA_HOSTS` instead (`tailscale serve`'s exact
forwarding behavior wasn't something I could test from here). Downloads you start from your
phone still run, and land in your Music folder, on this PC -- your phone is only the remote
control.

## Versions

The fork version is shown beside the **Artist cleanup** title and in its error messages.
A short alert sound plays when a run stops with an error or an action fails.

- **v59** **YouTube source (yt-dlp), tried first.**
  - New **YouTube** tab in Downloads (one `Artist - Title` per line) and a switch in Settings (on by default). Tagcast uses the open-source
    yt-dlp library (installed automatically at the next start), picks the official audio (the "Artist - Topic" upload first; live, remix,
    cover, instrumental and other versions are skipped unless you asked for them) and saves the AAC (m4a) stream without re-encoding.
  - Order for every download is now **YouTube, Galaxy, Bandcamp, Soulseek**. Albums use YouTube's album playlist when it clearly matches.
    Charts rows that already carry a NetEase track id still go straight to Galaxy.
  - Files are lossy (about 128 kbps), have no cover, and say "from YouTube, lossy" on the item. They are tagged and tidied like other downloads.
  - Not tested against live YouTube (the build sandbox has no internet). If YouTube changes, update yt-dlp: `pip install -U yt-dlp`.
- **v60** **More sources tab + SoundCloud chart.** New Downloads tab "More sources": one search bar over SoundCloud (yt-dlp), one-click download, plus a box for SoundCloud/Audiomack links (song, album or set). SoundCloud "Top Hip-hop & Rap" added to the Charts page. Audiomack/mixtape search and charts are not built (no stable public API). Lossy files.
- **v61** **YouTube upgrade.** YouTube tab: search an artist, see Albums and Singles (1-3 songs) with tracks, all foldable; one-click Download per release, Download all albums/singles (skips what you have). YouTube Music first, switch to plain YouTube (channel Releases tab), auto-fallback. Shared link box (YouTube tab + More sources) takes YouTube links and playlists; a playlist = one album (album = playlist name, tracks in order, Various Artists if mixed). All yt-dlp downloads now MP3 (ffmpeg via imageio-ffmpeg) with square cover art and page tags (track, artist, album, year, genre). Not tested live.
- **v62** **Split albums.** Albums filter "Split albums": one album split into many because its tracks got different album artists (same title + disc, 3+ album artists, mostly 1-3 track parts). Each row: parts list (fold), album artist choice (main artist if 60%+ of tracks, else Various Artists), one-click Merge; Merge all skips rows marked Check (generic titles or no shared cover/year/upload date). Merge = one save setting the same album artist, clearing extra album artists and setting one year; iBroadcast then joins the parts. Track artists unchanged. Backend: /api/save split_merge allows album-artist-only changes across artists.
- **v63** **YouTube links fixed + where each download came from.** A YouTube link with a list (watch?v=…&list=… or playlist?list=…) waits for a click: ⬇ This song or ⬇ Whole album/playlist/Mix (N songs). OLAK5uy_ = official album (album name, album artist, track order); Mix (RD…) = separate singles. Links now follow redirects (yt-dlp extract_flat in_playlist), so album links list every song; an unreadable link is reported, not downloaded. Queue/history show the real site (YouTube/SoundCloud/Audiomack) and `query: …` or `from: <link>` with a copy button; ✕ All from link removes every waiting song from one paste. En/em dashes split Artist – Title. Automatic album lookups try YouTube Music's album search first (finds Artist - Topic albums), plain YouTube second; when nothing is found the note lists each source's query and reason.
- **v64** **Discovery.** New Downloads tab **Labels**: type a label name (MusicBrainz catalogue, albums/EPs, singles optional, "Not this label?" alternatives) or paste a label's Bandcamp link; missing releases marked, ⬇ per release and ⬇ Download all missing (Bandcamp rows straight from Bandcamp, others through the Discography chain). Charts: **Bandcamp best-sellers** (hip-hop/rap albums, whole release queued from Bandcamp; undocumented discover endpoint with fallback). From a page: **Best-of lists** quick links (Rolling Stone and Complex 2025 preset, ☆ Save this link, ✕ remove; kept in this browser). Recommended: **Only artists I don't have** (default on) and **⬇ Discography** per artist (/api/discography/get-all). Daily Digest new releases: ⬇ Download per release and ⬇ Download all new. Audiomack charts not built (needs an account key).
- **v65** **YouTube artist search that doesn't give up + Galaxy fallback.** Artist albums & singles: each step may fail on its own (YouTube Music → channel Releases tab → channel Playlists tab → playlist search); results without an artist name are kept when most tracks are by the artist (Topic). "Artist - Title" typed in the artist box is searched as a song. yt-dlp errors without colour codes. A Galaxy "No download link" song now tries YouTube → Bandcamp → Soulseek by itself (the failed row goes once queued elsewhere, else wishlist); failed rows get ⬇ Try YouTube. On the search tabs the search and results come first, the queue after.
- **v66** **Spotify links (spotDL), album pick list, editions, fork updates.** Galaxy Album search lists every matching album (grouped by cover; Open or ⬇ Download each) and flags a **Different artist** when the query names one ("Album - Artist" or "Album Artist"). Owned check ignores edition words (Bonus/Deluxe/Remastered/Expanded/Explicit…): another edition counts as Have it · other edition. Update button checks this fork (fork vN in artist-cleanup.js on empyreanwolf/tagcast main), never the original Tagcast's releases; a newer build offers the main zip. Spotify song/album/playlist/artist links in the shared link box: spotDL (MIT) in its own environment (spotdl-env in the settings folder, one-click install in More sources) reads Spotify's tags and YouTube Music match (`spotdl save --preload`); Tagcast downloads with yt-dlp and writes Spotify's tags and cover. Optional own Spotify app key.
- **v75** **Swap artist/album saves.** Swapping several albums failed with "A save must stay within one album or one album artist"; a save that changes album artist and album name together may now span albums (same rule as Merge split albums).
- **v76** **Sonora look.** A new dark, glassy look copied from the Sonora player: Inter font, big rounded album art that glows on hover, a glass player bar, a coloured glow round the window and in Now playing. Theme menu › **Look**: Sonora (default) or Classic (the old look, with your light/dark choice back). **Accent colour**: Auto (follows the album that is playing) or Cyan, Pink, Violet, Green, Orange, Red, Gold. **Favourites** has **▶ Play** and **🔀 Shuffle play** for every favourite (all pages, and the search if you typed one). The ♫＋ quick-add button is gone from every list (Playlist… stays).
- **v77** **Players that follow the music's age.** Now playing, the bottom bar and the Mini Player show a device drawn for the album's year, with the cover on it and moving while a song plays: phonograph, gramophone, wooden radio, jukebox, transistor radio, reel-to-reel, vinyl, car radio, boombox, Walkman, cassette, MiniDisc, portable CD player, CD, MP3 player, click-wheel player, computer, smartphone, smart speaker, earbuds. No year: a steady random one per album. **Theme ▾ › Player style** forces one or turns it off (plain cover, with the round spinning CD back). **How we listen** in the sidebar is a timeline of all twenty; click one to use it.
- **v74** **Select albums faster.** Albums page: Shift-click a checkbox to select everything from the last one you clicked to it (Shift-click on a ticked one unticks the range); or press on a checkbox and drag over the others to tick or untick them all. Then Move selected albums to trash as before. **⇄ Swap artist/album…** in the selection bar: for albums tagged the wrong way round, builds one change per selected album (album artist ↔ album name), opens the normal Review dialog and saves only when you press Save; track artists unchanged.
- **v73** **One-click update, same choices on both PCs, queue notification, debug report.** **⬆ Update now & restart** (the "Update available" button's dialog, and Settings › About & updates): downloads the fork's `main` zip from GitHub, checks it holds a newer fork version, copies its files over the Tagcast folder (never `.venv`, `.git` or `.tagcast`; nothing is deleted; all files are staged first so a failure leaves the old version), then starts the launcher again and the page reloads on the new version. Windows only; first update from v72 or older still needs the zip. **Same choices on both PCs** (Downloads › Settings): with the shared folder set, each PC writes `tagcast-settings-<pc>.json` and merges the others every 5 minutes (and ↻ Sync now): keep-separate artists, wishlist, genre look-ups, your genre list, uploaded files. It only adds; removals can come back. Download history already synced. **Windows notification** when the queue finishes (Downloads › Settings; browser notification, asks permission once). **Debug report** (Settings › About & updates): one zip with versions, the Activity log, tagcast.log, queue titles and reasons and scrubbed settings; no tokens, keys or passwords.
- **v72** **Upload page, YouTube names, copy buttons, spinning disc (fixes 31–35).** New left-menu entry **Upload** (also a Downloads tab): scan a folder (or your default folder) into an Mp3tag-style grid: file name, title, artist, album artist, album, #, disc, year, genre, cover, format, size and **file created date**; sort, search, folder and date filters (Created today / Last 7 days / Since last upload / Pick a date), Shift/Ctrl select, double-click a cell to edit, **Edit selected** with `<keep>`, Tools (auto-number, replace text, letter case, file name → tags, tags → file name, split artists "A; B" with first as album artist, copy cover), pending edits in yellow, Save and ↶ Undo (only the changed fields are written, other tags survive). ⚠ **Possible duplicates** (iBroadcast, this list, uploaded before: same artist incl. spellings, same or close title; Remix/Live stay separate) with side-by-side compare, Skip / Upload anyway / Skip all duplicates; never decided for you and Upload stays off until each is chosen. Artist names iBroadcast already has are offered (→ name). **⬆ Upload selected** sends files to upload.ibroadcast.com (new, written like iBroadcast's own uploader; untested against the real service: a refusal shows in **Failed uploads** with the reason, Retry / Show in folder / Remove / Retry all). Files are never moved or deleted: uploaded files get ✓ with the date and are hidden unless "Show uploaded". Upload settings: default folder and your **genre list** (Underground Hip Hop and Chinese Hip Hop first; add, remove, ▲▼ order), used by the Upload drop-downs and Clean up decisions. YouTube matching: names like PACT派克特 are found by either part in any order, 【album】, track numbers and Feat. are ignored in video titles, slightly different titles are accepted when the video names the artist, each name part is searched on its own, and an album playlist from another channel is accepted when the album's words are in its name and the artist is in its videos. Queued links leave the paste box (failed ones stay). Missing page: Copy Title / Artist / Album / All on each row. Now playing and the bottom player: the cover spins like a CD while playing (Settings › Playback › Spinning disc; off with reduce motion). Music video from Google Drive (fix 36) is on hold.
- **v71** **Chinese discographies from NetEase (fix 30).** For an artist name with Chinese characters, Discography also lists NetEase's albums, EPs and singles (QQ Music when NetEase has nothing), matched across spellings (派克特Pact = 派克特（PACT）); guest appearances go under Compilations. Top songs fall back to NetEase's hot songs. ⬇ Get the missing for Chinese artists tries Galaxy first (also with NetEase's spelling, saved under yours), then YouTube → Bandcamp → Soulseek.
- **v70** **Genres, Queue & history, Keep separate, YouTube fallback (fixes 22–29).** Genre decisions ask Discogs (with a token) → Apple → QQ Music (Chinese names) → MusicBrainz; the first that is sure decides. A source that doesn't answer is retried 3× slowly and shown as "didn't answer" (not "not on MusicBrainz"), with ↻ per artist and ↻ Check all again. Needs your decision groups by Album (default; one click sets a whole album) or Artist, and shows every source's genres. "Queue & history" has its own left-menu entry with a waiting count (also still a Downloads tab; show/hide in Settings › Sidebar). Artist cleanup › Duplicates: "Keep separate · don't suggest again" per card (remembers the unticked names against the ticked ones), "Ignore all shown", Show › Ignored (N) with Undo; saved in ~/.tagcast/artist_separate.json. Galaxy "Preview only" now tries YouTube → Bandcamp → Soulseek automatically. YouTube matching accepts the same words in any order (swapped remix credits); when Try YouTube finds nothing, the reason stays on the row with "⬇ Use this one".
- **v69** **From upstream Tagcast 1.3.0: Now playing lyrics, better Find lyrics, Mini Player.** Now playing › Lyrics (button remembered) shows iBroadcast lyrics, else Unison → LRCLIB online (Settings › Playback › Now playing lyrics; fork default "iBroadcast first"); timed lines follow the music, word-timed lyrics underline word by word, click a line to jump there; optional cover-colour background. Online lyrics are display-only (never saved). Find lyrics uses upstream's improved LRCLIB search (album, edition labels, duration guard, provider back-off); still Find → Use → Review → Save with the same conflict checks and read-back. Mini Player: button in the compact player and in Now playing; opens an always-on-top Picture-in-Picture window (Chrome/Edge), else a popup; it controls the same audio. Replaces fork v26 synced lyrics. Needs pyyaml (installed by the launcher on restart).
- **v68** **spotDL FFmpeg fix.** Spotify links pass Tagcast's own FFmpeg to spotDL (it checked for FFmpeg even when only reading the link: "FFmpeg is not installed"). spotDL errors show as one clean line, no box frame.
- **v67** **Discogs in Discography + fixes.** With a Discogs token (Settings › Sources) Discography also lists the artist's Discogs releases (masters, own releases; aliases marked "Discogs (as …)"; appearances under Compilations, off by default), merged with Deezer/Apple; used by Missing, New releases and ⬇ Discography too. "(feat. X)" no longer splits one release in two. Sidebar shows the fork version. Galaxy/other downloads recreate the shared _incomplete folder before writing (crash "No such file or directory … .part").
- **v58** **Notes built.**
  - Genre page lists each album artist once (artist picture, total albums and songs); a button switches back to every album.
  - Failed downloads have Copy artist / Copy album / Copy title buttons.
  - An artist created in a credit is offered in the artist lists right after saving.
  - Downloads: tab menu and the "needs a genre" banner sit above the download manager; every table and list folds (remembered per section); Finding sources starts folded.
  - Missing and the Daily Digest only follow Underground, English and Chinese Hip Hop by default; tick other genres under Missing > Which artists.
- **v57** **Chinese names default to Chinese Hip Hop.** An artist written in Chinese characters that MusicBrainz cannot place gets "Chinese Hip Hop" automatically (if you have that genre). A clear MusicBrainz answer (e.g. Mandopop) still wins.
- **v56** **Genres Tagcast is unsure about are no longer silent.** Downloaded songs whose genre could not be placed show a count on the Clean up tab and a banner "N downloaded songs need a genre from you" with a Choose genres button.
- **v55** **Fix: other artists' songs queued by mistake.** Singles by different artists that share one title and album name (e.g. "I Don't Care") were treated as one album, so asking for one queued them all. They are now split by artist.
- **v54** **Galaxy depth, download manager on top, per-PC record, sorting.**
  - Galaxy tries album, song title and artist (traditional and simplified, deep results); a 403 firewall page means "blocked, retry later", not "Not found".
  - Every download goes Galaxy, then Bandcamp, then Soulseek.
  - The download manager (Pause, Retry, Clear, Activity log, API line, overall progress, items) is at the top of the Downloads page.
  - Downloads are recorded per PC. Settings > "This PC and the other PC": name this PC and optionally pick a shared folder (OneDrive/Dropbox) on both PCs; rows then read "downloaded at Office, not uploaded yet" in Downloads, Charts, Recommendations and the Daily Digest.
  - Changing an album's year sets every track's year (like genre).
  - Every table header sorts when clicked (A to Z, reverse, original order). Paged tables sort the page shown.
  - Daily Digest sections load one after another, and start quietly 8 seconds after login.
- **v53** **Duplicates, row buttons, heart playlist.**
  - **Duplicated tag** now means the same title twice on one album (per disc of a set). Matching track numbers alone are not tagged.
  - **Track rows** show "＋ Queue", "⏭ Next" and "☰ Playlist…" as buttons: one click each, no menu.
  - **Heart also adds to a playlist**: after a heart (rating 5) is confirmed, the song is also added to a playlist you choose
    (asked once on your first heart; change or turn off in Settings → Playback). Duplicates skipped; un-hearting does not remove it.
    The ♫＋ quick-add target is not changed by this.
  - Not tried in a real browser against the real library.
- **v52** **Results, resume, crossfade, smart playlists.**
  - **Play / Shuffle / Add results**: three buttons above the albums list act on everything the current search, filter and artist show
    (all pages, first 400 albums). Add uses your quick playlist and skips songs already in it.
  - **Resume last queue**: the queue, position and repeat mode are remembered in this browser; after a restart a
    "↺ Resume last queue" button (and a message) brings it back, paused.
  - **Crossfade** (Settings → Playback, Off by default, 2–12 s): the next song fades in while the ending one fades out.
    Not used with gapless, repeat-one or the last song. Best with Pre-load on.
  - **★ Smart playlists**: save a search + filter + sort (+ artist) under a name; opening it re-checks your library, so it
    stays current. Open, ▶ play or 🔀 shuffle from the list. Kept in this browser only; nothing is written to iBroadcast.
  - Not tried in a real browser against the real library. Crossfade is the riskiest: try it with Pre-load on first.
- **v51** **Queue and playlist helpers.**
  - **Reorder the queue**: drag a row in Now Playing onto another, or Alt+↑ / Alt+↓ on a focused row. The playing song keeps playing.
  - **Clear queue has Undo** (15 seconds): puts the whole queue back, paused.
  - **Smart shuffle**: every shuffle keeps songs by the same artist apart where possible.
  - **Add selected albums**: tick albums, then "♫＋ Add to playlist" in the selection bar adds all their tracks in one go.
  - **Duplicates are skipped** when adding to a playlist (and it tells you how many); a playlist over 10,000 songs is not checked.
  - **Recent playlists** are listed first in the playlist chooser.
  - Not tried in a real browser against the real library. Still not built: crossfade, play from a filter, resume queue after restart, playlist from search, smart playlists.
- **v50** **Smoother listening: next 2 songs are pre-loaded.**
  - While a track plays, the next two songs in the queue are downloaded one at a time into memory (never to disk).
    When one becomes current it plays from memory, so Next and track changes start instantly. Seeking works.
  - On by default; switch off in Settings → Playback → "Pre-load next songs". Not used with experimental gapless.
  - If a download fails or the copy cannot play, that track streams normally. No sleep timer (not wanted).
  - Not tried in a real browser against the real library; the other v50 ideas (queue reorder, smart shuffle, etc.) are not built yet.
- **v49** **Readable text and one-click add.**
  - **Text size**: A− / A+ beside the theme button (and Theme menu → Text size: Small, Normal, Large, Extra large).
    Remembered in the browser. No text is below about 12px at Normal.
  - **Clear roles**: album name is bold and larger, artist is green, track title stays dark. Now Playing shows
    labelled Track / Artist / Album lines. Muted greys are darker for contrast.
  - **One-click add**: the ♫＋ button on any track, album card or album page adds straight to your quick playlist.
    The first click asks which playlist (once); Shift-click chooses another; a playlist page has
    "Use for ♫＋ quick add". The write is sent once and is never retried automatically.
  - Not tried in a real browser against the real library.
- **v48** **Faster loading, nothing removed.**
  - **Scripts and styles are cached by the browser** under a tag made from each file's contents, so a reload
    no longer downloads ~1.3 MB again. A new zip changes the tags, so an old copy is never used.
  - **Everything is compressed** (page, scripts, styles and the library list): about 1.3 MB → 0.35 MB on
    first open, and the 60k-song library list shrinks several times. Biggest help over Tailscale on the phone.
  - **The library list is built once per library** instead of on every load (~0.8 s saved per reload on
    5,000 albums), and it is prepared in the background as soon as the library arrives.
  - **The library is requested together with the status check** when this browser was connected last time,
    saving one round trip to iBroadcast on start-up.
  - **Lighter redraws**: artist grouping and the "Uploaded today" filter do less work per click (about a third
    faster on 5,000 albums), off-screen album cards are not laid out until you scroll near them, and covers
    decode in the background.
- **v47** **Picked from upstream Tagcast 1.0 (cyberdeliaAI/tagcast), everything from v46 kept.**
  - **Merge albums… (upstream's reviewed merge)**: tick 2–20 pieces of one disc, choose the album to keep,
    check every track and confirm. Your drag-one-album-onto-another merge stays, and selecting exactly two
    albums on an artist page still offers it as **Quick merge**.
  - **Select all on this page** checkbox above the albums.
  - **Saves are never sent twice**: if iBroadcast's reply is lost or it answers 429/5xx, Tagcast reads the
    library back instead of resending; unconfirmed changes show "Not confirmed". Your instant background
    save (v36) is unchanged.
  - **Album information** finds TheAudioDB text for "Deluxe Edition", "Remastered" and similar titles.
  - Not taken (you chose to skip): album/track year review, upload folder & day browsing, Mini Player.
- **v46** **Tags after every download, genres into your own list, Soulseek live numbers, Bandcamp album search.**
  - **Every download is tagged right after it is saved** (Galaxy, Bandcamp and Soulseek): the artist is
    one field "A; B", the album artist is the first artist, and the genre is placed in one of *your*
    genres from MusicBrainz (country and tags): hip-hop by country (Chinese, Hong Kong, Taiwan,
    Singapore, Malaysian, Japanese, Korean, Australian, UK Rap, African), otherwise **Underground
    Hip Hop**; Instrumental Hip Hop, Electronica, K-Pop, OST, Cantopop, Chinese Song, English Song
    and so on by tag. A song already in exactly one of your genres is never touched again.
  - **Clean up** now covers every genre that is not one of yours ("Hip-Hop", "Electronic",
    "Comedy\\Experimental…", no genre), not just hip-hop. The decision page is **one line per artist**:
    name, song count, MusicBrainz's genres, your matching genres as buttons and an "Other" box.
    No more 300-song lists.
  - **Soulseek**: the running row shows MB done / total, MB/s and the current file, turns yellow
    after 2 minutes without data, red after 10, and after **30 minutes with no data it is cancelled**
    and the next source (or the wishlist) takes over. Numbers Sockseek doesn't report are left out.
  - **Bandcamp**: if the artist page has no match, Bandcamp's own album search is tried; when it
    still fails, the reason is shown in the result and `tagcast.log`.
  - **Galaxy line**: no more false "Galaxy thread stopped unexpectedly" when only Soulseek/Bandcamp
    items were waiting.
  - **Discography**: instrumental albums (incl. "Petestrumentals") are tagged and start unticked.
  - **Finding sources** card at the top of Downloads → Queue & history: every album Tagcast is looking
    for (From a page, Discography, Missing, Charts) shows what it is doing right now ("searching Galaxy…",
    "asking Soulseek…") and the result, then the album moves into the queue below. From a page jumps
    straight there after you click Download.
- **v45** **Downloads → From a page, and Galaxy now comes before Soulseek.**
  - **From a page** (new Downloads tab, next to Check): paste the link of a page with a list of
    albums (a "best of 2024" article, a Reddit thread, a Wikipedia list, a public Spotify
    playlist) and Tagcast lists every artist and album on it with year and cover, checked online
    (MusicBrainz first, then Deezer). Each one says Have / Partly / New against iBroadcast and your
    download history. The sure New ones start ticked; **Download chosen albums** fetches them.
    Lines no source knows are kept as **Not sure**: Edit, then Check again. If a site blocks
    Tagcast, use **Paste the text instead**. Not found anywhere goes on the wishlist.
    Untested live (sandbox has no internet): Reddit, Wikipedia and Spotify readers; they are
    covered by saved-page tests only.
  - **Source order everywhere is now Bandcamp → Galaxy → Soulseek** (Charts, Discography,
    Recommendations, Wishlist, Missing, From a page). Soulseek is only tried when Galaxy has
    nothing, and a failed Soulseek job goes straight to the wishlist.
- **v44** **Charts: Spotify in, Shazam and Billboard out; Ask Gemini gone; Daily Digest cleaned up.**
  - **Charts**: the Shazam (US) and Billboard Hot Rap tabs are removed (their pages no longer
    carry readable chart data), and so is Shazam in Browse. New **Spotify RapCaviar** tab, and
    Browse → **Spotify playlist** takes the link of any public playlist (a hip-hop Top 50, say),
    no login. It is read from Spotify's embed page, which I could not test from here: if a
    playlist says it can't be read, send me a screenshot.
  - **Ask Gemini is removed** (page, menu entry and its Gemini key settings). Recommendations moved
    to the **Charts** page as the **Recommended for you** tab: Deezer's related artists, as before.
    The separate Recommendations page is gone.
  - **Daily Digest**: no Gemini section, recommendations come from the Charts tab, and charts that
    cannot be read right now are named in one line instead of showing red errors.
- **v43** **Clean up no longer asks about tracks already in "Underground Hip Hop" or "Chinese Hip Hop"**
  (it used to, whenever MusicBrainz couldn't place the artist). Scan again to clear the old list.
- **v42** **Recently uploaded opens instantly.** Like iBroadcast's own web app, it now reads the library
  copy Tagcast already holds instead of asking iBroadcast (and possibly re-downloading the library)
  every time. The upload days are indexed once per library copy, in the background as soon as it
  arrives; days, a day's albums and Most recent are then lookups in memory. **Refresh** still asks
  iBroadcast for anything new.
- **v41** **Clean up tags the way Mp3tag does.**
  - Several artists are written into ONE artist field, joined with "; " ("Artist A; Artist B"),
    never as separate values (which Mp3tag shows as "\\\\" and some players as "/" or "//").
    Files with separate values or "/", "//", "\\" are rewritten; a field already like "A; B" is left alone.
  - Genre fixing covers every genre: a track with no genre now shows under **Needs your decision**,
    and you can type any genre (not only ones already in iBroadcast), with yours suggested as you type.
- **v40** **Ask Gemini waits up to 2 minutes** for an answer (was 30 seconds) and says plainly when it times out.
- **v39** **Ask Gemini / Tavily keys: pasted spaces are removed.** A key copied with a space, line break
  or invisible character inside is cleaned instead of refused with "That Gemini API key doesn't look right."
- **v38** **Recently uploaded: check your uploads by day.** Downloads → **Clean up** now has two
  tabs; **Recently uploaded** mirrors iBroadcast's Date Uploaded page.
  - **By day**: one row per upload day, newest first, with a cover mosaic, the date, albums,
    tracks and total length. Click a day for its albums and tracks (genre, artist, album artist,
    album, year).
  - Anything missing or suspicious is flagged: no genre, an odd genre (Unknown, Other…), genres
    joined with ";", no artist / album artist / album name / year / cover. **Problems only**
    shows just those.
  - **Edit album** opens the normal editor and Review dialog; the list refreshes after you save.
  - **Most recent**: the flat newest-first list, like the Most Recent Uploads playlist.
  - Tick **I checked this day** to remember a day is done (kept in Tagcast's settings).
- **v37** **Instrumental versions are left out of "download all".** In Downloads → Galaxy, **Queue all**
  and **Download album** (artist, album and whole-album buttons) skip tracks whose title says
  Instrumental, Karaoke, Off Vocal, Backing Track, 伴奏, 纯音乐 / 純音樂, 无人声 / 無人聲 or 消音.
  They stay in the list with an **Instrumental** tag and a note ("N instrumental left out"); tick
  them and use **Download selected** (or the single ⬇ button) when you do want one.
- **v36** **Everything that waits now runs in the background.** Saving tags, changing a cover or
  artist image, ratings, favourites, trash, playlists and lyrics no longer hold the page:
  - The dialog closes at once and the new values show straight away; the save finishes behind
    the scenes. If iBroadcast refuses it, the old values come back and a "Not saved" box (and
    History) lets you review the same changes again.
  - Saves wait in one queue, in the order you made them, on the server. No more "Another save is
    still running". A **Tasks** pill (bottom right) shows what is running, waiting or failed.
  - If the queue is congested (6+ waiting, or one waited 45 s+) Tagcast tells you, with a rough
    time, and asks you to keep it open (closing the tab warns while tasks are active).
  - **Artist pictures**: saved in batches of 10 with one confirmation per batch (before: one
    full library download per artist). Each line says Saving / Saved / Not showing yet / Failed,
    and a picture appears in Tagcast as soon as iBroadcast confirms it.
- **v35** **Activity log: see what's working and what isn't, under the hood.** Overview →
  **Activity log** (or **Problems only**), and an **Activity log** button in the Downloads queue.
  Everything Tagcast does is recorded, newest first:
  - **The download queue, item by item**: queued (and on which source), held for your
    decision (and where Tagcast thinks you already have it), your Skip / Download anyway,
    started, saved (where, how long it took), failed (why, and at which step), retried,
    removed. Galaxy, Bandcamp, Soulseek and Telegram alike.
  - **Tags and metadata**: every save to iBroadcast with each field's new value, which records
    iBroadcast refused, and the read-back afterwards (what iBroadcast actually has); every file
    or track Tag clean-up wrote, or failed to.
  - **Background runs**: how each Clean up metadata / Artist cleanup / Duplicate cleanup run
    ended (with its items counted by outcome), and every Artist pictures artist (picked a face,
    a photo, a cover, or skipped and why).
  - **Every button that reaches Tagcast**, with what was sent, what came back and how long it
    took; any failure with its message, and for a crash the full technical details to send me.
  - **Warnings and errors from inside Tagcast** that used to sit only in `tagcast.log`, or
    nowhere at all (lookups that failed quietly, cover fetches, MusicBrainz misses).
  - **The page's own errors**: a script error or Tagcast being unreachable is reported too.
  The top of the page shows, for the last 24 hours, each area's OK / error / warning counts and
  its last problem; click one to see only that area. Search, filter by outcome, and it refreshes
  itself every 3 seconds while open (untick **Live** to stop). **Download log file** saves the
  whole log as readable text, the thing to send along when something breaks. It's kept in
  `activity.log` in your settings folder (`%USERPROFILE%\.tagcast`), at most about 6 MB, so it
  never grows without limit. Passwords, tokens and API keys are never written to it. Your
  terminal window stays as quiet as before.
- **v34** **Soulseek: SoulseekQt is no longer accepted as "the Sockseek program".** Tagcast
  runs a separate background downloader called Sockseek; pointing that setting at SoulseekQt
  (the normal Soulseek app) made a SoulseekQt window pop up on every job ("already running"),
  and every job failed with "Sockseek did not start". Tagcast now refuses SoulseekQt there,
  both when you choose it and if it was saved before, and says what to pick instead:
  sockseek.exe from github.com/fiso64/sockseek/releases. The same Soulseek login can only be
  online once, so close SoulseekQt while Tagcast downloads, or give Tagcast its own username.
- **v33** Seven fixes and changes from your feedback list:
  - **The artist page works like iBroadcast's.** An album artist's page now has **Albums**
    and **Tracks** tabs. Tracks lists every song on that artist's albums in one table (title,
    album, year, time), with its own search and sort, **Play all**, **Shuffle**, and click any
    song to play the list from there. The tab you last used is remembered.
  - **Merge two albums by the same artist.** On an artist's page, drag one album cover onto
    another, or select exactly two albums and press **Merge 2 albums** (that one also works on
    a phone; the album with more tracks keeps its title). The merged album takes the other's
    title (and year, if different); iBroadcast then joins them, just like dragging in
    iBroadcast. Track numbers, track tags and covers are left exactly as they are. It goes
    through the usual Review dialog, so nothing is written until you press Save, and the
    read-back now counts the joined album as saved rather than "unverified".
  - **200 per page by default**, everywhere there's a page-size choice (albums, artists,
    browse pages, tracks, favourites, recently played, 1001 Albums, which gained a 200
    option). Sizes saved before this version are reset once so you see 200 straight away; any
    size you pick afterwards is remembered as before. Recently played and 1001 Albums now
    remember their size too.
  - **Release year and Decades load faster.** They wait on an index of your whole library
    that has to be rebuilt every time the library reloads, which happens after every edit
    (including Artist cleanup and Artist pictures runs). It is now built in the background as
    soon as a new library arrives, and a general speed-up in how Tagcast looks up library
    records makes the build itself roughly 20–40% faster (measured on a library the size of yours).
  - **Artist pictures moved into Overview**: it's the **Artist pictures…** button in the
    Metadata health card (next to the "Album artists with an image" meter), with a ← Overview
    button to go back. It no longer has its own sidebar entry.
  - **Artist pictures uses song covers too.** Most of the "No album cover to use yet"
    skips were artists whose albums *do* show a cover in iBroadcast: the album record itself
    has no cover, and iBroadcast shows the first track's artwork. That now counts, and when an
    artist has no usable album cover at all, the cover of any song they're on (featured
    appearances included) is used. Press **Run now** again: everyone skipped before is tried
    again.
  - **Bandcamp: clearer failures.** Both your links failed the same way, and even the artist's
    releases page came back empty ("1 releases" for an artist with 28), so Bandcamp was most
    likely sending Tagcast something other than the real pages, such as a "checking your
    browser" page. Tagcast now sends the standard headers every browser sends, says what it
    actually received instead of only "no album on it" (a "check you're a person" page is named
    as such), writes the start of that page to `tagcast.log`, and no longer keeps such a page
    cached for 10 minutes, so the next try really asks again. If it still fails, the message and
    the log line will show what to fix next.
- **v32** **Galaxy finds songs and albums the GD Studio site shows but Tagcast missed.**
  Two reports: "Empire State Of Mind (feat. Alicia Keys)" by JAŸ-Z came back "Not found
  on Bandcamp, Soulseek or Galaxy" although the site lists it, and an Album search for
  "Heavy Lies the Crown" (While You Were Gone) said no such album although the site shows
  its 5 songs. Fixed in three ways:
  - **"Get it" (Discography, Charts, Recommendations, Wishlist) searches the way you
    would.** It used to make one search, "Artist Title" with the "(feat. …)" left in, on one
    source, and look at only 10 results. It now also tries without "(feat. …)" or brackets,
    and the title alone, with 30 results each, stopping at the first real match. The artist
    still has to match, so a cover by someone else isn't picked.
  - **Accents no longer split an artist.** "JAŸ-Z" and "JAY-Z", "Beyoncé" and "Beyonce" now
    count as the same artist when Galaxy checks who a song is by.
  - **Albums: a song search backs up the album search.** When the API's album search has
    nothing, Tagcast now runs a normal song search (the same one as the site's 歌曲搜索)
    and keeps only songs whose album name matches exactly; loose singles never count.
  - "Get it" and "Get the missing" now try your chosen source first, then netease and joox,
    before giving up. A manual Album search stays on the source you picked, and its
    "not found" note now suggests the other sources to try.
- **v31** **Short songs are no longer thrown away as "previews".** Galaxy used to reject
  every file under 35 seconds as a 30-second preview, so a real 32-second intro or skit
  could never be downloaded (reported: "A WORD 4RM MEL" by Kal Banx, "Preview only (32s)").
  Being short is no longer enough on its own. A short file that otherwise arrived whole is
  now checked against the song's length on MusicBrainz (already looked up for every
  download): if MusicBrainz says the song really is that short, it's saved; if it says the
  song is minutes long, it's still rejected, and the note now says so ("Preview only (30s;
  MusicBrainz says 3:12)"). When MusicBrainz doesn't know the song, the item fails as
  "Maybe a preview" with a **Keep it (short track)** button that downloads it again and keeps
  it. The checks that catch a cut-off file (fewer bytes or seconds than the API announced)
  are unchanged and still apply even after Keep it. Bandcamp already compared against each
  track's own listed length, so it was never affected.
- **v30** Three fixes from a report after v29, plus one small feature:
  - **The duplicate check no longer treats a "Various Artists" (or otherwise
    unrecognised-artist) library track as a wildcard.** A compilation track titled
    "Intro" was making every artist's own "Intro" look like a duplicate -- press
    "Skip" enough times on a whole discography and you'd skip songs you never
    actually had. Only a source with *no artist text at all* (an old Telegram file
    with no "Artist - Title" in its name) still falls back to matching by title alone;
    a *named* artist that just doesn't produce a useful key, like "Various Artists",
    no longer does.
  - **Galaxy no longer substitutes a different artist's album when the one you asked
    for shares its exact title.** Downloading an artist's whole discography could
    silently grab songs from someone else entirely (reported: asking for Moka Only's
    discography pulled in Travis Roig and an unrelated "beaming" release) whenever
    another artist happened to have an album with the exact same name and the search
    turned up no exact artist match -- Galaxy used to fall back to "the biggest
    same-named group" regardless of whose it was. It now skips an album like that
    entirely (consistent with "skip albums with no exact edition match") rather than
    guessing.
  - **Shuffle play, a new 🔀 button next to "Play random album"** on any Genres, Tags,
    Track artists, Composers, Release year or Decades detail page: builds one shuffled
    playlist from every song in every album currently shown (not just one album at a
    time), so you can press it on "Chinese Hip Hop" and get a random mix across your
    whole collection in that genre.
  - If you're running artist splitting and a download in **two separate Tagcast
    windows/processes at once**, pointed at the same settings folder: that's very
    likely adding to the stuck-queue problem from v29, not just the disk-write issue
    already fixed there. Each process keeps its own copy of the download queue in
    memory and saves over the other's file periodically, so changes can get lost or
    conflict. Tagcast doesn't need two windows for this -- Artist cleanup and
    Downloads are both tabs in the same app -- so please run one instance only.
- **v29** Download manager resilience, after a report of the Galaxy queue getting stuck
  ("984 waiting", 0 saved, no way to recover but a restart). The most likely cause: the
  download queue is saved to disk after almost every change, and that save was not
  wrapped in any error handling -- a single disk hiccup (antivirus briefly locking the
  file, a cloud-sync conflict, a full disk, etc.) could silently kill a download worker's
  background thread for good, with nothing ever written to the log, and nothing to
  restart it. Fixed on three levels:
  - Saving the queue to disk can no longer kill a worker thread -- any error there is now
    caught, written to `tagcast.log`, and remembered so the Downloads page can show it.
  - Each download worker's entire loop (not just the download itself) is now wrapped in
    its own error handler, so no error, from any cause, can end that thread silently again
    -- it logs the problem and keeps going.
  - A watchdog, run every time the Downloads page refreshes (about every 1.5 seconds while
    something is in progress), notices a source with waiting work and no running thread,
    puts any item it had half-started back in the queue, and restarts that source's
    worker automatically -- no click needed, in almost all cases.
  - For anything the watchdog can't fix alone, the queue view now says plainly when a
    source "Stopped unexpectedly", points at `tagcast.log`, and shows a **Restart** button
    next to **Pause**/**Resume**.
  - This fix can't un-stick a queue that's already stuck from *before* updating -- restart
    Tagcast once to clear that, and the new log entries will catch anything that happens
    next.
- **v28** Three small usability fixes, none of them a new page:
  - **Sidebar cleanup**: Track artists, Composers and Tags now start hidden (the first
    time Tagcast ever runs in a browser only -- if you've already opened Settings and
    changed the sidebar, your choice stays exactly as it was). Turn any of them back on
    in **Settings → Sidebar**. The remaining single artist shortcut is now just called
    **Artist** rather than "Album artists" (it works exactly as before -- it browses by
    album artist; nothing about what it shows changed, only the name).
  - **Genres, Tags, Composers and Favourites load instantly on a repeat visit**: these
    pages were re-asking iBroadcast every single time you opened them, even seconds
    apart with nothing changed. They now only ask again when something about the
    request changed (a different search, sort, or page) or the library itself was
    reloaded -- otherwise the page you already had is shown straight away.
  - **"Uploaded today"**, a new entry in the Albums filter menu: shows just the albums
    with at least one track iBroadcast recorded as uploaded today (your computer's
    local date), the same place you'd check and tag anything you added today. iBroadcast's
    own web player has a similar daily view; this reuses the per-track upload date
    Tagcast already tracked for the "Date uploaded" sort, so no extra request is needed.
- **v27** **Artist pictures**, a new page on the left: a one-time "Run now" job that
  gives every album artist with no image one, in order -- a face found in one of their
  own album covers wins and reuses that cover directly (no re-upload); failing that, a
  real photo from TheAudioDB (free, no key -- the same source already used for
  biographies, looked up by exact artist name only; it has no way to search by genre, so
  genre isn't used); failing that, just one of their own covers anyway, which still looks
  better than the blank default. Only artists with no image yet are touched -- nothing
  already set is replaced. Face detection is OpenCV's bundled frontal-face Haar cascade
  (no extra download, no extra API key) and is best-effort by design: it can miss a
  stylised, side-profile, small, or busy cover, or occasionally flag something that isn't
  a face, and a miss just falls through to the next source rather than erroring. "Search
  Google" wasn't something a free API can actually automate within Google's terms, so
  this uses TheAudioDB instead. The existing **Change artwork** dialog is completely
  unaffected and can always override anything this run picks, any time.
- **v26** **Live sync lyrics**: in the fullscreen Now playing view, a track whose LRCLIB
  lyrics carry line timestamps now scrolls automatically with the music, highlighting the
  current line, and clicking a line seeks there. LRCLIB's timing is community-submitted and
  can be a little off the actual recording. A track with only plain lyrics (most of them,
  or anything saved in iBroadcast, which has no timing field at all) still shows the same
  plain, non-highlighted scrollable text as before; a track with no lyrics at all shows
  nothing. Nothing changes outside the fullscreen view -- the Lyrics dialog and the Now
  playing panel are unaffected.
- **v24** **Daily Digest**, a new page on the left: one read-first page pulling together
  what the other pages already track. New releases (its own undismissed results). Wishlist,
  just found -- the most recent items it dug up, flagged "New" until you hit "Mark seen"
  (same manual acknowledgement New releases already uses). Chart movement -- which songs on
  each of the six fixed Charts tabs are there now that weren't the last time this page
  looked (Charts itself has no history to diff against, so this keeps its own snapshot per
  chart; the very first look at a chart has nothing to compare yet, so it says so rather
  than listing the whole chart as "new"). The top of each Recommendations list. Every
  section fails on its own -- one chart's site changing, or no Gemini key yet, only takes
  out that section, never the page. Nothing downloads from here; each section links back to
  its own page for that.
- **v23** **Recommendations**, a new page on the left, next to Ask Gemini: two separate
  lists seeded from the artists New releases already tracks (followed artists, plus your
  library's own 3+-album artists if that setting is on). **Deezer (related artists)** is
  deterministic -- no AI -- using Deezer's own related-artist data, tallied across your
  seed artists so someone related to several of them ranks first; each kept artist's
  current top track on Deezer is the song offered. **Gemini** asks your own Ask Gemini key
  and model (Settings are shared) for other artists worth exploring, one song each, as a
  one-off question that isn't added to that page's conversation. The two lists are shown
  separately, never merged -- a deterministic signal and a model's opinion are different
  kinds of evidence. "Get it" works the same as Charts: Bandcamp → Soulseek → Galaxy, one
  song at a time, landing on the wishlist if nothing has it.
- **v22** Charts → **Browse**, alongside the existing fixed hip-hop tabs (which are unchanged):
  pick any country and/or genre, as far as each source actually supports it -- nothing here
  is guessed. Apple Music takes any 2-letter country code (its feed has no reliable genre-id
  list beyond Hip-Hop/Rap, so genre stays fixed). Shazam takes both a country and a genre;
  since no official list of valid combinations exists, an unsupported pairing comes back as a
  plain "not available" error rather than wrong data. Deezer takes any genre it lists (pop,
  k-pop, rock, and so on, same by-name lookup as the existing Deezer tab) but no country --
  Deezer's API has no per-country charts, only an undocumented, per-country playlist id that
  could change without notice, so that wasn't built on.
- **v21** Ask Gemini, a new page on the left: a chat backed by your own free Gemini API
  key (aistudio.google.com/apikey -- not the gemini.google.com consumer chat, which has
  no API). Type an artist, a mood or a question; any songs or other artists Gemini names
  are checked against your library/history and shown as a "Get it" list and clickable
  artist chips, same as Charts. Picks go through Bandcamp → Soulseek → Galaxy and land on
  the wishlist if nothing has them. The conversation is saved and persists across restarts
  until you start a new one. It has no live internet access by default, so it says so
  instead of guessing on "what's current" questions -- tick "Search the web" on a message
  to actually look it up first (a free Tavily key, tavily.com, no card, 1,000 searches/mo;
  only spent when you tick the box).
- **v20** Charts, a new page on the left: Chinese Rap (NetEase's own "中文说唱榜") and five
  mainstream hip-hop/rap charts (HotNewHipHop Top 100, Deezer, Apple Music, Shazam US,
  Billboard Hot Rap Songs), each song checked against your library and download history
  first. NetEase songs carry a real track id and queue straight through Galaxy; the rest
  try Bandcamp → Soulseek → Galaxy one at a time and land on the wishlist if nothing has
  them. There's no "underground hip-hop" chart because nothing online actually publishes
  one as a fetchable list -- the page says so instead of faking it.
- **v19** Downloads → Clean up: the Mp3tag fixes before an upload. A combined artist field is
  split on your own separators (feat., &, comma, / and more, editable) into separate artists
  joined by "; ", with the first one set as album artist. For hip-hop and rap, the genre can be
  collapsed into whichever of your own iBroadcast genres already covers "underground" and
  "chinese" hip-hop -- never a genre you don't already have -- deciding Chinese artists from
  MusicBrainz's artist record. Works on a folder of files before upload (tags rewritten in
  place) or on tracks already in your library (genre only there). An artist MusicBrainz can't
  place with confidence is grouped so you can pick a genre once and apply it to everything by
  that artist, the same "select all, set genre" as Mp3tag.
- **v18** Downloads → Missing → Complete my albums: a scan of your library finds albums that are only
  partly there (gaps in track numbers, or fewer songs than Deezer lists), shows which songs are
  missing, and gets them in bulk (Bandcamp → Galaxy; not found → wishlist).
- **v17** Downloads → Missing → Wishlist: what Bandcamp, Soulseek and Galaxy didn't have (also a
  failed Soulseek job whose Galaxy fallback found nothing) is tried again every 3 days while
  Tagcast is open; found items go to the queue, items you meanwhile have are removed. Add wishes by hand too.
- **v16** Downloads → Missing → New releases: for the artists you follow (and, if on, every album
  artist with 3+ albums in your library) Tagcast checks Deezer and Apple Music every 7 days while it
  is open, or on Check now. New releases you don't fully have are listed for Get the missing; a
  message (and Windows notification) says when there are new ones.
- **v15** Discography tab (also "Discography & top songs" on every album artist page): every album,
  EP, single and compilation from Deezer and Apple Music (MusicBrainz on request, cached 7 days),
  each Have / Partly / Downloaded before / Missing; the top 30 songs with 30-second previews.
  "Get the missing" tries Bandcamp, then Soulseek, then Galaxy (a failed Soulseek job falls back
  to Galaxy); anything you may have still waits in Needs your decision.
- **v14** Soulseek tab: "Artist - Album" or "Artist - Title" per line; Tagcast starts Sockseek
  (github.com/fiso64/sockseek) in the background and follows its jobs in the shared queue. Set the
  Sockseek program, your Soulseek login and how much you share under Downloads → Settings.
- **v13** Bandcamp tab: paste an artist or album link; every release shows Have / Partly /
  Downloaded before / Missing. Download the whole discography, an album or single songs (free
  128 kbps streams, never purchases), tagged with cover. One queue and one Pause for all sources.
- **v12** Galaxy part 2: every download is looked up on MusicBrainz for year, genre, track
  number/total (unless it came from a full album) and MusicBrainz IDs; album cards and the album
  page show the year. Downloads → Settings has the pause between songs, the pause between API
  calls and the API quota. (Lyrics and history extras were left out on request.)
- **v11.2** Galaxy shows album covers, as in the Galaxy app: on every song row, album card, the
  album page and the queue. Tagcast fetches them (NetEase without using the API limit; other
  sources with a low-priority call) and keeps them in `galaxy-covers` in the settings folder.
- **v11.1** The Windows launcher repairs a `.venv` that can no longer load Tagcast (moved folder or
  interrupted update): it reinstalls, and rebuilds `.venv` once if needed.
- **v11** Galaxy (your GD downloader) inside Downloads: Artist / Album / Track search on netease,
  joox, bilibili; artists who share a name get separate cards (MusicBrainz, Deezer, your
  library) with "Which artist?" remembered; exact albums only; one queue with pause, cancel,
  retry, move to top, clear, progress, speed and time left; 45 API calls per 5 minutes with
  backoff; 320 → 128 kbps → other source; preview rejection; tags + cover (needs `mutagen`,
  installed automatically). Duplicates wait in Needs your decision.
- **v10** Artist cleanup runs in the background: close its window and keep browsing, playing
  and using Downloads. A bar at the bottom shows the progress (Open / Stop). When it ends: a
  chime (error sound on failure), a message and a Windows notification. Album edits saved
  during a run wait and are sent when it finishes.
- **v9** Downloads page: duplicate check against iBroadcast and the download history,
  Needs your decision (Skip / Download anyway, in bulk or one by one), queue & history,
  Galaxy and Telegram history import, download folder setting. No sources yet (v10+).
- **v8** Version label and error sound.
- **v7** The approval tick stays ticked when the review list redraws.
- **v6** Additional artists stored in another order count as saved; unconfirmed writes
  name the record, what was expected and what iBroadcast has.
- **v5** Records changed during a run are replanned from their current artists.
- **v4** Albums that iBroadcast joins during a merge are followed, not conflicts.
- **v3** A duplicates card can never lock itself.
- **v2** Faster previews, bracket-aware feat. reading, port 8913 launcher.
- **v1** Artist cleanup: duplicates, combined names, featured artists, search & merge.
- **v78** **Visualizer, rapper, better lyrics.** (1) Butterchurn (Milkdrop) visualizer, loaded from the jsDelivr CDN on first use: Theme menu > Visualizer picks Now playing (replaces the player picture, so it sits beside lyrics too), a full-page Now playing background, or the whole site as a background; Now playing header has Visualizer / Lock / Next look; the Mini Player has its own button (pretend beat, no audio there). Looks change every 30 s unless locked. (2) Computer, smartphone, smart speaker and earbuds players removed; new headphones (2008-12), DJ decks (2013-17), festival stage (2018 on); hip hop albums get an animated rapper. (3) The device no longer overlaps the lyrics, no caption over the title, centred. (4) Lyrics: "Artist - " prefix, Dirty/Clean, "Da/The" slang and traditional/simplified are forgiven, a few seconds of length difference is allowed (8 s), "Search lyrics..." lets you type another title/artist, and GD Studio (netease) is the Chinese fallback after LRCLIB.
- **v79** **Galaxy downloads carry their lyrics.** Each downloaded song asks GD Studio for its timed lyrics, removes the credit lines (作词, 作曲, 录音师 ...), embeds them in the file (MP3 lyrics tag, FLAC LYRICS, M4A lyrics) and saves a `.lrc` file with the same name next to it. A song without lyrics just downloads as before. Songs already downloaded are not touched.
- **v80** **Songs start faster.** "Preparing..." was the experimental Gapless playback, which downloads and decodes the whole song before it plays (5+ s); it is now switched off once for everyone (turn it on again in Settings > Playback if you want it) and normal playback with the next-2 pre-load is back. The server also keeps one connection to iBroadcast per thread instead of a new TLS handshake for every song (about 0.3-0.8 s saved).
- **v85** **Lyrics everywhere while playing.** Timed lyrics no longer need the large Now playing view: (A) the current line (next line dimmed) in the player bar, toggled with the new ♪ button; click the line to jump there; (B) a floating lyrics box (⧉ in the bar line) that you drag anywhere, make bigger or close, and that stays across pages; (C) the current line in the Mini Player (Picture-in-Picture window is a bit taller). Settings → Playback → "Lyrics while playing" switches each one (bar and Mini Player on, box off by default). Same lyrics sources as Now playing; with an online option the current song is looked up while lyrics show anywhere. GitHub tests and builds now run on Windows only.
- **v86** **Lyrics card in page headers + auto-save.** (A) A "LYRICS" card in the empty space right of the cover and title (album, artist, playlist and other page headers), after upstream Tagcast 1.5.5's Now playing card: Follow switch (scrolling the card turns it off), current line big and bold, others dim, click a line to jump there, footer "Lyrics from LRCLIB ↗ · Not stored in iBroadcast" or "Saved in iBroadcast". Hidden below 1100 px wide. Player-bar line, floating box and Mini Player stay. (B) Timed lyrics found online (LRCLIB/Unison) while playing are saved once to the song's iBroadcast Lyrics field, only when it has none (the server checks again and never overwrites); listed in Change history and the Activity log. Both on by default; Settings → Playback → "Lyrics while playing" switches them. New route `/api/lyrics/autosave` (`LyricsJob.autosave`).
- **v87** **Album "Find lyrics" button + lyric translations.** (A) A "♪ Find lyrics" button on every album page (next to Edit): one click runs the Find lyrics job for just that album's songs (LRCLIB first, GD Studio after; saved to iBroadcast when sure, never overwrites). The button shows the progress ("Finding lyrics… 3/10"), a message at the end says how many were saved / already had lyrics / not found / need a look, and the Lyrics labels on the songs refresh. Songs that were "not found" or "couldn't match" before are looked at again. Needs Premium. Server: `/api/lyrics-job/start` now takes `track_ids`. (B) Chinese lyrics from GD Studio come with their translated lyric when there is one (`tr` on each line): shown under the current line in the player bar and Mini Player (in place of the dim next line), as small italic text in the header card, floating box and large Now playing view. Settings → Playback → "Lyrics while playing" → "Show translations" (on).
- **v88** **Auto-save also for GD Studio lyrics.** Timed lyrics that Tagcast finds on GD Studio while a song plays (not only LRCLIB/Unison) are now saved once to the song's iBroadcast Lyrics field, only when it has none and never overwriting; the header card footer then says "Saved in iBroadcast". Same switch as before (Settings → Playback → Lyrics while playing → Save found timed lyrics). Translations are not saved.
- **v91** **Downloads + wishlist + Upload batch.** (1) Wishlist: retries search the artist's MusicBrainz aliases and offer a one-click "Search as “X”" when MusicBrainz credits the album to someone else; manual "Search as…" row. (2) Download duplicate check matches close titles (brackets, versions) against library and history and dedupes inside one batch; strict album mode skips YouTube playlists much longer than the expected track count and videos over 20 minutes; Upload "Skip duplicates" only skips real iBroadcast/uploaded-before hits. (3) Age-restricted YouTube: falls back to another upload, then other sources; optional browser/cookies.txt sign-in; "Update yt-dlp" button in Settings. (4) Upload: click a row for an Mp3tag-style tag popup (several files show <keep>, Previous/Next, Enter saves). (5) Track numbers now come from MusicBrainz then Discogs only (Overview › Track numbers…, account-wide background job, exact title match, never overwrites a number, undoable in Change history); the order-based "Auto-number the selected" Upload tool is removed.
- **v90** **Lyrics batch + faster start.** (1) Header lyrics card is bigger (about 480×330) with A−/A+ buttons (3 sizes, remembered). (2) Karaoke glow: the current word lights up as it is sung, with real word timing when the lyrics have it and an even estimate otherwise (Settings → Playback → Lyrics while playing: "Karaoke glow", plus "Use only real word timing"). (3) Faster start: the saved library file is read while iBroadcast's status call is on its way. (4) "Find lyrics" button on playlist pages (same job as the album button, up to 500 songs). (5) Galaxy prepares the next song's MusicBrainz and cover lookups while the current one downloads. (6) One version number per batch (rule added to CLAUDE.md).
- **v89** **English translation for Chinese lyrics.** When a Chinese (also Japanese or Korean) song with timed lyrics plays, Tagcast asks Google Translate's free web endpoint (no key) for an English line under each line, once per song, and remembers it in `~/.tagcast/lyrics_translations.json` (newest 300 songs). It shows wherever v87 showed translations (player bar and Mini Player next line, header card, floating box, large Now playing view). Lines with their own translation from GD Studio keep it; English lines and music notes get none. Settings → Playback → Lyrics while playing → "Translate Chinese, Japanese and Korean lyrics to English" (on) and "Show translations under the lyrics" (on). The endpoint is unofficial: if it says "too many requests" Tagcast pauses it for 10 minutes and the lyrics just stay untranslated. New route `/api/lyrics/translate`, module `lyrics_translate.py`. Translations are not saved to iBroadcast.
- **v84** **Galaxy: fewer lookups, smarter fallback, auto releases.** (1) MusicBrainz is asked once per album: after the first song matches, the release's track list is saved and the other songs take their number, year and genre from it (no call). (2) The GD Studio quota (calls of the last 5 minutes and a 403 pause) is saved in ~/.tagcast/galaxy_quota.json, so a restart no longer forgets it and hits the firewall. (3) A Galaxy song that fails with a download error, a firewall block or "gave up after retries" now goes straight to YouTube → Bandcamp → Soulseek too (before: only "No download link" / "Preview only"). (4) GitHub Actions workflow "Fork release": each new fork vN pushed to main gets a GitHub release (tag fork-vN) with the zip, made by GitHub's own token.
- **v83** **Galaxy about 2× faster.** (1) Lyrics come from LRCLIB first (outside GD Studio's 45-calls-per-5-min quota); the GD Studio lyric call only runs when LRCLIB has nothing, so most songs use one quota call instead of two. Instrumentals skip lyrics. (2) Two-stage download: while one song does MusicBrainz, cover, lyrics and tags, the next song already gets its link and downloads. (3) Pause between songs 6 s → 1 s (a saved 6 s moves to 1 s once; the API limiter still paces calls and a 403 firewall page still pauses 90 s). Each finished row shows its timing ("Ns after previous (link · download · musicbrainz · cover+lyrics · tags)"), also in the log, to compare speeds.
- **v82** **Featured-artist downloads + lyrics feat-strip.** (1) Compilations in Discography now show an "Appearance" pill for releases where the artist is a featured guest (Discogs role ≠ Main). "Get the missing" for those albums searches for the artist's own songs on the album instead of trying to download the full album (which always failed). Each appearance row has a one-click "Get full album" button to download the whole album regardless. (2) Lyrics search now strips an unbracketed trailing "feat. X, Y & Z" (and stray closing brackets) from the song title before querying LRCLIB and GD Studio. The primary artist is now split on "·" too (e.g. "Army of the Pharaohs · Jedi Mind Tricks" → "Army of the Pharaohs"), so only the main act is used in the search. The rapper now spins a CD (cover art fills the disc) instead of a vinyl record.
- **v81** **Find lyrics for the whole library, rapper with a vinyl.** (1) Overview > Metadata health > Find lyrics...: a slow background run over every song with no lyrics. Songs that already have lyrics are never touched. LRCLIB first, then GD Studio (netease, joox, bilibili; title with artist, title alone, simplified Chinese), through Galaxy's rate limiter so downloads go first and a firewall page pauses it. A match needs the same title and artist and a timing that fits the length; it is saved to the song's iBroadcast lyrics as timed LRC text. Unsure ones wait under "Couldn't match" (Preview / Use these lyrics / None of these). Pause, Resume, Stop; what was checked is kept in `lyrics-job.json`, so it continues where it left off after a stop or restart. (2) Now playing reads timed iBroadcast lyrics (`[01:23.45]words`) and follows the song with them; plain lyrics keep working. (3) The rapper now has a big spinning vinyl (the album cover is its label) beside him, and he is a little smaller; his mic arm just touches the vinyl.
