"use strict";

// Downloads (fork v9): check songs/albums against iBroadcast and the download history,
// decide about possible duplicates, see the queue and the history, import the old
// Galaxy/Telegram histories and choose the download folder. Duplicates are never
// queued automatically, and nothing is uploaded to iBroadcast.
const downloadsView = {
  tab: "galaxy", lines: "", galaxy: null, poll: null, info: null, queue: null, held: null, results: null, checkKind: "song",
  history: {query: "", source: "", offset: 0, data: null}, picked: new Set(), busy: false, timer: null,
  persistError: "", stalled: [],
};
const downloadsTabs = [["youtube", "YouTube"], ["galaxy", "Galaxy"], ["bandcamp", "Bandcamp"], ["soulseek", "Soulseek"], ["more", "More sources"], ["discography", "Discography"], ["labels", "Labels"], ["missing", "Missing"], ["tagclean", "Clean up"], ["upload", "Upload"], ["check", "Check"], ["pagelist", "From a page"], ["decide", "Needs your decision"], ["queue", "Queue & history"], ["settings", "Settings"]];
const downloadsStatusLabels = {have: "In iBroadcast", partly: "Partly (other edition)", downloaded: "Downloaded before", folder: "In your download folder", new: "New"};
const downloadsSourceLabels = {youtube: "YouTube", galaxy: "Galaxy", telegram: "Telegram", bandcamp: "Bandcamp", soulseek: "Soulseek", more: "YouTube/SoundCloud/Audiomack", manual: "Added here"};

function downloadsDate(seconds) {
  if (!seconds) return "";
  return new Date(seconds * 1000).toLocaleDateString("en-GB", {day: "numeric", month: "short", year: "numeric"});
}

// Every failure shows its message with the fork version and plays the alert sound.
function downloadsError(error) {
  setActionStatus("#downloads-status", `${error.message || error} (${artistCleanupVersion})`);
  artistCleanupAlarm();
}

function downloadsNote(message) {
  setActionStatus("#downloads-status", "");
  if (message) toast(message);
}

function showDownloads(tab) {
  if (tab) downloadsView.tab = tab;
  else if (["queue", "upload"].includes(downloadsView.tab) && downloadsView.lastTab) downloadsView.tab = downloadsView.lastTab;  // v70: the menu has its own Queue & history
  showScreen("downloads");
  $("#downloads-version").textContent = artistCleanupVersion;
  renderDownloads();
  loadDownloads();
}

async function loadDownloads() {
  try {
    const [info, queue, galaxy, finding] = await Promise.all([api("/api/downloads"), api("/api/downloads/queue"), api("/api/galaxy/status"), api("/api/discography/active")]);
    downloadsView.finding = finding.jobs;
    downloadsView.info = info; downloadsView.queue = queue.queue; downloadsView.held = queue.held; downloadsView.galaxy = galaxy;
    downloadsView.persistError = queue.persist_error || ""; downloadsView.stalled = queue.stalled || [];
    for (const id of [...downloadsView.picked]) if (!queue.held.some(h => h.id === id)) downloadsView.picked.delete(id);
    if (downloadsView.tab === "queue") await loadDownloadsHistory();
    renderDownloads();
    downloadsPoll();
  } catch (error) { downloadsError(error); }
}

// While songs download, refresh only the queue box and the Galaxy status line (never the
// fields you are typing in), every 1.5 s, and only while the Downloads page is open.
function downloadsBusy() {
  return (downloadsView.queue || []).some(i => i.state === "active" || (i.state === "queued" && i.payload))
    || (downloadsView.finding || []).some(f => f.state === "running");
}

function downloadsPoll() {
  clearTimeout(downloadsView.poll);
  if (state.screen !== "downloads" || !downloadsBusy()) return;
  downloadsView.poll = setTimeout(async () => {
    if (state.screen !== "downloads") return;
    try {
      const before = downloadsView.held?.length || 0;
      const [queue, galaxy, finding, info] = await Promise.all([api("/api/downloads/queue"), api("/api/galaxy/status"), api("/api/discography/active"), api("/api/downloads")]);
      const waitingBefore = downloadsView.info?.genre_waiting || 0;
      if (info && downloadsView.info) downloadsView.info.genre_waiting = info.genre_waiting || 0;
      downloadsView.finding = finding.jobs;
      const failed = (downloadsView.queue || []).filter(i => i.state === "failed").length;
      downloadsView.queue = queue.queue; downloadsView.held = queue.held; downloadsView.galaxy = galaxy;
      downloadsView.persistError = queue.persist_error || ""; downloadsView.stalled = queue.stalled || [];
      if (queue.queue.filter(i => i.state === "failed").length > failed) artistCleanupAlarm();
      downloadsManagerRender();
      if ($("#galaxy-status")) $("#galaxy-status").innerHTML = galaxyStatusHtml();
      if (before !== queue.held.length || waitingBefore !== (downloadsView.info?.genre_waiting || 0)) $("#downloads-tabs").innerHTML = downloadsTabsHtml();
    } catch { /* the next full load shows the error */ }
    downloadsPoll();
  }, 1500);
}

function downloadsTabsHtml() {
  const view = downloadsView, held = view.held?.length || 0, waiting = view.info?.genre_waiting || 0;
  const banner = waiting && view.tab !== "tagclean" ? `<p class="dl-genre-banner" role="status"><b>${waiting}</b> downloaded ${waiting === 1 ? "song needs" : "songs need"} a genre from you (Tagcast was not sure).
    <button type="button" class="button small primary" data-downloads-tab="tagclean">Choose genres</button></p>` : "";
  return banner + downloadsTabs.map(([key, label]) => `<button type="button" role="tab" data-downloads-tab="${key}"
    aria-selected="${view.tab === key}" tabindex="${view.tab === key ? 0 : -1}">${label}${key === "tagclean" && view.info?.genre_waiting ? ` <b class="dl-count">${view.info.genre_waiting}</b>` : ""}${key === "decide" && held ? ` <b class="dl-count">${held}</b>` : ""}${key === "missing" && typeof missingView !== "undefined" && missingView.releases?.unseen ? ` <b class="dl-count">${missingView.releases.unseen}</b>` : ""}</button>`).join("");
}


// v58: every table and list on the Downloads page can be folded away. Each one sits under a heading line
// (the heading before it, or the tab name); open or closed is remembered per section in this browser.
const DL_COLLAPSE_KEY = "tagcast-downloads-collapsed", dlDefaultClosed = new Set(["Finding sources"]);

function dlCollapsedState() {
  try { return JSON.parse(localStorage.getItem(DL_COLLAPSE_KEY) || "{}") || {}; } catch { return {}; }
}

function dlSectionOpen(label) {
  const saved = dlCollapsedState()[label];
  return typeof saved === "boolean" ? saved : !dlDefaultClosed.has(label);
}

function downloadsCollapsify(html, fallback) {
  const used = new Map();
  let out = "", at = 0;
  const open = /<(table|ul)\b([^>]*)>/g;
  for (let m; (m = open.exec(html));) {
    if (m[1] === "ul" && (!/class="[^"]*\bdl-list\b/.test(m[2]) || /\bdl-nofold\b/.test(m[2]))) continue;
    let depth = 1, i = open.lastIndex;
    const tag = new RegExp(`<(/?)${m[1]}\\b[^>]*>`, "g");
    tag.lastIndex = i;
    for (let t; depth && (t = tag.exec(html));) { depth += t[1] ? -1 : 1; i = tag.lastIndex; }
    if (depth) continue;
    const block = html.slice(m.index, i);
    const heads = [...html.slice(at, m.index).matchAll(/<h[23][^>]*>([\s\S]*?)<\/h[23]>/g)];
    let label = (heads.length ? heads[heads.length - 1][1] : fallback).replace(/<span[\s\S]*?<\/span>/g, "").replace(/<[^>]*>/g, "").split(" · ")[0].trim() || fallback;
    const n = (used.get(label) || 0) + 1; used.set(label, n);
    if (n > 1) label += ` ${n}`;
    const rows = (block.match(m[1] === "table" ? /<tr\b/g : /<li\b/g) || []).length - (m[1] === "table" ? 1 : 0);
    out += html.slice(at, m.index) + `<details class="dl-fold" data-dl-fold="${escapeHtml(label)}" ${dlSectionOpen(label) ? "open" : ""}>
      <summary data-dl-fold-toggle="${escapeHtml(label)}">${escapeHtml(label)} <span class="muted">${Math.max(0, rows)}</span></summary>${block}</details>`;
    at = i; open.lastIndex = i;
  }
  return out + html.slice(at);
}

function downloadsManagerRender() {
  const box = $("#dl-queue-box");
  if (box) box.innerHTML = downloadsCollapsify(downloadsQueueBoxHtml(), "Queue");
}

async function loadDownloadsHistory() {
  const h = downloadsView.history;
  const params = new URLSearchParams({q: h.query, source: h.source, offset: String(h.offset)});
  h.data = await api(`/api/downloads/history?${params}`);
}

// v65: on tabs with a search box, the search and its results come first and the queue follows.
const DOWNLOADS_SEARCH_TABS = new Set(["youtube", "galaxy", "bandcamp", "soulseek", "more", "discography", "labels", "pagelist", "check"]);

// v70: "Queue & history" has its own entry in the left menu; it lights up instead of Downloads on that tab.
function syncDownloadsNav() {
  const view = downloadsView, onPage = state.screen === "downloads";
  if (view.tab !== "queue" && view.tab !== "upload") view.lastTab = view.tab;
  $("#show-downloads")?.classList.toggle("active", onPage && view.tab !== "queue" && view.tab !== "upload");
  $("#show-upload")?.classList.toggle("active", onPage && view.tab === "upload");
  $("#show-dl-queue")?.classList.toggle("active", onPage && view.tab === "queue");
  const count = $("#dl-queue-count");
  if (count) {
    const waiting = (view.queue || []).filter(i => ["queued", "running", "active"].includes(i.state)).length;
    count.textContent = waiting ? String(waiting) : ""; count.hidden = !waiting;
  }
}

function renderDownloads() {
  const view = downloadsView;
  syncDownloadsNav();
  $("#downloads-page")?.classList.toggle("dl-queue-last", DOWNLOADS_SEARCH_TABS.has(view.tab));
  $("#downloads-tabs").innerHTML = downloadsTabsHtml();
  const body = {youtube: youtubeHtml, galaxy: galaxyHtml, bandcamp: bandcampHtml, soulseek: soulseekHtml, more: moreHtml, discography: discographyHtml, labels: labelsHtml, missing: missingHtml, tagclean: tagcleanHtml, upload: uploaderHtml, check: downloadsCheckHtml, pagelist: pagelistHtml, decide: downloadsDecideHtml, queue: downloadsQueueHtml, settings: downloadsSettingsHtml}[view.tab]();
  $("#downloads-content").innerHTML = downloadsCollapsify(body, downloadsTabs.find(([k]) => k === view.tab)?.[1] || "List");
  // The download manager always sits at the top of the page (v54), whichever tab is open.
  downloadsManagerRender();
}

function downloadsYouHave(rows) {
  return (rows || []).map(r => r.where === "folder" ? `<span>In your download folder: ${escapeHtml(r.path || r.title)}</span>` : r.where === "ibroadcast"
    ? `<span>iBroadcast: ${escapeHtml(r.title)} · ${escapeHtml(r.artist)}${r.album ? ` · <i>${escapeHtml(r.album)}</i>` : ""}${r.tracks ? ` · ${r.tracks} ${r.tracks === 1 ? "track" : "tracks"}` : ""}${r.edition ? " · other edition" : ""}</span>`
    : `<span>Downloaded ${escapeHtml(downloadsDate(r.when) || "before")} via ${escapeHtml(downloadsSourceLabels[r.source] || r.source || "?")}${r.pc ? ` at <b>${escapeHtml(r.pc)}</b>` : ""}, not uploaded yet: ${escapeHtml(r.title)}${r.artist ? ` · ${escapeHtml(r.artist)}` : ""}${r.songs ? ` (${r.songs} songs)` : ""}</span>`).join("");
}

function downloadsItemLabel(item) {
  const tracks = item.kind === "album" && item.tracks ? ` · ${item.tracks} tracks` : "";
  return `${item.kind === "album" ? "Album: " : ""}<b>${escapeHtml(item.title)}</b>${item.artist ? ` · ${escapeHtml(item.artist)}` : ""}${tracks}`;
}

function downloadsCheckHtml() {
  const view = downloadsView, results = view.results;
  const counts = results ? Object.keys(downloadsStatusLabels).map(s => [s, results.filter(r => r.status === s).length]).filter(([, n]) => n) : [];
  return `<p class="muted">One per line: <code>Artist - Title</code>. Albums may end with <code>| 12</code> for the number of tracks; another track count counts as a partly owned edition.</p>
    <div class="dl-kind" role="radiogroup" aria-label="What you check">
      <label><input type="radio" name="dl-kind" value="song" ${view.checkKind === "song" ? "checked" : ""}> Songs</label>
      <label><input type="radio" name="dl-kind" value="album" ${view.checkKind === "album" ? "checked" : ""}> Albums</label></div>
    <textarea id="downloads-lines" class="dl-lines" rows="6" maxlength="100000" placeholder="${view.checkKind === "album" ? "Company Flow - Funcrusher Plus | 15" : "Coldplay - Yellow"}" aria-label="Songs or albums to check">${escapeHtml(view.lines)}</textarea>
    <div class="dl-actions"><button type="button" class="button primary" data-downloads-check ${view.busy ? "disabled" : ""}>Check</button>
      ${results?.length ? `<button type="button" class="button" data-downloads-add>Add to queue…</button><span class="muted">New items are queued; everything you may have goes to Needs your decision.</span>` : ""}</div>
    ${results ? `<p class="dl-summary" role="status">${counts.map(([s, n]) => `<span class="dl-badge ${s}">${n} ${downloadsStatusLabels[s]}</span>`).join(" ") || "Nothing to check."}</p>
    <ul class="dl-list">${results.map(r => `<li><span class="dl-badge ${r.status}">${downloadsStatusLabels[r.status]}</span>
      <div><div>${downloadsItemLabel(r)}</div><div class="dl-have">${downloadsYouHave(r.you_have)}</div></div></li>`).join("")}</ul>` : ""}
    <p class="muted">Items added here wait in the queue until a source can fetch them; Galaxy searches and downloads on its own tab. Bandcamp, Soulseek, Telegram and artist discographies arrive in later versions.</p>`;
}

function downloadsDecideHtml() {
  const held = downloadsView.held;
  if (!held) return '<p class="muted">Loading…</p>';
  if (!held.length) return '<p class="muted">Nothing is waiting. Possible duplicates from any source appear here, and are never downloaded until you choose Download anyway.</p>';
  const all = held.every(h => downloadsView.picked.has(h.id)), picked = downloadsView.picked.size;
  return `<p class="muted">You may already have these. Choose for each one, or tick several and decide in bulk.</p>
    <div class="dl-actions"><label><input type="checkbox" data-downloads-pick-all ${all ? "checked" : ""}> Select all (${held.length})</label>
      <button type="button" class="button" data-downloads-decide="skip" ${picked ? "" : "disabled"}>Skip ${picked || ""}</button>
      <button type="button" class="button primary" data-downloads-decide="download" ${picked ? "" : "disabled"}>Download anyway ${picked || ""}</button></div>
    <ul class="dl-list dl-decide">${held.map(h => `<li>
      <input type="checkbox" data-downloads-pick="${escapeHtml(h.id)}" aria-label="Select ${escapeHtml(h.title)}" ${downloadsView.picked.has(h.id) ? "checked" : ""}>
      <div class="dl-compare"><div><span class="eyebrow">THIS ONE · ${escapeHtml(downloadsSourceLabels[h.source] || h.source)}</span>${downloadsItemLabel(h)}</div>
        <div><span class="eyebrow">YOU HAVE · ${escapeHtml(downloadsStatusLabels[h.status] || h.status)}</span><div class="dl-have">${downloadsYouHave(h.you_have)}</div></div></div>
      <div class="dl-row-actions"><button type="button" class="button small" data-downloads-one="skip" data-id="${escapeHtml(h.id)}">Skip</button>
        <button type="button" class="button small" data-downloads-one="download" data-id="${escapeHtml(h.id)}">Download anyway</button></div></li>`).join("")}</ul>`;
}

const downloadsSteps = ["Got link", "Downloading", "MusicBrainz lookup", "Tagging", "Saved"];

function downloadsSeconds(s) {
  s = Math.round(s || 0);
  return s >= 60 ? `${Math.floor(s / 60)} min ${s % 60} s` : `${s} s`;
}

// Albums being looked up on Galaxy → Bandcamp → Soulseek (v46), from Discography, Missing, From a page...
// Once a source has them they move into the queue below.
function downloadsFindingHtml() {
  const jobs = downloadsView.finding || [];
  if (!jobs.length) return "";
  const running = jobs.some(j => j.state === "running");
  return `<div class="dl-card" role="status"><h3>Finding sources ${running ? "" : "· done"}</h3>
    <ul class="dl-list">${jobs.map(j => `${j.log.map(e => `<li><span class="dl-badge ${e.source ? "have" : "partly"}">${escapeHtml(e.source || "Not found")}</span>
      <div><b>${escapeHtml(e.title)}</b> · ${escapeHtml(j.name)}<div class="dl-have">${escapeHtml(e.note || "")}</div></div></li>`).join("")}
      ${j.state === "running" ? `<li><span class="dl-badge downloaded">Looking…</span><div>${escapeHtml(j.current || j.name)}<div class="muted">${escapeHtml(j.name)} · ${j.done} of ${j.total} done</div></div></li>` : ""}`).join("")}</ul>
    ${running ? "" : `<button type="button" class="button small" data-downloads-finding-dismiss>Clear</button>`}</div>`;
}

// v63: the real site (YouTube, SoundCloud, Audiomack) for "more" downloads, and the search or link each came from.
function downloadsSourceName(i) {
  return i.payload?.site || i.site || downloadsSourceLabels[i.source] || i.source || "";
}

function downloadsOriginHtml(i) {
  const short = value => value.length > 60 ? `${value.slice(0, 57)}…` : value;
  const one = (label, value) => ` · <span title="${escapeHtml(value)}">${label}: ${escapeHtml(short(value.replace(/^https?:\/\/(www\.)?/, "")))}</span> <button type="button" class="text-action" data-dl-copy="${escapeHtml(value)}" title="Copy">⧉</button>`;
  return i.query ? one("query", i.query) : i.link ? one("from", i.link) : "";
}

function downloadsQueueBoxHtml() {
  const queue = downloadsView.queue || [], g = downloadsView.galaxy;
  const count = st => queue.filter(i => i.state === st).length;
  const order = {active: 0, queued: 1, failed: 2, done: 3, skipped: 4};
  const rows = [...queue].map((item, index) => ({item, index})).sort((a, b) => (order[a.item.state] ?? 5) - (order[b.item.state] ?? 5)
    || (["done", "skipped"].includes(a.item.state) ? b.index - a.index : a.index - b.index)).map(r => r.item);
  const queuedTotal = count("queued") + count("active"), doneTotal = count("done");
  const overall = queuedTotal + doneTotal ? Math.round(doneTotal / (queuedTotal + doneTotal) * 100) : 0;
  const label = i => i.state === "active" ? `Step ${Math.max(1, (i.step ?? 0) + 1)}/5 · ${downloadsSteps[i.step] || "Starting"}`
    : i.state === "queued" ? (i.payload ? (i.allow_duplicate ? "Waiting (you chose Download anyway)" : "Waiting") : "Waits for a source")
    : {done: "Saved", failed: "Failed", skipped: "Skipped"}[i.state] || i.state;
  const badge = i => ({active: "downloaded", queued: "new", done: "have", failed: "partly", skipped: "partly"}[i.state] || "new");
  return `${downloadsFindingHtml()}<div class="dl-actions dl-queue-controls">
      <button type="button" class="button small" data-galaxy-control="${g?.paused ? "resume" : "pause"}">${g?.paused ? "▶ Resume" : "⏸ Pause"}</button>
      <button type="button" class="button small" data-galaxy-control="cancel" ${g?.active ? "" : "disabled"}>⏹ Cancel current</button>
      <button type="button" class="button small" data-galaxy-control="retry" ${count("failed") ? "" : "disabled"}>Retry failed (${count("failed")})</button>
      <button type="button" class="button small" data-galaxy-control="clear_done" ${doneTotal ? "" : "disabled"}>Clear done</button>
      <button type="button" class="button small" data-galaxy-control="clear_waiting" ${count("queued") ? "" : "disabled"}>Clear waiting</button>
      <button type="button" class="button small" data-galaxy-control="clear_failed" ${count("failed") ? "" : "disabled"}>Clear failed</button>
      <button type="button" class="button small" data-galaxy-control="clear_skipped" ${count("skipped") ? "" : "disabled"}>Clear skipped</button>
      <button type="button" class="button small" data-activity-open data-activity-cat="downloads" title="Every queue step, with why it failed">Activity log</button></div>
    <p class="muted" role="status">${galaxyStatusHtml()}</p>
    ${queuedTotal + doneTotal ? `<div class="dl-overall"><span>Overall: ${doneTotal} of ${queuedTotal + doneTotal} saved</span><progress max="100" value="${overall}" aria-label="Overall progress"></progress></div>` : ""}
    ${rows.length ? `<ul class="dl-list">${rows.map(i => `<li class="dl-job ${escapeHtml(i.state)}"><span class="dl-badge ${badge(i)}">${escapeHtml(label(i))}</span>
      ${i.payload ? galaxyThumb(i.payload.source, i.payload.pic_id, 100) : ""}
      <div>${downloadsItemLabel(i)}${i.album ? ` <span class="muted">· ${escapeHtml(i.album)}</span>` : ""}
        ${i.state === "active" ? `<div class="dl-progress"><progress max="100" value="${i.progress || 0}" aria-label="Download progress"></progress>
          <span class="${(i.idle || 0) >= 600 ? "error-text" : (i.idle || 0) >= 120 ? "dl-stuck" : "muted"}">${escapeHtml(i.step_detail || "")}${i.eta ? ` · ${downloadsSeconds(i.eta)} left` : ""}</span></div>` : ""}
        <div class="muted">${escapeHtml(downloadsSourceName(i))}${downloadsOriginHtml(i)}${i.state === "done" ? ` · ${escapeHtml(i.path || "")}` : ""}${i.note && i.state !== "done" ? ` · ${escapeHtml(i.note)}` : i.state === "done" && i.note && i.note !== "Saved" ? ` · ${escapeHtml(i.note)}` : ""}</div></div>
      <div class="dl-row-actions">
        ${i.state === "failed" ? `<button type="button" class="button small" data-galaxy-control="retry" data-id="${escapeHtml(i.id)}">Retry</button>` : ""}
        ${i.state === "failed" ? `<span class="dl-copy" role="group" aria-label="Copy for a manual search">
          ${i.artist ? `<button type="button" class="button small" data-dl-copy="${escapeHtml(i.artist)}" title="Copy the artist name">Copy artist</button>` : ""}
          ${i.album ? `<button type="button" class="button small" data-dl-copy="${escapeHtml(i.album)}" title="Copy the album name">Copy album</button>` : ""}
          <button type="button" class="button small" data-dl-copy="${escapeHtml(i.title)}" title="Copy the song or album title">Copy title</button></span>` : ""}
        ${i.state === "failed" && i.kind !== "album" && i.source !== "youtube" ? `<button type="button" class="button small" data-dl-try-youtube="${escapeHtml(i.id)}" title="Look this song up on YouTube instead">⬇ Try YouTube</button>` : ""}
        ${i.state === "failed" && i.youtube_near?.id ? `<button type="button" class="button small" data-dl-use-near="${escapeHtml(i.id)}" title="${escapeHtml(i.youtube_near.title)}">⬇ Use this one</button>` : ""}
        ${i.state === "failed" && i.short_seconds ? `<button type="button" class="button small" data-galaxy-control="allow_short" data-id="${escapeHtml(i.id)}" title="It is a real ${escapeHtml(String(i.short_seconds))}-second track (an intro or skit): download it again and keep it">Keep it (short track)</button>` : ""}
        ${i.state === "queued" && i.link && queue.filter(q => q.state === "queued" && q.link === i.link).length > 1 ? `<button type="button" class="button small" data-dl-cancel-link="${escapeHtml(i.link)}" title="Remove every waiting song from this link">✕ All from link (${queue.filter(q => q.state === "queued" && q.link === i.link).length})</button>` : ""}
        ${i.state === "queued" && i.payload ? `<button type="button" class="button small" data-galaxy-control="top" data-id="${escapeHtml(i.id)}" title="Move to top">⤒</button>` : ""}
        <button type="button" class="button small" ${i.payload ? `data-galaxy-control="remove" data-id="${escapeHtml(i.id)}"` : `data-downloads-remove="${escapeHtml(i.id)}"`}
          aria-label="${i.state === "active" ? "Cancel" : "Remove"} ${escapeHtml(i.title)}">${i.state === "active" ? "Cancel" : "✕"}</button></div></li>`).join("")}</ul>`
      : '<p class="muted">The queue is empty. Search on the Galaxy tab and press Download.</p>'}`;
}

function downloadsQueueHtml() {
  const h = downloadsView.history, data = h.data;
  const sources = Object.entries(downloadsView.info?.history_sources || {});
  const pages = data ? Math.ceil(data.total / 50) : 0, page = Math.floor(h.offset / 50);
  return `<h3>History <span class="muted">${downloadsView.info ? `${downloadsView.info.history.toLocaleString("en")} songs` : ""}</span></h3>
    <div class="toolbar dl-history-tools"><div class="search"><span aria-hidden="true">⌕</span><input id="downloads-history-search" maxlength="200" placeholder="Search the history" aria-label="Search the download history" value="${escapeHtml(h.query)}"></div>
      <select id="downloads-history-source" aria-label="Source"><option value="">All sources</option>${sources.map(([s, n]) => `<option value="${escapeHtml(s)}" ${h.source === s ? "selected" : ""}>${escapeHtml(downloadsSourceLabels[s] || s)} (${n})</option>`).join("")}</select></div>
    ${!data ? '<p class="muted">Loading…</p>' : !data.total ? '<p class="muted">No songs yet. Downloads from Galaxy appear here; you can also import old histories under Settings.</p>'
      : `<table class="dl-table"><thead><tr><th>Song</th><th>Artist</th><th>Album</th><th>Source</th><th>PC</th><th>Date</th></tr></thead><tbody>${data.entries.map(e => `<tr>
        <td>${escapeHtml(e.title)}</td><td>${escapeHtml((e.artists || []).join(", ") || "—")}</td><td>${escapeHtml(e.album || "—")}</td>
        <td>${escapeHtml(downloadsSourceName(e))}${e.query || e.link ? `<div class="muted" title="${escapeHtml(e.query || e.link)}">${escapeHtml((e.query ? "query: " + e.query : "from: " + e.link).slice(0, 60))}</div>` : ""}</td><td>${escapeHtml(e.pc || "—")}</td><td>${escapeHtml(downloadsDate(e.when))}</td></tr>`).join("")}</tbody></table>
      <div class="pagination">${pages > 1 ? `<button type="button" class="button small" data-downloads-page="${page - 1}" ${page ? "" : "disabled"}>← Previous</button>
        <span>Page ${page + 1} of ${pages} · ${data.total.toLocaleString("en")} songs</span>
        <button type="button" class="button small" data-downloads-page="${page + 1}" ${page + 1 < pages ? "" : "disabled"}>Next →</button>` : ""}</div>`}`;
}

function downloadsSettingsHtml() {
  const info = downloadsView.info, imports = info?.imports || {};
  const done = kind => imports[kind] ? `<p class="muted">Last import ${escapeHtml(downloadsDate(imports[kind].when))}: ${imports[kind].added} new of ${imports[kind].found} (${escapeHtml(imports[kind].path)}).</p>` : "";
  const gs = downloadsView.galaxy?.settings || {track_delay: 1, api_delay: 1.5, api_quota: 45};
  return `<section class="dl-card"><h3>Galaxy</h3>
      <p class="muted">GD Studio allows 50 API calls per 5 minutes; a download uses 2–3. Year, genre and track numbers come from MusicBrainz for every download.</p>
      <div class="dl-settings">
        <label>Pause between songs <span><input id="galaxy-track-delay" type="number" min="0" max="600" step="0.5" value="${gs.track_delay}"> s</span></label>
        <label>Pause between API calls <span><input id="galaxy-api-delay" type="number" min="0" max="60" step="0.1" value="${gs.api_delay}"> s</span></label>
        <label>API quota <span><input id="galaxy-api-quota" type="number" min="5" max="50" step="1" value="${gs.api_quota}"> calls per 5 min</span></label></div>
      <div class="dl-actions"><button type="button" class="button primary" data-galaxy-settings>Save Galaxy settings</button></div></section>
    <section class="dl-card"><h3>YouTube (yt-dlp)</h3><div id="youtube-settings">${youtubeSettingsHtml()}</div></section>
    <section class="dl-card"><h3>Soulseek</h3><div id="soulseek-settings">${soulseekSettingsHtml()}</div></section>
    <section class="dl-card"><h3>Download folder</h3>
      <p class="muted">Every source saves here (as <code>Album Artist\\Album\\## - Title</code>). Tagcast creates the folder if needed.</p>
      <div class="dl-actions"><input id="downloads-folder" class="dl-path" maxlength="400" value="${escapeHtml(info?.folder || "")}" aria-label="Download folder">
      <button type="button" class="button primary" data-downloads-folder>Save folder</button></div>
      ${info && !info.folder_set ? '<p class="muted">Not saved yet: this is the default.</p>' : ""}</section>
    <section class="dl-card"><h3>This PC and the other PC</h3>
      <p class="muted">Every download is recorded with the name of the PC that made it, so a song fetched at the office shows “downloaded at Office, not uploaded yet” at home. To share this between your PCs, pick the same shared folder on both (OneDrive, Dropbox or a network folder); each PC writes its own small file there.</p>
      <div class="dl-settings"><label>Name of this PC <span><input id="downloads-pc" class="dl-path" maxlength="40" value="${escapeHtml(info?.pc || "")}"></span></label>
        <label>Shared folder (optional) <span><input id="downloads-sync" class="dl-path" maxlength="400" value="${escapeHtml(info?.sync_folder || "")}" placeholder="C:\\Users\\you\\OneDrive\\Tagcast"></span></label></div>
      <div class="dl-actions"><button type="button" class="button primary" data-downloads-pc>Save</button></div>
      ${info?.sync_error ? `<p class="error-text">${escapeHtml(info.sync_error)}</p>` : ""}
      ${info?.other_pcs?.length ? `<p class="muted">Also seen here: ${info.other_pcs.map(escapeHtml).join(", ")}.</p>` : info?.sync_folder ? '<p class="muted">No other PC has written to this folder yet.</p>' : ""}</section>
    ${typeof syncCardHtml === "function" ? syncCardHtml() : ""}
    <section class="dl-card"><h3>Import the Galaxy history</h3>
      <p class="muted">The Galaxy app keeps <code>history.json</code> in its own folder, next to <code>app.py</code> and <code>run.bat</code>.</p>
      <div class="dl-actions"><input id="downloads-galaxy-path" class="dl-path" maxlength="400" placeholder="C:\\Users\\you\\Documents\\gd-music-downloader\\history.json" aria-label="Galaxy history.json">
      <button type="button" class="button" data-downloads-find>Find it</button><button type="button" class="button primary" data-downloads-import="galaxy">Import</button></div>
      <div id="downloads-galaxy-found"></div>${done("galaxy")}</section>
    <section class="dl-card"><h3>Import the Telegram history</h3>
      <p class="muted">Reads <code>state.json</code> and <code>download_history.csv</code>. Importing again adds only what is new.</p>
      <div class="dl-actions"><input id="downloads-telegram-path" class="dl-path" maxlength="400" value="${escapeHtml(info?.telegram_folder || "")}" aria-label="Telegram downloader folder">
      <button type="button" class="button primary" data-downloads-import="telegram">Import</button></div>${done("telegram")}</section>`;
}

async function downloadsRun(work) {
  if (downloadsView.busy) return;
  downloadsView.busy = true;
  try { await work(); } catch (error) { downloadsError(error); } finally { downloadsView.busy = false; }
}

document.addEventListener("click", event => {
  const target = event.target;
  if (target.closest("#show-downloads")) { showDownloads(); return; }
  if (target.closest("#show-dl-queue")) { showDownloads("queue"); return; }
  if (target.closest("#show-upload")) { showDownloads("upload"); return; }
  if (!target.closest("#downloads-page")) return;
  const tab = target.closest("[data-downloads-tab]");
  if (tab) {
    downloadsView.tab = tab.dataset.downloadsTab; setActionStatus("#downloads-status", "");
    renderDownloads(); loadDownloads();
    $(`[data-downloads-tab="${downloadsView.tab}"]`)?.focus();
    return;
  }
  if (target.closest("[data-downloads-finding-dismiss]")) {
    api("/api/discography/dismiss", {}).then(data => { downloadsView.finding = data.jobs; downloadsManagerRender(); });
    return;
  }
  if (target.closest("[data-downloads-check]")) {
    downloadsRun(async () => {
      const lines = downloadsView.lines = $("#downloads-lines").value;
      if (!lines.trim()) { toast("Type at least one line to check."); return; }
      const data = await api("/api/downloads/check", {lines, kind: downloadsView.checkKind});
      downloadsView.results = data.results; renderDownloads(); downloadsNote("");
    });
    return;
  }
  if (target.closest("[data-downloads-add]")) {
    downloadsRun(async () => {
      const items = downloadsView.results.map(({kind, title, artist, tracks}) => ({kind, title, artist, tracks}));
      const data = await api("/api/downloads/submit", {items});
      downloadsView.results = null;
      downloadsNote(`${data.queued} queued, ${data.held} waiting for your decision${data.skipped ? `, ${data.skipped} already listed` : ""}.`);
      downloadsView.tab = data.held ? "decide" : "queue";
      await loadDownloads();
    });
    return;
  }
  const decide = target.closest("[data-downloads-decide], [data-downloads-one]");
  if (decide) {
    const one = decide.dataset.downloadsOne, action = one || decide.dataset.downloadsDecide;
    const ids = one ? [decide.dataset.id] : [...downloadsView.picked];
    downloadsRun(async () => {
      const data = await api("/api/downloads/decide", {ids, action});
      for (const id of ids) downloadsView.picked.delete(id);
      downloadsNote(`${data.decided} ${action === "skip" ? "skipped" : "added to the queue"}.`);
      await loadDownloads();
    });
    return;
  }
  const fold = target.closest("[data-dl-fold-toggle]");
  if (fold) {
    event.preventDefault();
    const label = fold.dataset.dlFoldToggle, details = fold.closest("details"), now = !details.open;
    details.open = now;
    try { localStorage.setItem(DL_COLLAPSE_KEY, JSON.stringify({...dlCollapsedState(), [label]: now})); } catch { /* private window */ }
    return;
  }
  const copy = target.closest("[data-dl-copy]");
  if (copy) {
    const value = copy.dataset.dlCopy;
    Promise.resolve(navigator.clipboard?.writeText?.(value)).then(() => toast(`Copied: ${value}`), () => toast("Could not copy. Select the text instead."));
    return;
  }
  const control = target.closest("[data-galaxy-control]");
  if (control) {
    const action = control.dataset.galaxyControl, id = control.dataset.id;
    if (action.startsWith("clear_") && !confirm(`${control.textContent.trim()}? This only changes the list; downloaded files stay.`)) return;
    downloadsRun(async () => {
      downloadsView.galaxy = await api("/api/galaxy/control", {action, ids: id ? [id] : []});
      await loadDownloads();
    });
    return;
  }
  const remove = target.closest("[data-downloads-remove]");
  if (remove) { downloadsRun(async () => { await api("/api/downloads/remove", {ids: [remove.dataset.downloadsRemove]}); await loadDownloads(); }); return; }
  const page = target.closest("[data-downloads-page]");
  if (page) {
    downloadsView.history.offset = Math.max(0, Number(page.dataset.downloadsPage)) * 50;
    downloadsRun(async () => { await loadDownloadsHistory(); renderDownloads(); });
    return;
  }
  if (target.closest("[data-galaxy-settings]")) {
    downloadsRun(async () => {
      downloadsView.galaxy = await api("/api/galaxy/settings", {track_delay: $("#galaxy-track-delay").value,
        api_delay: $("#galaxy-api-delay").value, api_quota: $("#galaxy-api-quota").value});
      renderDownloads(); downloadsNote("Galaxy settings saved.");
    });
    return;
  }
  if (target.closest("[data-downloads-folder]")) {
    downloadsRun(async () => {
      downloadsView.info = await api("/api/downloads/folder", {folder: $("#downloads-folder").value});
      renderDownloads(); downloadsNote(`Downloads go to ${downloadsView.info.folder}.`);
    });
    return;
  }
  if (target.closest("[data-downloads-pc]")) {
    downloadsRun(async () => {
      downloadsView.info = await api("/api/downloads/pc", {pc: $("#downloads-pc").value, sync_folder: $("#downloads-sync").value});
      renderDownloads(); downloadsNote(`This PC is called ${downloadsView.info.pc}.`);
    });
    return;
  }
  if (target.closest("[data-downloads-find]")) {
    downloadsRun(async () => {
      const {paths} = await api("/api/downloads/find-galaxy");
      if (paths.length) $("#downloads-galaxy-path").value = paths[0];
      $("#downloads-galaxy-found").innerHTML = paths.length > 1
        ? `<p class="muted">Also found: ${paths.slice(1).map(p => `<button type="button" class="text-action" data-downloads-use="${escapeHtml(p)}">${escapeHtml(p)}</button>`).join(", ")}</p>`
        : paths.length ? "" : '<p class="muted">Not found in Desktop, Documents, Downloads, Music or OneDrive. Paste the path of the Galaxy app folder\'s history.json.</p>';
    });
    return;
  }
  const use = target.closest("[data-downloads-use]");
  if (use) { $("#downloads-galaxy-path").value = use.dataset.downloadsUse; return; }
  const importButton = target.closest("[data-downloads-import]");
  if (importButton) {
    const kind = importButton.dataset.downloadsImport;
    downloadsRun(async () => {
      const data = await api("/api/downloads/import", {kind, path: $(`#downloads-${kind}-path`).value});
      downloadsNote(`${kind === "galaxy" ? "Galaxy" : "Telegram"}: ${data.added} songs added, ${data.already} already in the history (${data.history} in total).`);
      await loadDownloads();
    });
  }
});

document.addEventListener("change", event => {
  const target = event.target;
  if (!target.closest?.("#downloads-page")) return;
  if (target.name === "dl-kind") {
    downloadsView.checkKind = target.value; downloadsView.results = null; renderDownloads();
  } else if (target.matches("[data-downloads-pick]")) {
    downloadsView.picked[target.checked ? "add" : "delete"](target.dataset.downloadsPick); renderDownloads();
  } else if (target.matches("[data-downloads-pick-all]")) {
    downloadsView.picked = new Set(target.checked ? downloadsView.held.map(h => h.id) : []); renderDownloads();
  } else if (target.id === "downloads-history-source") {
    Object.assign(downloadsView.history, {source: target.value, offset: 0});
    downloadsRun(async () => { await loadDownloadsHistory(); renderDownloads(); });
  }
});

document.addEventListener("input", event => {
  if (event.target.id === "downloads-lines") { downloadsView.lines = event.target.value; return; }
  if (event.target.id !== "downloads-history-search") return;
  clearTimeout(downloadsView.timer);
  downloadsView.timer = setTimeout(() => {
    Object.assign(downloadsView.history, {query: event.target.value, offset: 0});
    downloadsRun(async () => {
      await loadDownloadsHistory(); renderDownloads();
      const input = $("#downloads-history-search");
      input.focus(); input.setSelectionRange(input.value.length, input.value.length);
    });
  }, 300);
});

document.addEventListener("keydown", event => {
  const tab = event.target.closest?.("[data-downloads-tab]");
  if (!tab || !["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
  event.preventDefault();
  const keys = downloadsTabs.map(([key]) => key), index = keys.indexOf(tab.dataset.downloadsTab);
  const next = event.key === "Home" ? 0 : event.key === "End" ? keys.length - 1 : (index + (event.key === "ArrowRight" ? 1 : -1) + keys.length) % keys.length;
  $(`[data-downloads-tab="${keys[next]}"]`).click();
});

// v63: "All from link" removes every waiting song that came from the same pasted link.
document.addEventListener("click", async event => {
  const button = event.target.closest?.("[data-dl-cancel-link]");
  if (!button) return;
  const link = button.dataset.dlCancelLink;
  const ids = (downloadsView.queue || []).filter(q => q.state === "queued" && q.link === link).map(q => q.id);
  if (!ids.length) return;
  button.disabled = true;
  try {
    await api("/api/downloads/control", {action: "remove", ids});
    downloadsView.queue = (await api("/api/downloads/queue")).queue;
    toast(`Removed ${ids.length} waiting ${ids.length === 1 ? "song" : "songs"} from this link.`);
  } catch (error) { toast(error.message || String(error)); }
  renderDownloads();
});

// v70: "⬇ Use this one": the nearest YouTube result Try YouTube found.
document.addEventListener("click", async event => {
  const button = event.target.closest?.("[data-dl-use-near]");
  if (!button) return;
  button.disabled = true;
  try { await api("/api/youtube/use-near", {id: button.dataset.dlUseNear}); toast("Queued from YouTube."); }
  catch (error) { toast(error.message || String(error)); }
  downloadsView.queue = (await api("/api/downloads/queue")).queue;
  renderDownloads();
});

// v65: "⬇ Try YouTube" on a failed song.
document.addEventListener("click", async event => {
  const button = event.target.closest?.("[data-dl-try-youtube]");
  if (!button) return;
  button.disabled = true; button.textContent = "Searching…";
  try {
    await api("/api/youtube/try", {id: button.dataset.dlTryYoutube});
    toast("Found on YouTube and queued.");
  } catch (error) { toast(error.message || String(error)); }
  downloadsView.queue = (await api("/api/downloads/queue")).queue;
  renderDownloads();
});

// v72: lines (or links) that were queued leave the paste box; the ones that failed or still wait for a choice stay.
function dropQueuedLines(text, results) {
  const done = (results || []).filter(r => r && r.ok && r.line).map(r => String(r.line).trim());
  if (!done.length) return text;
  return String(text || "").split("\n").filter(line => !done.some(d => line.trim() === d || (d.startsWith("http") && line.includes(d)))).join("\n");
}
