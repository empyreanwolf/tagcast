"""A tiny fake iBroadcast (OAuth + API + library) for end-to-end testing.

Run:  python tests/mock_ibroadcast.py 9555
Then: TAGCAST_IBROADCAST_BASE=http://127.0.0.1:9555 IBROADCAST_CLIENT_ID=test \
      PYTHONPATH=src python -m tagcast.app

The device code is approved automatically on the second poll. Every write
request is appended to the "writes" list, visible at GET /_writes.
"""

import json
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

STATE = {
    "artists": {41: "Kate Bush", 42: "Pink Floyd", 43: "pink floyd"},
    "albums": {
        72: {"name": "Hounds of Love", "artist_id": 41, "year": 0, "disc": 1, "tracks": [900, 901, 902]},
        73: {"name": "The Dreaming", "artist_id": 41, "year": 1982, "disc": 1, "tracks": [903]},
        74: {"name": "Wish You Were Here", "artist_id": 42, "year": 1975, "disc": 1, "tracks": [904]},
    },
    "tracks": {
        900: {"title": "Running Up That Hill", "album_id": 72, "artist_id": 41, "year": 1985, "genre": "", "track": 1, "trashed": False, "artwork_id": 600},
        901: {"title": "Hounds of Love", "album_id": 72, "artist_id": 41, "year": 1985, "genre": "", "track": 2, "trashed": False, "artwork_id": 601},
        902: {"title": "Old deleted", "album_id": 72, "artist_id": 41, "year": 1985, "genre": "", "track": 3, "trashed": True, "artwork_id": 0},
        903: {"title": "Sat in Your Lap", "album_id": 73, "artist_id": 41, "year": 1982, "genre": "Art Pop;New Wave", "track": 1, "trashed": False, "artwork_id": 0},
        904: {"title": "Wish You Were Here", "album_id": 74, "artist_id": 42, "year": 1975, "genre": "Rock", "track": 4, "trashed": False, "artwork_id": 0},
    },
    "writes": [],
    "play_requests": [],
    "recent_tracks": [],
    "playlists": {},
    "tags": {},
    "premium": False,
    "polls": 0,
    "downloads": 0,  # full library downloads
    "version": 1,  # bumped on every write, reported as lastmodified
    "next_artist": 100,
    "reject": set(),  # modes to reject, set via POST /_reject
    "artist_art": {41: 0, 42: 500},
    "next_artwork": 9000,
    "uploads": [],  # (filename, bytes) of uploaded artwork
    "combine_sets": False,  # the account setting that blocks update_album
    "busy": 0,  # answer this many writes with HTTP 503 first
    "frozen": False,  # writes leave lastmodified unchanged (as within the same second)
    "album_only_artists": {42},  # no tracks credited to them, so iBroadcast marks them trashed
}
AUDIO = bytes(range(256)) * 40  # 10 KB of "audio" for stream tests
# a 1x1 PNG, served at /image.png for image download tests
PNG = bytes.fromhex("89504e470d0a1a0a0000000d4948445200000001000000010806000000"
                    "1f15c4890000000d49444154789c63000100000500010d0a2db40000000049454e44ae426082")
LOCK = threading.Lock()
TOKEN = "access-1"


def library():
    tmap = {"title": 0, "album_id": 1, "artist_id": 2, "year": 3, "genre": 4, "track": 5,
            "trashed": 6, "artwork_id": 7, "artists_additional": 8, "file": 9, "type": 10,
            "genres_additional": 11, "rating": 12, "uploaded_on": 13, "uploaded_time": 14, "length": 15,
            "artists_additional_map": {"artist_id": 0, "phrase": 1, "type": 2}}
    tracks = {"map": tmap}
    for i, t in STATE["tracks"].items():
        tracks[str(i)] = [t["title"], t["album_id"], t["artist_id"], t["year"], t["genre"],
                          t["track"], t["trashed"], t["artwork_id"], t.get("additional", []), f"/128/abc/{i}", t.get("type", "audio/mpeg"),
                          t.get("genres_additional", []), t.get("rating", 0), t.get("uploaded_on", ""),
                          t.get("uploaded_time", ""), t.get("length", 0)]
    albums = {"map": {"name": 0, "tracks": 1, "artist_id": 2, "trashed": 3, "year": 4, "disc": 5, "rating": 6, "artists_additional": 7, "artists_additional_map": {"artist_id": 0, "phrase": 1, "type": 2}}}
    for i, a in STATE["albums"].items():
        albums[str(i)] = [a["name"], a["tracks"], a["artist_id"], False, a["year"], a["disc"], a.get("rating", 0), a.get("additional", [])]
    artists = {"map": {"name": 0, "tracks": 1, "trashed": 2, "artwork_id": 3, "rating": 4}}
    for i, name in STATE["artists"].items():
        artists[str(i)] = [name, [], i in STATE["album_only_artists"], STATE["artist_art"].get(i, 0), STATE.get("artist_ratings", {}).get(i, 0)]
    return {"result": True, "authenticated": True, "settings": {"artwork_server": "http://127.0.0.1:1"},
            "status": {"lastmodified": lastmodified()},
            "lastfm": {"sessionkey": "secret-lastfm-session"},
            "library": {"albums": albums, "tracks": tracks, "artists": artists, "expires": 1999999999,
                        "playlists": {"map": {"name": 0, "type": 1, "tracks": 2, "system_created": 3, "description": 4, "artwork_id": 5},
                                      "777": ["Recently Played", "recently-played", STATE["recent_tracks"][:], True, "", 0],
                                      **{str(i): [p["name"], p.get("type"), p["tracks"], p.get("system_created", False), p.get("description", ""), p.get("artwork_id", 0)] for i, p in STATE["playlists"].items()}},
                        "tags": {str(i): row for i, row in STATE["tags"].items()}}}


def lastmodified():
    return f"2026-10-04 12:00:{STATE['version']:02d}"


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, data):
        body = json.dumps(data).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        url = urlparse(self.path)
        if url.path == "/oauth/device/code":
            q = parse_qs(url.query)
            assert q["client_id"] == ["test"], q
            self.send(200, {"device_code": "dev-1", "user_code": "WXYZ-1234", "interval": 1,
                            "expires_in": 600, "verification_uri": "https://example.invalid/device"})
        elif url.path == "/_writes":
            self.send(200, STATE["writes"])
        elif url.path == "/image.png":
            self.send_response(200)
            self.send_header("Content-Type", "image/png")
            self.send_header("Content-Length", str(len(PNG)))
            self.end_headers()
            self.wfile.write(PNG)
        elif url.path.startswith("/stream/"):
            q = parse_qs(url.query)
            if q.get("Signature") != [TOKEN] or q.get("user_id") != ["7"]:
                return self.send(403, {})
            data, start = AUDIO, 0
            ranged = self.headers.get("Range", "").startswith("bytes=")
            if ranged:
                first, _, last = self.headers["Range"][6:].partition("-")
                start, end = int(first or 0), int(last) if last else len(AUDIO) - 1
                data = AUDIO[start:end + 1]
            self.send_response(206 if ranged else 200)
            self.send_header("Content-Type", "audio/mpeg")
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(len(data)))
            if ranged:
                self.send_header("Content-Range", f"bytes {start}-{start + len(data) - 1}/{len(AUDIO)}")
            self.end_headers()
            self.wfile.write(data)
        else:
            self.send(404, {})

    def do_POST(self):
        url = urlparse(self.path)
        raw = self.rfile.read(int(self.headers.get("Content-Length") or 0))
        if url.path == "/_reject":
            STATE["reject"] = set(json.loads(raw))
            return self.send(200, {})
        if url.path == "/_combine_sets":  # body: true or false
            STATE["combine_sets"] = bool(json.loads(raw or b"false"))
            return self.send(200, {})
        if url.path == "/_edit_elsewhere":
            STATE["albums"][73]["year"] += 1
            STATE["version"] += 1
            return self.send(200, {})
        if url.path.startswith("/oauth/"):
            form = {k: v[0] for k, v in parse_qs(raw.decode()).items()}
            if url.path == "/oauth/token":
                if form.get("grant_type") == "device_code":
                    STATE["polls"] += 1
                    if STATE["polls"] < 2:
                        return self.send(400, {"error": "authorization_pending"})
                return self.send(200, {"access_token": TOKEN, "refresh_token": "refresh-1",
                                       "expires_in": 3600, "scope": "user.library:read user.library:write"})
            return self.send(200, {})
        if self.headers.get("Authorization") != f"Bearer {TOKEN}":
            return self.send(200, {"result": False, "authenticated": False})
        if url.path == "/artwork-upload":
            if b'name="uploaded_file"' not in raw or b'name="user_id"' not in raw:
                return self.send(200, {"result": False, "message": "no file"})
            with LOCK:
                STATE["next_artwork"] += 1
                STATE["uploads"].append(raw)
                return self.send(200, {"result": True, "artwork_id": STATE["next_artwork"]})
        body = json.loads(raw)
        mode = body.get("mode")
        with LOCK:
            if mode in STATE["reject"]:
                return self.send(200, {"result": False, "message": f"{mode} is not allowed for this app"})
            if url.path == "/library":
                STATE["downloads"] += 1
                return self.send(200, library())
            if "history" in body:
                STATE["play_requests"].append(body)
                if STATE["busy"]:
                    STATE["busy"] -= 1
                    return self.send(503, {"message": "busy"})
                for day in body["history"]:
                    for track_id, count in day["plays"].items():
                        track = STATE["tracks"][int(track_id)]
                        track["plays"] = track.get("plays", 0) + count
                        if count > 0:
                            track_id = int(track_id)
                            STATE["recent_tracks"] = [track_id, *[i for i in STATE["recent_tracks"] if i != track_id]]
                if not STATE["frozen"]:
                    STATE["version"] += 1
            if mode == "status":
                return self.send(200, {"result": True, "status": {"lastmodified": lastmodified(), "plays": 42,
                                                                  "available": 5, "achievement_status": {"1": {}}},
                                       "lastfm": {"linked": True, "user": "wilfred", "sessionkey": "secret"},
                                       "dropbox": {"linked": False}, "googledrive": {"linked": False},
                                       "user": {"username": "wilfred", "id": "7", "token": "x",
                                                "email_address": "wilfred@example.com", "verified": True,
                                                "verified_on": "2021-11-28 19:00:00", "premium": STATE["premium"],
                                                "session": {"session_uuid": "tagcast-session", "sessions": [{"session_uuid": "remote-session", "device_name": "Living room", "joinable": True}]},
                                                "preferences": {"combine_sets": "1" if STATE["combine_sets"] else "0"}}})
            if mode == "update_album" and STATE["combine_sets"]:
                return self.send(200, {"result": False, "message": "You currently have 'Combine Multi-Disc Album Sets' on."})
            if mode == "gettrackuserdata":
                return self.send(200, {"result": True, "userdata": STATE["tracks"][int(body["track_id"])].get("userdata", [])})
            if mode in ("update_album", "update_track", "create_artist", "set_artwork",
                        "set_artist_artwork", "trash", "ratetrack", "ratealbum", "rateartist", "createplaylist", "createplaylistfolder", "appendplaylist", "updateplaylist", "deleteplaylist",
                        "createtag", "updatetag", "deletetags", "tagtracks"):
                if STATE["busy"]:
                    STATE["busy"] -= 1
                    return self.send(503, {"message": "busy"})
                STATE["writes"].append(body)
                if not STATE["frozen"]:
                    STATE["version"] += 1
            if mode == "set_artwork":
                for track_id in body["tracks"]:
                    STATE["tracks"][track_id]["artwork_id"] = body["artwork_id"]
                return self.send(200, {"result": True})
            if mode == "trash":
                for track_id in body["tracks"]:
                    STATE["tracks"][track_id]["trashed"] = True
                return self.send(200, {"result": True})
            if mode == "playqueue_token":
                return self.send(200, {"result": True, "token": "one-use-secret"})
            if mode == "createtag":
                i = max([1000, *STATE["tags"]]) + 1
                STATE["tags"][i] = {"name": body["tagname"], "archived": False, "tracks": []}
                return self.send(200, {"result": True, "id": i})
            if mode == "updatetag":
                STATE["tags"][body["tag_id"]]["name"] = body["name"]
                return self.send(200, {"result": True})
            if mode == "deletetags":
                for i in body["tags"]:
                    del STATE["tags"][i]
                return self.send(200, {"result": True})
            if mode == "tagtracks":
                tag = STATE["tags"][body["tagid"]]
                previous = set(tag["tracks"])
                tag["tracks"] = sorted(previous - set(body["tracks"]) if body["untag"] else previous | set(body["tracks"]))
                return self.send(200, {"result": True})
            if mode == "rateartist":
                assert type(body["artist_id"]) is int
                STATE.setdefault("artist_ratings", {})[body["artist_id"]] = body["rating"]
                return self.send(200, {"result": True})
            if mode == "ratealbum":
                assert type(body["album_id"]) is int
                STATE["albums"][body["album_id"]]["rating"] = body["rating"]
                return self.send(200, {"result": True})
            if mode in ("createplaylist", "createplaylistfolder"):
                i = max([800, *STATE["playlists"]]) + 1
                STATE["playlists"][i] = {"name": body["name"], "description": body.get("description", ""), "tracks": body.get("tracks", [])[:], "type": "folder" if mode == "createplaylistfolder" else None, "artwork_id": 0}
                return self.send(200, {"result": True, "playlist_id": i})
            if mode == "deleteplaylist":
                STATE["playlists"].pop(int(body["playlist"]), None)
                return self.send(200, {"result": True})
            if mode in ("appendplaylist", "updateplaylist"):
                p = STATE["playlists"][int(body["playlist"])]
                if "tracks" in body:
                    p["tracks"] = list(dict.fromkeys([*p["tracks"], *body["tracks"]])) if mode == "appendplaylist" else body["tracks"][:]
                for field in ("name", "description", "artwork_id"):
                    if field in body:
                        p[field] = body[field]
                return self.send(200, {"result": True})
            if mode == "ratetrack":
                for track_id in body["track_id"]:
                    STATE["tracks"][track_id]["rating"] = body["rating"]
                return self.send(200, {"result": True})
            if mode == "set_artist_artwork":
                STATE["artist_art"][body["artist_id"]] = body["artwork_id"]
                return self.send(200, {"result": True})
            if mode == "get_artwork":
                STATE["last_get_artwork"] = {"track_id": body.get("track_id"), "artist_id": body.get("artist_id")}
                return self.send(200, {"result": True, "art": [{"artwork_id": 77}, {"artwork_id": 78}]})
            if mode == "create_artist":
                STATE["next_artist"] += 1
                STATE["artists"][STATE["next_artist"]] = body["name"]
                return self.send(200, {"result": True, "artist_id": STATE["next_artist"]})
            if mode == "update_album":
                for row in body["albums"]:
                    a = STATE["albums"][row["album_id"]]
                    if "artists_additional" in row:
                        a["additional"] = [[e["artist_id"], e.get("phrase"), e.get("type")]
                                           for e in row["artists_additional"]]
                    for k in ("name", "artist_id"):
                        if k in row:
                            a[k] = row[k]
                    for k in ("year", "disc"):
                        if k in row:
                            a[k] = int(row[k] or 0)
                return self.send(200, {"result": True})
            if mode == "update_track":
                for row in body["tracks"]:
                    t = STATE["tracks"][row["file_id"]]
                    for k in ("title", "genre", "artist_id", "genres_additional", "userdata"):
                        if k in row:
                            t[k] = row[k]
                    if "artists_additional" in row:
                        t["additional"] = [[e["artist_id"], e.get("phrase"), e.get("type")]
                                           for e in row["artists_additional"]]
                    if "year" in row:
                        t["year"] = int(row["year"] or 0)
                    if "album_id" in row:
                        old_album = STATE["albums"][t["album_id"]]
                        old_album["tracks"].remove(row["file_id"])
                        t["album_id"] = int(row["album_id"])
                        STATE["albums"][t["album_id"]]["tracks"].append(row["file_id"])
                    if "track_no" in row:
                        t["track"] = int(row["track_no"])
                return self.send(200, {"result": True})
        self.send(200, {"result": False, "message": "unknown mode"})


if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), H).serve_forever()
