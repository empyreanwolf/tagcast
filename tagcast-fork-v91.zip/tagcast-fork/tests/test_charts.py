"""Hip-hop charts (fork v20): fetchers, caching, and "Get it" routing."""

import json
import time
import unittest

from tagcast.charts import Charts, ChartsError

from test_discography import LocalStudio as DiscographyStudio
from test_discography import FakeHttp
from test_discography import wait_job
from test_galaxy import song as gd_song
from tagcast.wishlist import Wishlist


class FakeResponse:
    def __init__(self, text="", status=200):
        self.text, self.status_code = text, status

    def raise_for_status(self):
        if self.status_code >= 400:
            import requests
            raise requests.HTTPError(f"{self.status_code}")

    def json(self):
        return json.loads(self.text)


class FakeSession:
    """requests.Session() stand-in: matches by URL, keyed loosely like FakeHttp."""

    def __init__(self, answers):
        self.answers, self.headers, self.calls = answers, {}, []

    def get(self, url, headers=None, timeout=None):
        self.calls.append(url)
        for key, value in self.answers.items():
            if key in url:
                return value() if callable(value) else value
        return FakeResponse(status=404)


class LocalStudio(DiscographyStudio):
    def __init__(self, soulseek=False, http_answers=None, session_answers=None):
        super().__init__(soulseek)
        self.wishlist = Wishlist(self, scheduler=False)
        self.http = FakeHttp(dict(http_answers or {}))
        self.discography.http = self.http
        self.session = FakeSession(dict(session_answers or {}))
        self.charts = Charts(self, http=self.http, session=self.session)


def wait_progress(charts, chart_id):
    for _ in range(200):
        if not charts.progress.get(chart_id):
            return charts.jobs_view()
        time.sleep(0.02)
    raise AssertionError("charts get-others did not finish")


NETEASE_JSON = json.dumps({"result": {"tracks": [
    {"id": 501, "name": "Song One", "artists": [{"name": "Rapper A"}], "album": {"name": "Album A", "picId": 999}},
    {"id": 502, "name": "Song Two", "artists": [{"name": "Rapper B"}], "album": {"name": "Album B", "picId": 998}},
]}})

HNHH_HTML = """
<a href="/1014105-live-and-die-french-montana"><img src="x.jpg">Live and Die</a>
<a href="/artist/french-montana">French Montana</a>
<a href="/1014106-another-song-x"><img src="y.jpg">Another Song</a>
<a href="/artist/some-rapper">Some Rapper</a>
"""

DEEZER_GENRES = {"data": [{"id": 0, "name": "All"}, {"id": 116, "name": "Rap/Hip Hop"}]}
DEEZER_CHART = {"tracks": {"data": [
    {"title": "Deezer Song", "artist": {"name": "Deezer Rapper"}, "album": {"title": "Deezer Album"}},
]}}

APPLE_FEED = {"feed": {"entry": [
    {"im:name": {"label": "Apple Song"}, "im:artist": {"label": "Apple Rapper"}},
    {"im:name": {"label": ""}, "im:artist": {"label": "Skip Me"}},  # dropped: no title
]}}

NEXT_DATA_HTML = """<html><script id="__NEXT_DATA__" type="application/json">{json}</script></html>"""


def next_data_html(entries):
    return NEXT_DATA_HTML.format(json=json.dumps({"props": {"pageProps": {"chart": entries}}}))


class ChartsListViewTests(unittest.TestCase):
    def test_list_has_all_charts_grouped(self):
        studio = LocalStudio()
        charts = studio.charts.list()
        self.assertEqual(set(charts), {"netease_cn_rap", "hotnewhiphop_top100", "deezer_hiphop",
                                        "apple_hiphop", "spotify_rapcaviar", "soundcloud_hiphop", "bandcamp_hiphop"})
        self.assertEqual(charts["netease_cn_rap"]["group"], "chinese")
        self.assertEqual(charts["hotnewhiphop_top100"]["group"], "mainstream")

    def test_view_unknown_chart_raises(self):
        studio = LocalStudio()
        with self.assertRaises(Exception):
            studio.charts.view("not_a_chart")

    def test_view_caches_until_refresh(self):
        studio = LocalStudio(session_answers={"music.163.com": FakeResponse(NETEASE_JSON)})
        first = studio.charts.view("netease_cn_rap")
        self.assertEqual(len(first["rows"]), 2)
        calls = len(studio.session.calls)
        again = studio.charts.view("netease_cn_rap")
        self.assertEqual(len(studio.session.calls), calls)  # cached, no new fetch
        self.assertEqual(again["when"], first["when"])
        studio.charts.view("netease_cn_rap", refresh=True)
        self.assertEqual(len(studio.session.calls), calls + 1)


class NeteaseFetchTests(unittest.TestCase):
    def test_parses_tracks_and_carries_a_real_track_id(self):
        studio = LocalStudio(session_answers={"music.163.com": FakeResponse(NETEASE_JSON)})
        data = studio.charts.view("netease_cn_rap")
        self.assertEqual([r["title"] for r in data["rows"]], ["Song One", "Song Two"])
        row = data["rows"][0]
        self.assertEqual((row["source"], row["source_id"], row["artist"], row["rank"]), ("netease", "501", "Rapper A", 1))

    def test_empty_tracks_is_a_clean_error(self):
        studio = LocalStudio(session_answers={"music.163.com": FakeResponse(json.dumps({"result": {"tracks": []}}))})
        data = studio.charts.view("netease_cn_rap")
        self.assertEqual(data["rows"], [])
        self.assertTrue(data["error"])

    def test_bad_json_is_a_clean_error_not_a_crash(self):
        studio = LocalStudio(session_answers={"music.163.com": FakeResponse("not json")})
        data = studio.charts.view("netease_cn_rap")
        self.assertEqual(data["rows"], [])
        self.assertIn("NetEase", data["error"])

    def test_http_error_is_a_clean_error(self):
        studio = LocalStudio(session_answers={"music.163.com": FakeResponse("", status=500)})
        data = studio.charts.view("netease_cn_rap")
        self.assertEqual(data["rows"], [])
        self.assertTrue(data["error"])


class HotNewHipHopFetchTests(unittest.TestCase):
    def test_parses_title_artist_pairs_from_link_patterns(self):
        studio = LocalStudio(session_answers={"hotnewhiphop.com": FakeResponse(HNHH_HTML)})
        data = studio.charts.view("hotnewhiphop_top100")
        self.assertEqual([(r["title"], r["artist"]) for r in data["rows"]],
                          [("Live and Die", "French Montana"), ("Another Song", "Some Rapper")])
        self.assertEqual(data["rows"][0]["rank"], 1)

    def test_no_matches_is_a_clean_error(self):
        studio = LocalStudio(session_answers={"hotnewhiphop.com": FakeResponse("<html>nothing here</html>")})
        data = studio.charts.view("hotnewhiphop_top100")
        self.assertEqual(data["rows"], [])
        self.assertIn("HotNewHipHop", data["error"])


class DeezerFetchTests(unittest.TestCase):
    def test_discovers_genre_id_by_name_and_reads_its_chart(self):
        studio = LocalStudio(http_answers={"/genre": DEEZER_GENRES, "/chart/116": DEEZER_CHART})
        data = studio.charts.view("deezer_hiphop")
        self.assertEqual([(r["title"], r["artist"], r["album"]) for r in data["rows"]],
                          [("Deezer Song", "Deezer Rapper", "Deezer Album")])

    def test_no_hiphop_genre_is_a_clean_error(self):
        studio = LocalStudio(http_answers={"/genre": {"data": [{"id": 0, "name": "All"}]}})
        data = studio.charts.view("deezer_hiphop")
        self.assertEqual(data["rows"], [])
        self.assertIn("Deezer", data["error"])


class AppleFetchTests(unittest.TestCase):
    def test_parses_feed_and_skips_incomplete_entries(self):
        studio = LocalStudio(http_answers={"/topsongs/limit=100/genre=18/json": APPLE_FEED})
        data = studio.charts.view("apple_hiphop")
        self.assertEqual([(r["title"], r["artist"]) for r in data["rows"]], [("Apple Song", "Apple Rapper")])

    def test_empty_feed_is_a_clean_error(self):
        studio = LocalStudio(http_answers={"/topsongs/limit=100/genre=18/json": {"feed": {"entry": []}}})
        data = studio.charts.view("apple_hiphop")
        self.assertEqual(data["rows"], [])
        self.assertTrue(data["error"])


SPOTIFY_EMBED = {"props": {"pageProps": {"state": {"data": {"entity": {"name": "RapCaviar", "trackList": [
    {"title": "Spot Song", "subtitle": "Spot Rapper, Guest One"},
    {"title": "Second Song", "subtitle": "Other Rapper"},
    {"title": "Spot Song", "subtitle": "Spot Rapper, Guest One"}]}}}}}}


class SpotifyFetchTests(unittest.TestCase):
    def embed(self, data=SPOTIFY_EMBED):
        return FakeResponse(NEXT_DATA_HTML.format(json=json.dumps(data)))

    def test_rapcaviar_reads_the_embed_page_track_list_and_drops_duplicates(self):
        studio = LocalStudio(session_answers={"open.spotify.com/embed/playlist/37i9dQZF1DX0XUsuxWHRQd": self.embed()})
        data = studio.charts.view("spotify_rapcaviar")
        self.assertEqual([(r["rank"], r["title"], r["artist"]) for r in data["rows"]],
                         [(1, "Spot Song", "Spot Rapper; Guest One"), (2, "Second Song", "Other Rapper")])
        self.assertEqual(data["error"], "")

    def test_browse_takes_any_public_playlist_link_or_bare_id(self):
        studio = LocalStudio(session_answers={"embed/playlist/ABCDEFGHIJKLMNOPQRSTUV": self.embed()})
        for link in ("https://open.spotify.com/playlist/ABCDEFGHIJKLMNOPQRSTUV?si=xyz", "spotify:playlist:ABCDEFGHIJKLMNOPQRSTUV",
                     "ABCDEFGHIJKLMNOPQRSTUV"):
            data = studio.charts.browse_view("spotify", genre=link, refresh=True)
            self.assertEqual(len(data["rows"]), 2, link)
            self.assertEqual(data["url"], "https://open.spotify.com/playlist/ABCDEFGHIJKLMNOPQRSTUV")

    def test_a_bad_link_is_a_clean_error(self):
        with self.assertRaises(ChartsError):
            LocalStudio().charts.browse_view("spotify", genre="not a playlist")

    def test_a_private_or_changed_page_is_a_clean_error_not_a_crash(self):
        for answer in (FakeResponse(status=404), FakeResponse("<html>no data here</html>"), self.embed({"props": {}})):
            studio = LocalStudio(session_answers={"open.spotify.com": answer})
            data = studio.charts.view("spotify_rapcaviar")
            self.assertEqual(data["rows"], [])
            self.assertTrue(data["error"])

    def test_shazam_and_billboard_are_gone(self):
        studio = LocalStudio()
        self.assertNotIn("shazam", studio.charts.browse_options())
        with self.assertRaises(Exception):
            studio.charts.browse_view("shazam", country="Thailand")


class StatusAndGetTests(unittest.TestCase):
    def test_rows_are_checked_against_the_library(self):
        netease = json.dumps({"result": {"tracks": [
            {"id": 9, "name": "Yellow", "artists": [{"name": "Coldplay"}], "album": {"name": "Parachutes"}},
        ]}})
        studio = LocalStudio(session_answers={"music.163.com": FakeResponse(netease)})
        data = studio.charts.view("netease_cn_rap")
        self.assertEqual(data["rows"][0]["status"], "have")  # library already has Coldplay - Yellow

    def test_get_netease_rows_goes_straight_through_galaxy(self):
        studio = LocalStudio(session_answers={"music.163.com": FakeResponse(NETEASE_JSON)})
        studio.charts.view("netease_cn_rap")
        result = studio.charts.get("netease_cn_rap", [1, 2])
        self.assertEqual(result, {"queued": 2, "jobs": 0})
        queued_titles = {i["title"] for i in studio.download_manager.state["queue"]}
        self.assertEqual(queued_titles, {"Song One", "Song Two"})
        # explicitly tagged "netease" regardless of whatever Galaxy's own UI source is set to
        payloads = [i["payload"]["source"] for i in studio.download_manager.state["queue"]]
        self.assertEqual(set(payloads), {"netease"})

    def test_get_other_rows_runs_as_a_background_job_and_lands_on_wishlist_when_not_found(self):
        studio = LocalStudio(session_answers={"hotnewhiphop.com": FakeResponse(HNHH_HTML)})
        studio.charts.view("hotnewhiphop_top100")
        result = studio.charts.get("hotnewhiphop_top100", [1, 2])
        self.assertEqual(result, {"queued": 0, "jobs": 2})
        jobs = wait_progress(studio.charts, "hotnewhiphop_top100")
        self.assertEqual(len(jobs["jobs"]), 2)
        self.assertTrue(all(not j["source"] for j in jobs["jobs"]))
        self.assertTrue(all("on your wishlist" in j["note"] for j in jobs["jobs"]))
        self.assertEqual({i["title"] for i in studio.wishlist.view()["items"]}, {"Live and Die", "Another Song"})

    def test_get_other_rows_finds_a_song_through_galaxy_fallback(self):
        studio = LocalStudio(http_answers={"/topsongs/limit=100/genre=18/json": APPLE_FEED})
        studio.charts.view("apple_hiphop")
        studio.gd.search_results[("netease", "Apple Rapper Apple Song", 1)] = [
            gd_song(77, "Apple Song", "Apple Rapper", "Some Album")]
        studio.charts.get("apple_hiphop", [1])
        jobs = wait_progress(studio.charts, "apple_hiphop")
        self.assertEqual(jobs["jobs"][0]["source"], "Galaxy")
        self.assertEqual({i["title"] for i in studio.download_manager.state["queue"]}, {"Apple Song"})

    def test_get_with_no_rows_cached_raises(self):
        studio = LocalStudio()
        with self.assertRaises(Exception):
            studio.charts.get("netease_cn_rap", [1])

    def test_get_with_no_matching_ranks_raises(self):
        studio = LocalStudio(session_answers={"music.163.com": FakeResponse(NETEASE_JSON)})
        studio.charts.view("netease_cn_rap")
        with self.assertRaises(Exception):
            studio.charts.get("netease_cn_rap", [99])

    def test_jobs_view_keeps_most_recent_first(self):
        studio = LocalStudio(session_answers={"hotnewhiphop.com": FakeResponse(HNHH_HTML)})
        studio.charts.view("hotnewhiphop_top100")
        studio.charts.get("hotnewhiphop_top100", [1, 2])
        wait_progress(studio.charts, "hotnewhiphop_top100")
        jobs = studio.charts.jobs_view()["jobs"]
        self.assertEqual(jobs[0]["title"], "Another Song")  # rank 2 finishes after rank 1, so it's most recent


class BrowseOptionsTests(unittest.TestCase):
    def test_options_describe_each_sources_real_capability(self):
        opts = LocalStudio().charts.browse_options()
        self.assertEqual(set(opts), {"apple", "deezer", "spotify"})
        self.assertTrue(opts["apple"]["needs_country"])
        self.assertFalse(opts["apple"]["needs_genre"])
        self.assertTrue(opts["spotify"]["needs_genre"])
        self.assertFalse(opts["spotify"]["needs_country"])
        self.assertFalse(opts["deezer"]["needs_country"])
        self.assertTrue(opts["deezer"]["needs_genre"])


class BrowseAppleTests(unittest.TestCase):
    def test_any_country_code_reuses_the_hiphop_feed_shape(self):
        studio = LocalStudio(http_answers={"/topsongs/limit=100/genre=18/json": APPLE_FEED})
        data = studio.charts.browse_view("apple", country="th")
        self.assertEqual([(r["title"], r["artist"]) for r in data["rows"]], [("Apple Song", "Apple Rapper")])
        self.assertIn("TH", data["label"])
        self.assertIn("/th/", data["url"])

    def test_bad_country_code_is_a_clean_error(self):
        studio = LocalStudio()
        with self.assertRaises(Exception):
            studio.charts.browse_view("apple", country="thailand")

    def test_defaults_to_us_when_no_country_given(self):
        studio = LocalStudio(http_answers={"/topsongs/limit=100/genre=18/json": APPLE_FEED})
        data = studio.charts.browse_view("apple")
        self.assertIn("/us/", data["url"])

    def test_empty_feed_for_a_country_is_a_clean_error(self):
        studio = LocalStudio(http_answers={"/topsongs/limit=100/genre=18/json": {"feed": {"entry": []}}})
        data = studio.charts.browse_view("apple", country="zz")
        self.assertEqual(data["rows"], [])
        self.assertIn("zz", data["error"])


class BrowseDeezerTests(unittest.TestCase):
    def test_any_listed_genre_name_resolves_by_substring(self):
        genres = {"data": [{"id": 0, "name": "All"}, {"id": 132, "name": "Pop"}]}
        chart = {"tracks": {"data": [{"title": "Pop Song", "artist": {"name": "Pop Star"}, "album": {"title": "Pop Album"}}]}}
        studio = LocalStudio(http_answers={"/genre": genres, "/chart/132": chart})
        data = studio.charts.browse_view("deezer", genre="pop")
        self.assertEqual([(r["title"], r["artist"]) for r in data["rows"]], [("Pop Song", "Pop Star")])

    def test_no_genre_is_a_clean_error(self):
        studio = LocalStudio()
        with self.assertRaises(Exception):
            studio.charts.browse_view("deezer", genre="")

    def test_unknown_genre_name_lists_what_deezer_actually_has(self):
        genres = {"data": [{"id": 0, "name": "All"}, {"id": 132, "name": "Pop"}]}
        studio = LocalStudio(http_answers={"/genre": genres})
        data = studio.charts.browse_view("deezer", genre="not-a-real-genre")
        self.assertEqual(data["rows"], [])
        self.assertIn("Pop", data["error"])

    def test_country_is_never_accepted_for_deezer(self):
        # Deezer's public API has no per-country chart -- browse_options says so and the
        # spec simply ignores any country value passed for this source.
        genres = {"data": [{"id": 0, "name": "All"}, {"id": 132, "name": "Pop"}]}
        chart = {"tracks": {"data": [{"title": "Pop Song", "artist": {"name": "Pop Star"}, "album": {"title": ""}}]}}
        studio = LocalStudio(http_answers={"/genre": genres, "/chart/132": chart})
        data = studio.charts.browse_view("deezer", country="th", genre="pop")
        self.assertEqual([r["title"] for r in data["rows"]], ["Pop Song"])


class BrowseGetTests(unittest.TestCase):
    def test_get_reuses_the_same_bandcamp_soulseek_galaxy_flow_as_charts(self):
        studio = LocalStudio(http_answers={"/topsongs/limit=100/genre=18/json": APPLE_FEED})
        studio.charts.browse_view("apple", country="th")
        result = studio.charts.browse_get("apple", "th", "", [1])
        self.assertEqual(result, {"queued": 0, "jobs": 1})
        jobs = wait_progress(studio.charts, "browse:apple:th")
        self.assertEqual(len(jobs["jobs"]), 1)

    def test_get_with_nothing_browsed_yet_raises(self):
        studio = LocalStudio()
        with self.assertRaises(Exception):
            studio.charts.browse_get("apple", "th", "", [1])


if __name__ == "__main__":
    unittest.main()
