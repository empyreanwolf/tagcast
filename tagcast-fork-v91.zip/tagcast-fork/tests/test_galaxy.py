"""Galaxy (fork v11): GD Studio search, exact albums, queue, downloads, tags and artist cards."""

import json
import tempfile
import threading
import time
import unittest
from pathlib import Path

from tagcast import galaxy as gx
from tagcast.artist_cards import ArtistCards
from tagcast.galaxy import Galaxy, GalaxyError, QuotaLimiter

from test_downloads import LocalStudio as DownloadsStudio

MP3 = (Path(__file__).parent / "fixtures" / "galaxy-silence.mp3").read_bytes()
JPEG = b"\xff\xd8\xff\xe0" + b"0" * 100


def song(i, title, artist, album, source="netease"):
    return {"id": str(i), "name": title, "artist": [artist], "album": album, "pic_id": "109951", "source": source}


class FakeResponse:
    def __init__(self, status=200, body=None, content=b"", headers=None):
        self.status_code, self.content, self.headers = status, content, headers or {}
        self.text = json.dumps(body) if body is not None else ""

    def iter_content(self, size):
        for n in range(0, len(self.content), size):
            yield self.content[n:n + size]

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


class FakeGD:
    """GD Studio API answers by request type."""

    def __init__(self):
        self.calls, self.urls = [], {}
        self.search_results = {}

    def __call__(self, params, timeout):
        self.calls.append(dict(params))
        kind = params["types"]
        if kind == "search":
            key = (params["source"], params["name"], params.get("pages", 1))
            return FakeResponse(body=self.search_results.get(key, []))
        if kind == "url":
            url = self.urls.get((params["source"], params["id"], params["br"]), "")
            return FakeResponse(body={"url": url, "br": params["br"], "size": 0})
        if kind == "pic":
            return FakeResponse(body={"url": "https://img.example/cover.jpg"})
        return FakeResponse(400, {"error": "?"})


def fetch(url, **kw):
    if url.endswith(".mp3"):
        return FakeResponse(content=MP3, headers={"Content-Length": str(len(MP3))})
    if "126.net" in url or "img.example" in url:
        return FakeResponse(content=JPEG)
    return FakeResponse(404)


class FakeMB:
    """MusicBrainz answers: nothing unless a test sets one."""

    def __init__(self):
        self.answers, self.years = {}, {}

    def lookup(self, artists, title, album):
        return self.answers.get(title)

    def album_year(self, artist, album):
        return self.years.get(album, "")


class LocalStudio(DownloadsStudio):
    def __init__(self):
        super().__init__()
        self.folder = Path(tempfile.mkdtemp())
        self.download_manager.set_folder(str(self.folder))
        self.gd = FakeGD()
        limiter = QuotaLimiter(interval=0)
        self.mb = FakeMB()
        self.galaxy = Galaxy(self, api=gx.GDApi(limiter, self.gd), fetch=fetch, track_delay=0, mb=self.mb)
        self.galaxy.limiter = limiter


def wait_idle(studio, seconds=10):
    end = time.time() + seconds
    while time.time() < end:
        states = [i.get("state") for i in studio.download_manager.state["queue"]]
        if "queued" not in states and "active" not in states:
            return
        time.sleep(0.05)
    raise AssertionError(f"queue did not finish: {studio.download_manager.state['queue']}")


class HelperTests(unittest.TestCase):
    def test_accents_and_feat_do_not_hide_a_song(self):
        # v32: "JAŸ-Z" matches "JAY-Z", and a title with "(feat. X)" is also searched without it.
        self.assertTrue(gx.artist_matches("JAŸ-Z", "JAY-Z"))
        self.assertFalse(gx.artist_matches("Jay", "JAY-Z"))
        self.assertEqual(gx.plain_title("Empire State Of Mind (feat. Alicia Keys)"), "Empire State Of Mind")
        self.assertEqual(gx.plain_title("Mask Off ft. Future"), "Mask Off")
        gd = FakeGD()
        api = gx.GDApi(QuotaLimiter(interval=0), gd)
        wanted = song(5, "Empire State Of Mind", "JAŸ-Z", "The Hits Collection", "joox")
        wanted["artist"] = ["JAY-Z", "Alicia Keys"]
        gd.search_results[("joox", "Empire State Of Mind", 1)] = [
            song(4, "Empire State Of Mind (COVER)", "Someone Else", "Covers", "joox"), wanted]
        best = gx.find_song(api, ["netease", "joox"], "JAŸ-Z", "Empire State Of Mind (feat. Alicia Keys)")
        self.assertEqual((best["id"], best["source"]), ("5", "joox"))  # netease had nothing; joox did
        self.assertIsNone(gx.find_song(api, ["netease"], "JAŸ-Z", "Empire State Of Mind"))

    def test_album_found_by_song_search_when_album_search_misses(self):
        # v32: the API's album search lists nothing; the site's song search shows the album.
        gd = FakeGD()
        api = gx.GDApi(QuotaLimiter(interval=0), gd)
        gd.search_results[("netease", "Heavy Lies the Crown", 1)] = [
            song(i, t, "While You Were Gone", "Heavy Lies the Crown")
            for i, t in enumerate(["Sinner", "Waiting", "Learn To Fight", "Heavy Lies The Crown", "Thief"], 1)] + [
            song(9, "Heavy Lies the Crown", "Other Band", "")]  # a loose single never counts as the album
        tracks, name = gx.fetch_album_exact(api, "netease", "Heavy Lies the Crown")
        self.assertEqual((len(tracks), name), (5, "Heavy Lies the Crown"))
        tracks, _ = gx.fetch_album_exact(api, "netease", "Heavy Lies the Crown", "While You Were Gone")
        self.assertEqual(len(tracks), 5)
        self.assertEqual(gx.fetch_album_exact(api, "netease", "Heavy Lies the Crown", "Someone Else"), ([], ""))

    def test_paths_and_names(self):
        self.assertEqual(gx.build_path("D:/M", "AC/DC", "Back: in Black", 1, "Hells Bells?").as_posix(),
                         "D:/M/ACDC/Back in Black/01 - Hells Bells.mp3")
        self.assertEqual(gx.safe_name("CON"), "_CON")
        self.assertEqual(gx.normalize_track({"id": 1, "name": "A &amp; B", "artist": "X / Y、Z"}, "joox")["artists"],
                         ["X", "Y", "Z"])

    def test_format_detection(self):
        path = Path(tempfile.mkdtemp()) / "a.part"
        path.write_bytes(MP3)
        self.assertEqual(gx.detect_audio_format(path), "mp3")
        path.write_bytes(b"fLaC" + b"0" * 20)
        self.assertEqual(gx.detect_audio_format(path), "flac")
        path.write_bytes(b"<html>")
        with self.assertRaises(ValueError):
            gx.detect_audio_format(path)

    def test_quota_holds_the_46th_call(self):
        now = [0.0]
        limiter = QuotaLimiter(interval=0, max_calls=3, period=300, reserve=1, clock=lambda: now[0])
        slept = []

        def fake_sleep(secs):
            slept.append(secs)
            now[0] += secs
        gx._tls.sleep = fake_sleep
        try:
            for _ in range(3):
                limiter.wait()
            self.assertEqual(limiter.status()["used"], 3)
            limiter.wait()  # the 4th has to wait for the first slot to free up
            self.assertGreaterEqual(now[0], 300)
        finally:
            gx._tls.sleep = None

    def test_netease_cover_url_needs_no_api_call(self):
        self.assertTrue(gx.netease_pic_url("109951163", 500).startswith("https://p3.music.126.net/"))
        self.assertEqual(gx.netease_pic_url("abc", 500), "")


class SearchTests(unittest.TestCase):
    def setUp(self):
        self.studio = LocalStudio()
        self.gd = self.studio.gd

    def test_exact_album_only(self):
        self.gd.search_results[("netease_album", "Parachutes", 1)] = [
            song(1, "Don't Panic", "Coldplay", "Parachutes"), song(2, "Yellow", "Coldplay", "Parachutes")]
        data = self.studio.galaxy.album("Parachutes", "Coldplay")
        self.assertTrue(data["found"])
        self.assertEqual([(t["title"], t["track_no"], t["status"]) for t in data["tracks"]],
                         [("Don't Panic", 1, "new"), ("Yellow", 2, "have")])
        self.assertIn("Coldplay/Parachutes/02 - Yellow", data["tracks"][1]["path"].replace("\\", "/"))
        # Only another edition: skipped, never swapped in.
        self.gd.search_results[("netease_album", "Funcrusher", 1)] = [song(3, "Blind", "Company Flow", "Funcrusher Plus")]
        self.assertFalse(self.studio.galaxy.album("Funcrusher", "Company Flow")["found"])

    def test_exact_title_by_a_different_artist_is_skipped_not_substituted(self):
        # Another, unrelated artist's album can share the exact same title ("Intro").
        # Fetching "Moka Only"'s "Intro" must never silently return this other artist's
        # songs just because it's the only (or biggest) exact-titled match (fork v29 bug fix).
        self.gd.search_results[("netease_album", "Intro", 1)] = [
            song(1, "Opener", "Travis Roig", "Intro"), song(2, "Preface", "Travis Roig", "Intro")]
        self.assertFalse(self.studio.galaxy.album("Intro", "Moka Only")["found"])

    def test_artist_search_keeps_credited_songs(self):
        self.gd.search_results[("netease", "Coldplay", 1)] = [
            song(1, "Yellow", "Coldplay", "Parachutes"), song(2, "Clocks", "Coldplay", "A Rush of Blood"),
            song(3, "Yellow", "Coldplay", "Parachutes"), song(4, "Cover", "Someone", "Tribute")]
        data = self.studio.galaxy.search("artist", "Coldplay", "netease")
        self.assertEqual([t["title"] for t in data["tracks"]], ["Yellow", "Clocks"])
        self.assertEqual({a["name"] for a in data["albums"]}, {"Parachutes", "A Rush of Blood"})

    def test_bad_input(self):
        with self.assertRaises(GalaxyError):
            self.studio.galaxy.search("artist", "", "netease")
        with self.assertRaises(GalaxyError):
            self.studio.galaxy.search("artist", "x", "napster")


class DownloadTests(unittest.TestCase):
    def setUp(self):
        self.studio = LocalStudio()
        self.gd = self.studio.gd
        self.manager = self.studio.download_manager

    def track(self, i, title, artist="Coldplay", album="Ghost Stories", n=None):
        return {"id": str(i), "title": title, "artists": [artist], "album": album, "pic_id": "109951",
                "source": "netease", "track_no": n}

    def test_album_download_queues_missing_and_holds_owned(self):
        self.gd.urls[("netease", "1", 320)] = "https://cdn.example/1.mp3"
        result = self.studio.galaxy.add([self.track(1, "Magic", n=1), self.track(2, "Yellow", album="Parachutes", n=2)],
                                        album_artist="Coldplay", total=9)
        self.assertEqual((result["queued"], result["held"]), (1, 1))
        wait_idle(self.studio)
        done = next(i for i in self.manager.state["queue"] if i["title"] == "Magic")
        self.assertEqual(done["state"], "done", done.get("note"))
        path = Path(done["path"])
        self.assertEqual(path.relative_to(self.studio.folder).as_posix(), "Coldplay/Ghost Stories/01 - Magic.mp3")
        from mutagen.id3 import ID3
        tags = ID3(str(path))
        self.assertEqual(str(tags["TIT2"]), "Magic")
        self.assertEqual(str(tags["TRCK"]), "1/9")
        self.assertEqual(str(tags["TPE2"]), "Coldplay")
        self.assertEqual(tags["APIC:Cover"].mime, "image/jpeg")
        self.assertFalse((self.studio.folder / "_incomplete").exists())
        # It is now in the history, so the same song is held next time, and so is a file in the folder.
        self.assertEqual(self.manager.check([{"kind": "song", "artist": "Coldplay", "title": "Magic"}])["results"][0]["status"],
                         "downloaded")
        self.assertEqual(self.studio.galaxy.add([self.track(9, "Magic", n=1)], "Coldplay")["held"], 1)

    def test_fallbacks_and_failures(self):
        # No 320 link: 128 is used.
        self.gd.urls[("netease", "1", 128)] = "https://cdn.example/1.mp3"
        # No link on netease at all: joox has the same song.
        self.gd.search_results[("joox", "Coldplay Midnight", 1)] = [song(77, "Midnight", "Coldplay", "Ghost Stories", "joox")]
        self.gd.urls[("joox", "77", 320)] = "https://cdn.example/77.mp3"
        # Nothing anywhere.
        self.studio.galaxy.add([self.track(1, "Magic"), self.track(2, "Midnight"), self.track(3, "Ink")])
        wait_idle(self.studio)
        states = {i["title"]: (i["state"], i.get("note", "")) for i in self.manager.state["queue"]}
        self.assertEqual(states["Magic"][0], "done")
        self.assertEqual(states["Midnight"][0], "done")
        self.assertEqual(states["Ink"][0], "failed")
        self.assertIn("No download link", states["Ink"][1])
        # Retry failed puts it back in the queue; a link now exists.
        self.gd.urls[("netease", "3", 320)] = "https://cdn.example/3.mp3"
        self.studio.galaxy.control("retry")
        wait_idle(self.studio)
        self.assertEqual(next(i for i in self.manager.state["queue"] if i["title"] == "Ink")["state"], "done")

    def test_previews_are_rejected(self):
        # The API announces a 5 MB song at 320 kbps (~130 s), but only 40 s arrives.
        self.gd.urls[("netease", "1", 320)] = "https://cdn.example/1.mp3"
        api = self.gd

        def big(params, timeout):
            r = api(params, timeout)
            if params["types"] == "url" and params["br"] == 320:
                r.text = json.dumps({"url": "https://cdn.example/1.mp3", "br": 320, "size": 5_000_000})
            return r
        self.studio.galaxy.api.get = big
        self.studio.galaxy.add([self.track(1, "Magic")])
        wait_idle(self.studio)
        item = self.manager.state["queue"][0]
        self.assertEqual(item["state"], "failed")
        self.assertIn("Preview only", item["note"])

    def _short_file(self, seconds=32.0):
        """Every download reads as a whole file this many seconds long (the fixture is 40 s)."""
        from unittest import mock
        self.gd.urls[("netease", "1", 320)] = "https://cdn.example/1.mp3"
        patcher = mock.patch.object(gx, "read_duration", return_value=(seconds, 320))
        patcher.start()
        self.addCleanup(patcher.stop)

    @staticmethod
    def _mb(length_s):
        return {"year": "2021", "track_no": 1, "track_total": 12, "genre": "Hip Hop", "recording_id": "r",
                "release_id": "l", "release_title": "Ghost Stories", "length_s": length_s}

    def test_short_track_kept_when_musicbrainz_agrees(self):
        # v31: a 32 s intro is not a preview just for being short.
        self._short_file(32.0)
        self.studio.mb.answers["Magic"] = self._mb(33.0)
        self.studio.galaxy.add([self.track(1, "Magic")])
        wait_idle(self.studio)
        item = self.manager.state["queue"][0]
        self.assertEqual(item["state"], "done", item.get("note"))

    def test_short_file_of_a_long_song_is_a_preview(self):
        self._short_file(30.0)
        self.studio.mb.answers["Magic"] = self._mb(192.0)
        self.studio.galaxy.add([self.track(1, "Magic")])
        wait_idle(self.studio)
        item = self.manager.state["queue"][0]
        self.assertEqual(item["state"], "failed")
        self.assertIn("Preview only", item["note"])
        self.assertIn("3:12", item["note"])
        self.assertNotIn("short_seconds", item)  # no "Keep it" button for a known preview

    def test_unknown_short_track_can_be_kept(self):
        self._short_file(32.0)  # MusicBrainz knows nothing about it
        self.studio.galaxy.add([self.track(1, "Magic")])
        wait_idle(self.studio)
        item = self.manager.state["queue"][0]
        self.assertEqual(item["state"], "failed")
        self.assertEqual(item.get("short_seconds"), 32)
        self.assertIn("Keep it", item["note"])
        # A plain Retry asks again; "Keep it (short track)" saves it.
        self.studio.galaxy.control("retry", [item["id"]])
        wait_idle(self.studio)
        self.assertEqual(self.manager.state["queue"][0]["state"], "failed")
        self.studio.galaxy.control("allow_short", [item["id"]])
        wait_idle(self.studio)
        item = self.manager.state["queue"][0]
        self.assertEqual(item["state"], "done", item.get("note"))
        self.assertTrue(item["payload"]["allow_short"])
        self.assertNotIn("short_seconds", item)

    def test_pause_top_and_clear(self):
        self.studio.galaxy.control("pause")
        self.studio.galaxy.add([self.track(1, "A"), self.track(2, "B"), self.track(3, "C")])
        ids = [i["id"] for i in self.manager.state["queue"]]
        self.studio.galaxy.control("top", [ids[2]])
        self.assertEqual([i["title"] for i in self.manager.state["queue"]], ["C", "A", "B"])
        time.sleep(0.3)
        self.assertTrue(all(i["state"] == "queued" for i in self.manager.state["queue"]))  # paused
        self.studio.galaxy.control("clear_waiting")
        self.assertEqual(self.manager.state["queue"], [])
        self.assertTrue(self.studio.galaxy.status()["paused"])

    def test_download_anyway_starts_the_download(self):
        self.gd.urls[("netease", "2", 320)] = "https://cdn.example/2.mp3"
        self.studio.galaxy.add([self.track(2, "Yellow", album="Parachutes")])
        held = self.manager.queue_view()["held"]
        self.assertEqual(len(held), 1)
        self.manager.decide([held[0]["id"]], "download")
        wait_idle(self.studio)
        self.assertEqual(self.manager.state["queue"][0]["state"], "done")


class MusicBrainzTests(unittest.TestCase):
    def test_lookup_picks_the_matching_release(self):
        recording = {"id": "rec-1", "title": "Magic", "score": 100, "first-release-date": "2014-03-03",
                     "artist-credit": [{"name": "Coldplay"}],
                     "releases": [{"id": "rel-live", "title": "Live 2014", "date": "2014-11-17", "status": "Official",
                                   "media": [{"track-count": 12, "track": [{"number": "3"}]}]},
                                  {"id": "rel-1", "title": "Ghost Stories", "date": "2014-05-16", "status": "Official",
                                   "release-group": {"id": "rg-1"},
                                   "media": [{"track-count": 9, "track": [{"number": "2"}]}]}]}

        class Http:
            def json(self, url, params=None, ttl=None):
                if url.endswith("/recording"):
                    return {"recordings": [recording, {"title": "Magic", "artist-credit": [{"name": "Other"}]}]}
                if url.endswith("/rec-1"):
                    return {"genres": [{"name": "alternative rock", "count": 3}, {"name": "pop", "count": 1}]}
                if url.endswith("/release"):
                    return {"releases": [{"title": "Ghost Stories", "date": "2014-05-16"},
                                         {"title": "Ghost Stories", "date": "2015-01-01"}]}
                return None
        mb = gx.MusicBrainz(Http())
        info = mb.lookup(["Coldplay"], "Magic", "Ghost Stories")
        self.assertEqual((info["release_id"], info["year"], info["track_no"], info["track_total"], info["genre"]),
                         ("rel-1", "2014", 2, 9, "Alternative Rock"))
        self.assertIsNone(mb.lookup(["Nobody"], "Magic", "Ghost Stories"))
        self.assertEqual(mb.album_year("Coldplay", "Ghost Stories"), "2014")

    def test_download_gets_year_genre_numbers_and_ids(self):
        studio = LocalStudio()
        studio.gd.urls[("netease", "1", 320)] = "https://cdn.example/1.mp3"
        studio.gd.urls[("netease", "2", 320)] = "https://cdn.example/2.mp3"
        info = {"year": "2014", "genre": "Alternative Rock", "track_no": 2, "track_total": 9,
                "recording_id": "rec-1", "release_id": "rel-1", "release_title": "Ghost Stories"}
        studio.mb.answers = {"Magic": info, "Midnight": dict(info, track_no=5)}
        song_ = lambda i, t, n=None: {"id": str(i), "title": t, "artists": ["Coldplay"], "album": "Ghost Stories",
                                      "source": "netease", "pic_id": "", "track_no": n}
        studio.galaxy.add([song_(1, "Magic")])                       # a single song: MusicBrainz numbers it
        studio.galaxy.add([song_(2, "Midnight", 7)], "Coldplay", 9)  # from a full album: its number stays
        wait_idle(studio)
        from mutagen.id3 import ID3
        items = {i["title"]: i for i in studio.download_manager.state["queue"]}
        magic = ID3(items["Magic"]["path"])
        self.assertEqual((str(magic["TDRC"]), str(magic["TCON"]), str(magic["TRCK"])), ("2014", "Alternative Rock", "2/9"))
        self.assertEqual(str(magic["TXXX:MusicBrainz Album Id"]), "rel-1")
        self.assertTrue(items["Magic"]["path"].replace("\\", "/").endswith("Ghost Stories/02 - Magic.mp3"))
        self.assertEqual(str(ID3(items["Midnight"]["path"])["TRCK"]), "7/9")
        self.assertTrue(items["Midnight"]["note"].startswith("Saved · no cover"))

    def test_no_match_still_saves(self):
        studio = LocalStudio()
        studio.gd.urls[("netease", "1", 320)] = "https://cdn.example/1.mp3"
        studio.galaxy.add([{"id": "1", "title": "Ink", "artists": ["Coldplay"], "album": "Ghost Stories", "source": "netease"}])
        wait_idle(studio)
        self.assertEqual(studio.download_manager.state["queue"][0]["state"], "done")
        self.assertIn("year/genre missing", studio.download_manager.state["queue"][0]["note"])

    def test_album_years_and_settings(self):
        studio = LocalStudio()
        studio.mb.years = {"Ghost Stories": "2014"}
        self.assertEqual(studio.galaxy.album_years("Coldplay", ["Ghost Stories", "Unknown Album", "X"])["years"],
                         {"Ghost Stories": "2014", "X": ""})
        status = studio.galaxy.save_settings({"track_delay": 10, "api_delay": "2.5", "api_quota": 30})
        self.assertEqual(status["settings"], {"track_delay": 10.0, "api_delay": 2.5, "api_quota": 30})
        self.assertEqual((studio.galaxy.limiter.max_calls, studio.galaxy.limiter.interval, studio.galaxy.track_delay),
                         (30, 2.5, 10.0))
        for bad in ({"api_quota": 60}, {"track_delay": -1}, {"api_delay": "x"}):
            with self.assertRaises(GalaxyError):
                studio.galaxy.save_settings(bad)
        again = Galaxy(studio, api=studio.galaxy.api, fetch=fetch, mb=studio.mb)
        self.assertEqual(again.settings()["api_quota"], 30)


class CoverTests(unittest.TestCase):
    def test_covers_are_cached_and_netease_needs_no_api_call(self):
        studio = LocalStudio()
        studio.home = tempfile.mkdtemp()
        g = studio.galaxy
        self.assertEqual(g.thumbnail("netease", "109951", 300), JPEG)
        self.assertEqual([c for c in studio.gd.calls if c["types"] == "pic"], [])
        g.fetch = lambda url, **kw: FakeResponse(500)  # cached on disk: no new download
        self.assertEqual(g.thumbnail("netease", "109951", 300), JPEG)
        # joox needs one low-priority API call; a missing cover is not asked for again.
        self.assertIsNone(g.thumbnail("joox", "abc", 300))
        calls = len(studio.gd.calls)
        self.assertIsNone(g.thumbnail("joox", "abc", 300))
        self.assertEqual(len(studio.gd.calls), calls)
        with self.assertRaises(GalaxyError):
            g.thumbnail("netease", "../etc", 300)


class FakeHttp:
    def __init__(self, answers):
        self.answers, self.calls = answers, []

    def json(self, url, params=None, **kw):
        self.calls.append(url)
        for key, value in self.answers.items():
            if url.endswith(key):
                return value
        return None


class ArtistCardTests(unittest.TestCase):
    def answers(self):
        return {
            "/ws/2/artist": {"artists": [
                {"id": "mb-1", "name": "Lotus", "disambiguation": "US electronic jam band", "country": "US",
                 "life-span": {"begin": "1999"}},
                {"id": "mb-2", "name": "Lotus", "disambiguation": "Swedish rock band", "country": "SE"},
                {"id": "mb-3", "name": "Lotus Eaters"}]},
            "/ws/2/release-group": {"release-groups": []},
            "/search/artist": {"data": [{"id": 11, "name": "Lotus", "nb_fan": 900, "nb_album": 30, "picture_medium": "p"},
                                        {"id": 12, "name": "LOTUS", "nb_fan": 5, "nb_album": 2}]},
        }

    def test_cards_and_which_artist(self):
        studio = DownloadsStudio()
        http = FakeHttp(self.answers())
        albums = {"mb-1": ["Nomad", "Hammerstrike"], "mb-2": ["Lotus II"]}
        dz = {11: ["Nomad", "Hammerstrike", "Spiral"], 12: ["Something Else"]}
        orig = http.json

        def json_(url, params=None, **kw):
            if url.endswith("/release-group"):
                return {"release-groups": [{"title": t} for t in albums[params["artist"]]]}
            if "/artist/" in url and url.endswith("/albums"):
                return {"data": [{"title": t} for t in dz[int(url.split("/")[-2])]]}
            return orig(url, params)
        http.json = json_
        cards = ArtistCards(studio, http)
        data = cards.cards_for("Lotus", ["Nomad", "Lotus II", "Unknown Thing"], {})
        ids = [c["id"] for c in data["cards"]]
        self.assertEqual(ids, ["mb:mb-1", "mb:mb-2", "dz:12"])  # Deezer 11 merged into mb-1 (same albums)
        self.assertEqual(data["cards"][0]["fans"], 900)
        self.assertEqual(data["cards"][0]["description"], "US electronic jam band")
        self.assertEqual(data["assign"], {"Nomad": "mb:mb-1", "Lotus II": "mb:mb-2", "Unknown Thing": "unsure"})
        # A remembered pick decides "Which artist?".
        picks = {f"{'lotus'}|{'unknown thing'}": "mb:mb-2"}
        self.assertEqual(cards.cards_for("Lotus", ["Unknown Thing"], picks)["assign"]["Unknown Thing"], "mb:mb-2")
        # Cached: no new requests.
        before = len(http.calls)
        cards.cards_for("LOTUS", ["Nomad"], {})
        self.assertEqual(len(http.calls), before)


if __name__ == "__main__":
    unittest.main()


class SameNamedSinglesTests(unittest.TestCase):
    def test_other_artists_singles_with_the_same_name_are_not_queued(self):
        from tagcast.galaxy import fetch_album_exact

        def track(i, artist):
            return {"id": str(i), "source": "netease", "title": "I Don't Care", "artists": [artist],
                    "album": "I Don't Care", "pic_id": ""}

        class Api:
            def search(self, source, q, count, page):
                return [track(1, "Darassa"), track(2, "Nick Leway"), track(3, "Ed Sheeran")] if page == 1 else []

        tracks, _ = fetch_album_exact(Api(), "netease", "I Don't Care", "Ed Sheeran")
        self.assertEqual([t["artists"][0] for t in tracks], ["Ed Sheeran"])
        tracks, _ = fetch_album_exact(Api(), "netease", "I Don't Care", None)
        self.assertEqual(len(tracks), 1)


class LyricsDownloadTests(unittest.TestCase):
    """Fork v79: the downloaded song carries its timed lyrics (credit lines removed)."""

    class Api:
        def __init__(self, text=None, error=None):
            self.text, self.error, self.calls = text, error, []

        def lyric(self, source, lyric_id, low=True):
            self.calls.append((source, lyric_id))
            if self.error:
                raise self.error
            return self.text

    def run_fetch(self, api, link, payload):
        from types import SimpleNamespace
        return Galaxy.fetch_lyrics(SimpleNamespace(api=api), link, payload)

    def test_credit_lines_are_removed_and_the_lyric_id_is_used(self):
        api = self.Api("[00:00.00] 作词 : A\n[00:36.1]前尘往事成云烟\n[00:39.0]消散在彼此眼前\n[04:57.09] 吉他 : B")
        text = self.run_fetch(api, {"source": "netease", "id": "5"}, {"source": "netease", "id": "5", "lyric_id": "77"})
        self.assertEqual(text, "[00:36.1]前尘往事成云烟\n[00:39.0]消散在彼此眼前\n")
        self.assertEqual(api.calls, [("netease", "77")])

    def test_another_source_uses_its_own_id_and_failures_or_empty_text_give_nothing(self):
        api = self.Api("[00:01.0]a\n[00:02.0]b")
        self.run_fetch(api, {"source": "joox", "id": "9"}, {"source": "netease", "id": "5", "lyric_id": "77"})
        self.assertEqual(api.calls, [("joox", "9")])
        self.assertEqual(self.run_fetch(self.Api(""), {"source": "netease", "id": "1"}, {"source": "netease", "id": "1"}), "")
        self.assertEqual(self.run_fetch(self.Api("[00:01.0]one line"), {"source": "netease", "id": "1"}, {"source": "netease", "id": "1"}), "")
        self.assertEqual(self.run_fetch(self.Api(error=RuntimeError("down")), {"source": "netease", "id": "1"}, {"source": "netease", "id": "1"}), "")

    def test_lrclib_comes_first_and_saves_the_gd_studio_call(self):
        # Fork v83: LRCLIB is outside the GD Studio quota; GD Studio only when LRCLIB has nothing.
        from types import SimpleNamespace

        def answer(body, status=200):
            r = FakeResponse(status)
            r.json = lambda: body
            return r

        seen = []

        def fetch(url, params=None, **kw):
            seen.append((url.rsplit("/", 1)[-1], dict(params or {})))
            return answer(lrclib_body)

        payload = {"source": "netease", "id": "5", "artists": ["Army of the Pharaohs · Jedi Mind Tricks"], "album": "X"}
        link = {"source": "netease", "id": "5"}
        lrclib_body = {"syncedLyrics": "[00:01.0]a\n[00:02.0]b", "duration": 200}
        api = self.Api("[00:01.0]gd\n[00:02.0]gd")
        text = Galaxy.fetch_lyrics(SimpleNamespace(api=api, fetch=fetch), link, payload, "Song feat. Someone", 201)
        self.assertEqual((text, api.calls), ("[00:01.0]a\n[00:02.0]b\n", []))
        self.assertEqual(seen[0][1]["artist_name"], "Army of the Pharaohs")
        self.assertEqual(seen[0][1]["track_name"], "Song")
        lrclib_body = {"instrumental": True, "duration": 200}  # instrumental: no lyrics, no GD call either
        self.assertEqual(Galaxy.fetch_lyrics(SimpleNamespace(api=api, fetch=fetch), link, payload, "Song", 200), "")
        self.assertEqual(api.calls, [])
        lrclib_body = {"syncedLyrics": "[00:01.0]a\n[00:02.0]b", "duration": 120}  # wrong length: GD Studio decides
        self.assertEqual(Galaxy.fetch_lyrics(SimpleNamespace(api=api, fetch=fetch), link, payload, "Song", 200),
                         "[00:01.0]gd\n[00:02.0]gd\n")
        self.assertEqual(api.calls, [("netease", "5")])

    def test_lyrics_go_into_the_tags_of_every_format(self):
        try:
            from mutagen.id3 import ID3
        except ImportError:
            self.skipTest("mutagen is not installed")
        import tempfile
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "a.mp3"
            path.write_bytes(b"\xff\xfb\x90\x00" + b"\x00" * 400)
            gx.write_tags(path, "mp3", title="T", artists=["A"], album_artist="A", album="B", track_no=1, track_total=1,
                          lyrics="[00:01.0]hello\n")
            self.assertIn("hello", ID3(str(path)).getall("USLT")[0].text)


class V84Tests(unittest.TestCase):
    """Fork v84: one MusicBrainz lookup per album; the API quota survives a restart."""

    def test_second_song_of_an_album_needs_no_musicbrainz_call(self):
        calls = []
        rec = {"id": "r1", "title": "One", "score": 100, "length": 200000,
               "artist-credit": [{"name": "Band"}],
               "releases": [{"id": "rel1", "title": "Album", "status": "Official", "date": "2001-05-01",
                             "media": [{"track-count": 2, "track": [{"number": "1"}]}]}]}
        release = {"media": [{"track-count": 2, "tracks": [
            {"number": "1", "title": "One", "length": 200000, "recording": {"id": "r1"}},
            {"number": "2", "title": "Two", "length": 180000, "recording": {"id": "r2"}}]}]}

        class Http:
            def json(self, url, params=None, ttl=None):
                calls.append(url.rsplit("/ws/2/", 1)[-1])
                if url.endswith("/recording"):
                    return {"recordings": [rec]}
                if "/release/" in url:
                    return release
                return {}

        mb = gx.MusicBrainz(Http())
        first = mb.lookup(["Band"], "One", "Album")
        self.assertEqual((first["track_no"], first["year"]), (1, "2001"))
        self.assertNotIn("album_sim", first)
        before = len(calls)
        second = mb.lookup(["Band"], "Two (feat. Guest)", "Album")
        self.assertEqual(len(calls), before)  # no call at all
        self.assertEqual((second["track_no"], second["track_total"], second["recording_id"], second["year"]), (2, 2, "r2", "2001"))

    def test_quota_is_saved_and_loaded_with_wall_clock_times(self):
        mono, wall = [1000.0], [5000.0]
        a = QuotaLimiter(interval=0, clock=lambda: mono[0])
        for _ in range(3):
            a.wait()
        a.penalize(60)
        data = a.export(wall=lambda: wall[0])
        mono2 = [10.0]  # the program restarted: monotonic time starts again
        b = QuotaLimiter(interval=0, clock=lambda: mono2[0])
        b.load(data, wall=lambda: wall[0] + 20)  # 20 s later
        status = b.status()
        self.assertEqual(status["used"], 3)
        self.assertTrue(35 <= status["wait"] <= 41)  # the 60 s block has ~40 s left
        b.load({"calls": [wall[0] - 400]}, wall=lambda: wall[0])  # older than 5 minutes: forgotten
        self.assertEqual(b.status()["used"], 0)


class V90PrefetchTests(unittest.TestCase):
    """Fork v90: the next song's MusicBrainz match and cover are looked up while the current one downloads."""

    def test_next_song_is_looked_up_during_the_current_download(self):
        studio = LocalStudio()
        for i in (1, 2):
            studio.gd.urls[("netease", str(i), 320)] = f"https://cdn.example/{i}.mp3"
        galaxy = studio.galaxy
        real_lookup, real_download = galaxy.mb.lookup, galaxy.download
        second_looked_up, waited, order = threading.Event(), [], []

        def lookup(artists, title, album):
            order.append(title)
            if title == "Midnight":
                second_looked_up.set()
            return real_lookup(artists, title, album)

        def download(jid, url, part):
            if url.endswith("/1.mp3"):  # the first song is held until the second one has been looked up
                waited.append(second_looked_up.wait(5))
            return real_download(jid, url, part)
        galaxy.mb.lookup, galaxy.download = lookup, download
        galaxy.add([{"id": "1", "title": "Magic", "artists": ["Coldplay"], "album": "Ghost Stories", "pic_id": "109951",
                     "source": "netease", "track_no": 1},
                    {"id": "2", "title": "Midnight", "artists": ["Coldplay"], "album": "Ghost Stories", "pic_id": "109951",
                     "source": "netease", "track_no": 2}], album_artist="Coldplay", total=9)
        wait_idle(studio)
        self.assertEqual(waited, [True])
        self.assertEqual(sorted(order), ["Magic", "Midnight"])  # each song is looked up once, not twice
        states = {i["title"]: i["state"] for i in studio.download_manager.state["queue"]}
        self.assertEqual(states, {"Magic": "done", "Midnight": "done"})
        self.assertEqual(galaxy._pre, {})  # nothing is left behind
