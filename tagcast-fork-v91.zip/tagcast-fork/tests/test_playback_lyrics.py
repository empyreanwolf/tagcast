"""Synthetic display fixtures only: no public lyrics, real account or audio requests."""

import copy
import json
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import Mock, patch

import requests
import test_lyrics
import yaml

from tagcast import playback_lyrics
from tagcast.library import ConflictError, LibraryError
from tagcast.playback_lyrics import (
    _lrclib_lines,
    _lrclib_match,
    fetch_lrclib_display,
    fetch_unison,
    lyric_time,
    lyrics_title,
    parse_lrc,
    parse_ttml,
)
from tagcast.sources import SourceError


class TimedLyricsTests(unittest.TestCase):
    def test_clock_and_offset_times_are_bounded(self):
        for value, expected in (("01:02.25", 62.25), ("1:02:03", 3723),
                                ("500ms", .5), ("1.5m", 90), ("2h", 7200)):
            self.assertEqual(lyric_time(value), expected)
        for value in (None, "NaN", "-1s", "01:99", "25h", "3f", "10t"):
            self.assertIsNone(lyric_time(value))

    def test_lrc_offsets_repeated_lines_word_markers_and_instrumental_breaks(self):
        result = parse_lrc("[ar:Synthetic]\n[re:Test]\n[offset:500]\n"
                           "[00:01.00][00:05.00]<00:01.00>First <00:01.50>line\n"
                           "[00:03.00]\n[00:07.00]Last line", 10)
        self.assertTrue(result["timed"])
        self.assertEqual([line["start"] for line in result["lines"]], [.5, 2.5, 4.5, 6.5])
        self.assertEqual(result["lines"][0]["text"], "First line")
        self.assertEqual(result["lines"][1]["text"], "")
        self.assertEqual(result["lines"][0]["end"], 2.5)
        self.assertEqual(result["lines"][0]["words"], [
            {"start": .5, "end": 1, "text": "First "},
            {"start": 1, "end": 2.5, "text": "line"}])
        self.assertEqual(result["lines"][2]["words"][0]["start"], 4.5)
        self.assertEqual(parse_lrc('[offset:-500]\n[00:01]Later', 10)['lines'][0]['start'], 1.5)
        self.assertEqual(parse_lrc('[offset:2000]\n[00:01]<00:01>Early<00:03>', 10)['lines'][0],
                         {'start': 0, 'end': 10, 'text': 'Early', 'words': [{'start': 0, 'end': 1, 'text': 'Early'}]})

    def test_modern_unison_ttml_uses_containment_not_namespace_spelling(self):
        for namespace in ('http://music.apple.com/lyric-ttml-internal',
                          'https://composer.betterlyrics.org/ttml', 'urn:synthetic'):
            value = ('<tt xmlns="http://www.w3.org/ns/ttml" xmlns:source="' + namespace + '">'
                     '<body><div><p begin="0:00.641" end="0:02.956">'
                     '<span begin="0:00.641" end="0:01.681">Synthetic</span> '
                     '<span begin="0:01.681" end="0:02.956">words</span></p></div></body></tt>')
            result = parse_ttml(value, 10)
            self.assertEqual(result['lines'][0]['words'], [
                {'text': 'Synthetic ', 'start': .641, 'end': 1.681},
                {'text': 'words', 'start': 1.681, 'end': 2.956}])

    def test_ttml_prefers_absolute_when_both_readings_fit_and_rejects_bad_lines(self):
        value = '<tt><div><p begin="1s" end="10s"><span begin="2s" end="3s">Synthetic</span></p></div></tt>'
        self.assertEqual(parse_ttml(value, 20)['lines'][0]['words'][0]['start'], 2)
        for value in ('<tt><div begin="20s" end="21s"><p begin="2s" end="4s">Outside</p></div></tt>',
                      '<tt><p begin="1s" end="30s">Past recording</p></tt>',
                      '<tt><div begin="NaN"><p begin="1s">Unknown container</p></div></tt>'):
            with self.assertRaises(SourceError):
                parse_ttml(value, 25)

    def test_ttml_apple_absolute_song_times_and_plain_text(self):
        value = ('<tt xmlns="http://www.w3.org/ns/ttml" '
                 'xmlns:itunes="http://itunes.apple.com/lyric-ttml-extensions" itunes:timing="Word">'
                 '<body><div begin="10s"><p begin="10s" end="12s">'
                 '<span begin="10s" end="11s">First </span><span begin="11s">line &amp; more</span>'
                 '</p><p begin="15s" end="18s">Next line</p></div></body></tt>')
        result = parse_ttml(value, 20)
        self.assertEqual(result["lines"][0], {"start": 10, "end": 12, "text": "First line & more",
            "words": [{"start": 10, "end": 11, "text": "First "},
                      {"start": 11, "end": 12, "text": "line & more"}]})
        self.assertTrue(result["timed"])
        self.assertFalse(parse_ttml('<tt><body><p>Plain line</p></body></tt>', 20)["timed"])

    def test_ttml_relative_times_and_duration(self):
        result = parse_ttml('<tt><body><div begin="20s"><p begin="1s" dur="2s">'
                            'Relative line</p></div></body></tt>', 30)
        self.assertEqual(result["lines"][0], {"start": 21, "end": 23, "text": "Relative line"})

    def test_ttml_breaks_and_equal_timestamps_keep_complete_lines(self):
        result = parse_ttml('<tt><p begin="1s">First<br/>Second</p>'
                            '<p begin="1s">Duet</p><p begin="3s">Ending</p></tt>', 10)
        self.assertEqual(result['lines'][0]['text'], 'First\nSecond')
        self.assertEqual([line['end'] for line in result['lines']], [3, 3, 10])
        with self.assertRaises(SourceError):
            parse_ttml('<tt><body begin="24h"><p begin="1s">Over limit</p></body></tt>', 0)

    def test_malformed_and_unbounded_timing_or_xml_are_rejected(self):
        for value in ('<!DOCTYPE tt [<!ENTITY a "test">]><tt><p>&a;</p></tt>', '<tt><p>Broken',
                      '<tt><body><p begin="10s" end="2s">Wrong end</p></body></tt>'):
            with self.subTest(value=value), self.assertRaises(SourceError):
                parse_ttml(value, 20)
        for value in ('[00:99]Invalid', '[00:40]Wrong recording', '[00:01]x\n' * 2001):
            with self.subTest(value=value[:30]), self.assertRaises(SourceError):
                parse_lrc(value, 20)

    def test_mixed_or_missing_timing_degrades_to_readable_text(self):
        result = parse_lrc('Untimed heading\n[00:01.00]First line', 20)
        self.assertFalse(result['timed'])
        self.assertTrue(all(line['start'] is None for line in result['lines']))


class WordLyricsTests(unittest.TestCase):
    def setUp(self):
        self.document = {"version": "1.0", "metadata": {
            "title": "Synthetic (Live)", "artist": "Test Artist", "duration_ms": 10000},
            "lines": [{"text": "First line", "start_ms": 1000, "end_ms": 4000, "words": [
                {"text": "First ", "start_ms": 1000, "end_ms": 2000},
                {"text": "line", "start_ms": 2000, "end_ms": 3500}]}]}
        self.record = {"trackName": "Synthetic (Live)", "artistName": "Test Artist", "duration": 10,
                       "syncedLyrics": "[00:01]Legacy line", "plainLyrics": "Legacy text"}

    def read(self, document=None, **record):
        value = self.document if document is None else document
        return _lrclib_lines({**self.record, "lyricsfile": value if isinstance(value, str)
                             else yaml.safe_dump(value, allow_unicode=True), **record}, 10)

    def test_lyricsfile_words_are_seconds_and_work_without_legacy_fields_or_hint(self):
        result = self.read(syncedLyrics=None, plainLyrics=None, hasWordSync=True)
        self.assertEqual(result["lines"][0], {"text": "First line", "start": 1, "end": 4,
            "words": [{"text": "First ", "start": 1, "end": 2},
                      {"text": "line", "start": 2, "end": 3.5}]})
        self.assertTrue(result["timed"])
        self.assertEqual(result["source"], "lrclib")
        self.assertIn("words", self.read(hasWordSync=False)["lines"][0])

    def test_unicode_segments_overlap_and_missing_ends_preserve_text_and_line_timing(self):
        self.document["lines"] = [
            {"text": "日本語 & <test>", "start_ms": 1000, "end_ms": 4000, "words": [
                {"text": "日本", "start_ms": 1000, "end_ms": 2500},
                {"text": "語 & <test>", "start_ms": 2000}]},
            {"text": "Other singer", "start_ms": 2000, "end_ms": 5000}]
        lines = self.read()["lines"]
        self.assertEqual([line["end"] for line in lines], [4, 5])
        self.assertEqual(lines[0]["words"][1]["end"], 4)
        self.assertEqual("".join(word["text"] for word in lines[0]["words"]), lines[0]["text"])

    def test_bad_optional_word_data_falls_back_to_the_complete_line(self):
        for change in ({"start_ms": True}, {"start_ms": -1}, {"start_ms": 20000},
                       {"end_ms": 6000}, {"end_ms": 500}, {"text": "Wrong text"},
                       {"start_ms": 2500}):
            document = copy.deepcopy(self.document)
            document["lines"][0]["words"][0].update(change)
            with self.subTest(change=change):
                line = self.read(document)["lines"][0]
                self.assertEqual(line["text"], "First line")
                self.assertNotIn("words", line)
                self.assertEqual((line["start"], line["end"]), (1, 4))

    def test_unknown_versions_identity_duration_offsets_and_invalid_lines_use_legacy(self):
        changes = [({"version": "2.0"}, {}), ({"version": 1}, {}),
                   ({}, {"title": "Synthetic"}), ({}, {"artist": "Wrong artist"}),
                   ({}, {"duration_ms": 13000}), ({}, {"duration_ms": True}),
                   ({}, {"offset_ms": 10}), ({}, {"offset_ms": False})]
        for fields, meta in changes:
            document = copy.deepcopy(self.document)
            document.update(fields)
            document["metadata"].update(meta)
            self.assertEqual(self.read(document)["lines"][0]["text"], "Legacy line")
        for value in (True, -1, "1000", 90000000):
            document = copy.deepcopy(self.document)
            document["lines"][0]["start_ms"] = value
            self.assertEqual(self.read(document)["lines"][0]["text"], "Legacy line")

    def test_yaml_is_bounded_and_rejects_objects_aliases_duplicates_and_extra_documents(self):
        valid = yaml.safe_dump(self.document)
        bad = [valid + "\nversion: '2.0'", valid + "\n---\nversion: '1.0'",
               valid + "\nextra: &a [1, 2]\ncopy: *a", valid + "\nextra: !!python/object/apply:os.system ['false']",
               valid + "\nextra: !!binary SGVsbG8=", valid + "\nextra: " + "[" * 50 + "]" * 50,
               valid + "\nextra: {key: first, key: second}", "x" * 512001, "\x00"]
        for value in bad:
            with self.subTest(value=value[-65:]):
                self.assertEqual(self.read(value)["lines"][0]["text"], "Legacy line")
        self.assertEqual(self.read(valid + "\nextra: [1, true, null, text]")["lines"][0]["text"], "First line")

    def test_plain_lyricsfile_does_not_displace_legacy_timing(self):
        self.document.update(lines=[], plain="Plain words\n\nAnother verse")
        self.assertEqual(self.read()["lines"][0]["text"], "Legacy line")
        result = self.read(syncedLyrics=None, plainLyrics=None)
        self.assertFalse(result["timed"])
        self.assertEqual([line["text"] for line in result["lines"]], ["Plain words", "", "Another verse"])

    def test_optional_word_and_line_limits_do_not_expand_the_display(self):
        self.document["lines"][0]["words"] *= 1001
        self.assertNotIn("words", self.read()["lines"][0])
        self.document["lines"] *= 2001
        self.assertEqual(self.read()["lines"][0]["text"], "Legacy line")

    def test_ttml_nested_relative_spans_and_spaces(self):
        result = parse_ttml('<tt><body begin="10s"><p begin="1s" dur="5s"> '
            '<span><span begin="0s" dur="1s"><span>One</span></span> '
            '<span begin="1s" dur="2s">two</span></span> </p></body></tt>', 20)
        line = result["lines"][0]
        self.assertEqual(line, {"text": "One two", "start": 11, "end": 16,
            "words": [{"text": "One ", "start": 11, "end": 12},
                      {"text": "two", "start": 12, "end": 14}]})

    def test_ttml_incomplete_invalid_or_unordered_spans_keep_readable_lines(self):
        for content in ('Unmarked <span begin="1s">word</span>',
                        '<span begin="1s" end="9s">Outside</span>',
                        '<span begin="2s">Two </span><span begin="1s">one</span>',
                        '<span begin="1s" end="NaN">Unknown end</span>',
                        '<span begin="NaN">Unknown</span>'):
            result = parse_ttml('<tt><p begin="0s" end="5s">' + content + '</p></tt>', 10)
            self.assertTrue(result["timed"])
            self.assertNotIn("words", result["lines"][0])
            self.assertTrue(result["lines"][0]["text"])
        with self.assertRaises(SourceError):
            parse_ttml('<tt><p begin="1s">' + '<span>' * 42 + 'Text' + '</span>' * 42 + '</p></tt>', 10)
        with self.assertRaises(SourceError):
            parse_ttml('<tt><p begin="1s"><span begin="0s">' + '<span>' * 42
                       + 'Text' + '</span>' * 42 + '</span></p></tt>', 10)

    def test_enhanced_lrc_end_marker_and_missing_or_invalid_words(self):
        result = parse_lrc('[00:01]<00:01>First <00:02>line<00:03>', 10)
        self.assertEqual([word["end"] for word in result["lines"][0]["words"]], [2, 3])
        for value in ('[00:01]Prefix <00:02>line', '[00:01]<00:99>Invalid',
                      'Heading\n[00:01]<00:01>Word'):
            self.assertNotIn("words", parse_lrc(value, 10)["lines"][0])


class LyricsIdentityTests(unittest.TestCase):
    def match(self, title, artist, returned_title, returned_artist, duration=200, returned_duration=200):
        return _lrclib_match({"trackName": returned_title, "artistName": returned_artist,
                              "albumName": "Album", "duration": returned_duration},
                             {"title": title, "artist": artist, "length": duration}, "Album")

    def test_release_labels_typography_accents_and_complete_credits_with_duration_guard(self):
        cases = [("Don’t Stop Me Now - Remastered 2011", "Queen", "Don't Stop Me Now"),
                 ("Here Comes The Sun - Remastered 2009", "The Beatles", "Here Comes The Sun"),
                 ("Hotel California - 2013 Remaster", "Eagles", "Hotel California"),
                 ("Uptown Funk (feat. Bruno Mars)", "Mark Ronson", "Uptown Funk"),
                 ("I'm Just A Singer (In A Rock And Roll Band)", "The Moody Blues",
                  "I'm Just A Singer (In A Rock And Roll Band)"),
                 ("Synthetic (2011 Remastered Version)", "Beyoncé", "Synthetic"),
                 ("Synthetic (20th Anniversary Deluxe Edition)", "Beyoncé", "Synthetic"),
                 ("Synthetic [Mono Version]", "Beyoncé", "Synthetic")]
        for title, artist, returned in cases:
            with self.subTest(title=title):
                self.assertTrue(self.match(title, artist, returned, artist))
                self.assertFalse(self.match(title, artist, returned, artist, returned_duration=208.01))
                if title != returned:
                    self.assertFalse(self.match(title, artist, returned, artist, duration=0))
        self.assertTrue(self.match("Don't Stop Me Now - Remastered 2011", "Queen",
                                   "Don’t Stop Me Now (Remastered 2011)", "Queen"))
        for artist in ("Prince; The Revolution", "Prince The Revolution", "Prince and The Revolution"):
            self.assertTrue(self.match("Purple Rain", "Prince & The Revolution", "Purple Rain", artist))
        self.assertTrue(self.match("Héllo!", "The Beyoncé", "Hello", "Beyonce feat. Other Artist"))
        self.assertFalse(self.match("Hello", "Ga", "Hello", "Lady Gaga"))
        self.assertFalse(self.match("Hello", "U2", "Hello", "U2 Tribute"))
        self.assertFalse(self.match("Hello", "U2", "Hello", "U2 & " + 'x' * 1001))

    def test_recording_qualifiers_and_descriptive_parentheses_are_not_stripped(self):
        for qualifier in ("Live", "Acoustic", "Remix", "Demo", "Instrumental", "Live 2011 Remaster"):
            for title in (f"Song ({qualifier})", f"Song - {qualifier}"):
                self.assertFalse(self.match(title, "Artist", "Song", "Artist"))
                self.assertTrue(self.match(title, "Artist", title, "Artist"))
        self.assertEqual(lyrics_title("Singer (In A Rock And Roll Band)"), "Singer (In A Rock And Roll Band)")
        self.assertFalse(self.match("Singer (In A Rock And Roll Band)", "Artist", "Singer", "Artist"))
        self.assertFalse(self.match("Song", "Prince & The Revolution", "Song", "Prince", duration=0))


class UnisonRequestTests(unittest.TestCase):
    def setUp(self):
        self.track = {'title': 'Test Song (Live)', 'artist': 'U2', 'length': 200}
        # GET /lyrics omits duration (unlike /lyrics/search). Synthetic text only.
        self.data = {'success': True, 'data': {'song': 'Test Song (Live)', 'artist': 'U2',
                     'album': 'Test album', 'confidence': 'high', 'effectiveScore': 1,
                     'format': 'lrc', 'hidden': False, 'id': 1, 'language': 'en',
                     'lyrics': '[00:01.00]Synthetic test line', 'score': 1, 'submitter': None,
                     'syncType': 'linesync', 'userVote': None, 'videoId': '', 'voteCount': 1}}

    def fetch(self, data=None, status=200, headers=None, chunks=None):
        response = Mock(status_code=status, headers=headers or {'Content-Type': 'application/json'})
        response.iter_content.return_value = chunks if chunks is not None else [json.dumps(data or self.data).encode()]
        session = Mock(headers={})
        session.get.return_value.__enter__ = Mock(return_value=response)
        session.get.return_value.__exit__ = Mock(return_value=False)
        with patch('tagcast.playback_lyrics.requests.Session') as create:
            create.return_value.__enter__.return_value = session
            result = fetch_unison(self.track, 'Test album')
        self.assertFalse(session.trust_env)
        kwargs = session.get.call_args.kwargs
        self.assertFalse(kwargs['allow_redirects'])
        self.assertEqual(kwargs['params'], {'song': 'Test Song (Live)', 'artist': 'U2',
                                           'album': 'Test album', 'duration': 200})
        self.assertEqual(set(session.headers), {'User-Agent', 'Accept'})
        session.get.assert_called_once()
        return result

    def test_exact_metadata_supported_formats_and_no_credentials(self):
        self.assertTrue(self.fetch()['timed'])
        for fmt, lyrics in (('plain', 'Synthetic plain text'),
                            ('ttml', '<tt><body><p begin="1s" end="3s">Synthetic line</p></body></tt>')):
            result = self.fetch({'success': True, 'data': {**self.data['data'], 'format': fmt, 'lyrics': lyrics}})
            self.assertEqual(result['status'], 'ready')
            self.assertEqual(result['source'], 'unison')

    def test_partial_title_short_artist_and_present_invalid_duration_never_match(self):
        for change in ({'song': 'Test Song'}, {'artist': 'Different artist'}, {'duration': 204},
                       {'duration': None}, {'duration': True}, {'duration': float('nan')}):
            result = self.fetch({'success': True, 'data': {**self.data['data'], **change}})
            self.assertEqual(result['status'], 'missing')

    def test_real_response_shape_without_duration_accepts_the_server_duration_filter(self):
        self.assertNotIn('duration', self.data['data'])
        self.assertEqual(self.fetch()['status'], 'ready')

    def test_cleaned_unison_query_still_validates_identity_and_unknown_duration_album(self):
        self.track.update(title='Test Song (Remastered 2011)')
        response = {**self.data['data'], 'song': 'Test Song'}
        with patch('tagcast.playback_lyrics._ProviderReader.read', return_value={'success': True, 'data': response}) as read:
            self.assertEqual(fetch_unison(self.track, 'Test album')['status'], 'ready')
            self.assertEqual(read.call_args.args[2]['song'], 'Test Song')
            self.track.update(length=0)
            self.assertEqual(fetch_unison(self.track, 'Test album')['status'], 'missing')
            self.track.update(title='Test Song')
            self.assertEqual(fetch_unison(self.track, 'Other album')['status'], 'missing')
            self.assertEqual(fetch_unison(self.track, 'Test album')['status'], 'ready')

    def test_404_is_missing_but_failures_redirects_and_oversize_are_errors(self):
        self.assertEqual(self.fetch(status=404)['status'], 'missing')
        for status in (302, 307, 308, 403, 429, 503):
            with self.subTest(status=status), self.assertRaises(SourceError):
                self.fetch(status=status)
        for data in ({'success': False}, {'success': True, 'data': {}},
                     {'success': True, 'data': {**self.data['data'], 'format': 'unknown'}}):
            with self.assertRaises(SourceError):
                self.fetch(data)
        with self.assertRaises(SourceError):
            self.fetch(chunks=[b'x' * 512001])
        with self.assertRaises(SourceError):
            self.fetch(chunks=[b'{broken'])

    def test_timeout_and_rate_limit_are_distinct_from_a_missing_song(self):
        with patch('tagcast.playback_lyrics.requests.Session') as create:
            create.return_value.__enter__.return_value.get.side_effect = requests.Timeout()
            with self.assertRaises(SourceError):
                fetch_unison(self.track, 'Album')
        with self.assertRaises(SourceError) as raised:
            self.fetch(status=429, headers={'Retry-After': '180'})
        self.assertEqual(raised.exception.retry_after, 180)


class LRCLIBDisplayTests(unittest.TestCase):
    def setUp(self):
        self.track = {'title': 'Test Song (Live)', 'artist': 'U2', 'length': 200}
        self.record = {'id': 1, 'trackName': self.track['title'], 'artistName': 'U2',
                       'albumName': 'Test album', 'duration': 200, 'instrumental': False,
                       'syncedLyrics': '[00:01.00]Synthetic timed line',
                       'plainLyrics': 'Synthetic plain line'}
        self.current = Mock()

    def fetch(self, replies, track=None, album='Test album', current=None):
        self.session = Mock(headers={})
        contexts = []
        for reply in replies:
            if len(reply) == 2:
                status, data = reply
                headers, chunks = {'Content-Type': 'application/json'}, None
            else:
                status, data, headers, chunks = reply
            response = Mock(status_code=status, headers=headers)
            response.iter_content.return_value = chunks if chunks is not None else [json.dumps(data).encode()]
            context = Mock()
            context.__enter__ = Mock(return_value=response)
            context.__exit__ = Mock(return_value=False)
            contexts.append(context)
        self.session.get.side_effect = contexts
        self.clock = 100.
        def sleep(delay):
            self.clock += delay
        with patch('tagcast.playback_lyrics.requests.Session') as create, \
                patch('tagcast.playback_lyrics.time.monotonic', side_effect=lambda: self.clock), \
                patch('tagcast.playback_lyrics.time.sleep', side_effect=sleep):
            create.return_value.__enter__.return_value = self.session
            return fetch_lrclib_display(track or self.track, album, current or self.current)

    def test_database_search_precedes_get_and_uses_no_account_cookies_or_redirects(self):
        result = self.fetch([(200, [self.record])])
        self.assertEqual(result['source'], 'lrclib')
        self.assertTrue(result['timed'])
        self.session.get.assert_called_once()
        args, kwargs = self.session.get.call_args
        self.assertEqual(args, ('https://lrclib.net/api/search',))
        self.assertEqual(kwargs['params'], {'track_name': 'Test Song (Live)', 'artist_name': 'U2'})
        self.assertFalse(kwargs['allow_redirects'])
        self.assertTrue(kwargs['stream'])
        self.assertFalse(self.session.trust_env)
        self.assertEqual(set(self.session.headers), {'User-Agent', 'Accept'})
        self.session.cookies.clear.assert_called_once()
        self.assertGreaterEqual(self.current.call_count, 2)

    def test_exact_get_is_used_only_without_a_usable_database_result(self):
        result = self.fetch([(200, []), (200, self.record)])
        self.assertEqual(result['status'], 'ready')
        urls = [c.args[0] for c in self.session.get.call_args_list]
        self.assertEqual(urls, ['https://lrclib.net/api/search', 'https://lrclib.net/api/get'])
        self.assertEqual(self.session.get.call_args.kwargs['params'], {
            'track_name': 'Test Song (Live)', 'artist_name': 'U2', 'album_name': 'Test album', 'duration': 200})
        self.assertAlmostEqual(self.clock, 100.25)

    def test_word_timing_without_legacy_text_or_extra_requests(self):
        document = {'version': '1.0', 'metadata': {'title': self.track['title'], 'artist': 'U2'},
                    'lines': [{'text': 'Synthetic timing', 'start_ms': 1000, 'end_ms': 4000,
                               'words': [{'text': 'Synthetic ', 'start_ms': 1000, 'end_ms': 2000},
                                         {'text': 'timing', 'start_ms': 2000, 'end_ms': 4000}]}]}
        result = self.fetch([(200, [{**self.record, 'hasWordSync': True,
                                   'lyricsfile': yaml.safe_dump(document),
                                   'plainLyrics': None, 'syncedLyrics': None}])])
        self.assertEqual([w['start'] for w in result['lines'][0]['words']], [1, 2])
        self.session.get.assert_called_once()

    def test_search_ranks_by_duration_then_synced_then_album_and_skips_bad_candidates(self):
        hits = [{**self.record, 'id': 2, 'duration': 199},
                {**self.record, 'id': 3, 'duration': 200.25, 'syncedLyrics': '[00:01]Closest line'},
                {**self.record, 'id': 4, 'duration': 200, 'trackName': 'Test Song'},
                {**self.record, 'id': 5, 'duration': 200, 'artistName': 'U2 Tribute'},
                {**self.record, 'id': 6, 'duration': 206},
                {**self.record, 'id': 7, 'duration': 200, 'syncedLyrics': '[04:00]Past ending'}]
        self.assertEqual(self.fetch([(200, hits)])['lines'][0]['text'], 'Closest line')
        hits = [{**self.record, 'id': 2, 'syncedLyrics': None},
                {**self.record, 'id': 3, 'albumName': 'Other'}, self.record]
        self.assertEqual(self.fetch([(200, hits)])['lines'][0]['text'], 'Synthetic timed line')

    def test_typography_searches_keep_live_identity_and_pick_the_closest_hit(self):
        track = {'title': 'Test Song – Live', 'artist': 'O’Flynn', 'length': 200}
        record = {**self.record, 'trackName': 'Test Song - Live', 'artistName': "O'Flynn"}
        result = self.fetch([(200, [{**record, 'duration': 201}]),
                             (200, [{**record, 'id': 2, 'duration': 200,
                                     'syncedLyrics': '[00:01]Exact duration'}])], track)
        self.assertEqual(result['lines'][0]['text'], 'Exact duration')
        self.assertEqual(self.session.get.call_count, 2)
        self.assertEqual(self.session.get.call_args.kwargs['params'],
                         {'track_name': 'test song - live', 'artist_name': "o'flynn"})

    def test_one_bare_title_primary_artist_search_finds_version_label_variants(self):
        track = {'title': 'Synthetic Song - Remastered 2011', 'artist': 'Prince & The Revolution', 'length': 200}
        record = {**self.record, 'trackName': 'Synthetic Song', 'artistName': 'Prince The Revolution'}
        result = self.fetch([(200, []), (200, [record])], track)
        self.assertEqual(result['status'], 'ready')
        self.assertEqual([call.kwargs['params'] for call in self.session.get.call_args_list], [
            {'track_name': track['title'], 'artist_name': track['artist']},
            {'track_name': 'Synthetic Song', 'artist_name': 'Prince'}])
        self.assertEqual(self.session.get.call_count, 2)

    def test_plain_instrumental_missing_and_empty_candidate_stay_distinct(self):
        result = self.fetch([(200, [{**self.record, 'syncedLyrics': None}])])
        self.assertFalse(result['timed'])
        self.assertEqual(result['lines'][0]['text'], 'Synthetic plain line')
        result = self.fetch([(200, [{**self.record, 'instrumental': True}])])
        self.assertEqual(result['status'], 'instrumental')
        self.assertEqual(result['lines'], [])
        for hits in ([], [{**self.record, 'plainLyrics': '', 'syncedLyrics': ''}]):
            self.assertEqual(self.fetch([(200, hits), (404, {})])['status'], 'missing')

    def test_invalid_or_far_duration_does_not_win_and_unknown_duration_remains_ambiguous(self):
        for duration in (None, True, float('nan'), float('inf'), '200', -1, 209):
            with self.subTest(duration=duration):
                self.assertEqual(self.fetch([(200, [{**self.record, 'duration': duration}]),
                                             (404, {})])['status'], 'missing')
        track = {**self.track, 'length': 0}
        self.assertEqual(self.fetch([(200, [self.record, {**self.record, 'id': 2}])], track)['status'], 'missing')
        self.session.get.assert_called_once()
        self.assertEqual(self.fetch([(200, [self.record])], track)['status'], 'ready')
        self.assertEqual(self.fetch([(200, [self.record]), (404, {})], track, album='Other')['status'], 'missing')

    def test_short_server_delay_retries_once_and_does_not_turn_into_one_minute(self):
        for status in (429, 503):
            result = self.fetch([(status, {}, {'Retry-After': '1'}, None), (200, [self.record])])
            self.assertEqual(result['status'], 'ready')
            self.assertAlmostEqual(self.clock, 101)
            self.assertEqual(self.session.get.call_count, 2)
            self.assertEqual({c.args[0] for c in self.session.get.call_args_list}, {'https://lrclib.net/api/search'})
        # Two overloaded searches still allow a different step, after its requested delay.
        result = self.fetch([(503, {}, {'Retry-After': '1'}, None),
                             (503, {}, {'Retry-After': '1'}, None), (200, self.record)])
        self.assertEqual(result['status'], 'ready')
        self.assertAlmostEqual(self.clock, 102)
        # A healthy search never calls the slow /get endpoint, even when it is overloaded.
        self.fetch([(200, [self.record]), (503, {}, {'Retry-After': '1'}, None)])
        self.session.get.assert_called_once()

    def test_long_retry_after_skips_the_provider_without_shortening_the_server_delay(self):
        with self.assertRaises(SourceError) as raised:
            self.fetch([(429, {}, {'Retry-After': '7200'}, None)])
        self.assertEqual(raised.exception.retry_after, 7200)
        self.session.get.assert_called_once()
        self.assertEqual(self.clock, 100)

    def test_invalid_json_limits_and_redirects_are_not_retried_or_followed(self):
        for reply in [(302, {}), (307, {}), (308, {}),
            (200, {}, {'Content-Type': 'text/html'}, None),
            (200, None, {'Content-Type': 'application/json'}, [b'{broken']),
            (200, None, {'Content-Type': 'application/json'}, [b'null']),
            (200, None, {'Content-Type': 'application/json'}, [b'x' * 512001]),
            (200, {}), (200, [self.record] * 101)]:
            with self.subTest(reply=str(reply)[:50]), self.assertRaises(SourceError):
                self.fetch([reply])
            self.session.get.assert_called_once()

    def test_new_selection_interrupts_sleep_and_prevents_any_next_request(self):
        current = Mock(side_effect=[None, ConflictError('Replaced selection')])
        with self.assertRaises(ConflictError):
            self.fetch([(200, []), (200, self.record)], current=current)
        self.assertLessEqual(self.session.get.call_count, 1)

    def test_timeout_and_outside_get_duration_range(self):
        with patch('tagcast.playback_lyrics.requests.Session') as create:
            create.return_value.__enter__.return_value.get.side_effect = requests.Timeout()
            with self.assertRaises(SourceError):
                fetch_lrclib_display(self.track, 'Test album', self.current)
        self.fetch([(200, []), (404, {})], {**self.track, 'length': 4000})
        self.assertNotIn('duration', self.session.get.call_args.kwargs['params'])


class PlaybackLyricsIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.fixture = test_lyrics.LyricsTests()
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.service = self.fixture.service.display
        self.body = {**self.fixture.body, 'enabled': True}
        self.result = parse_lrc('[00:01.00]Synthetic line', 200)

    def test_consent_and_fresh_account_track_identity_precede_any_network(self):
        with patch('tagcast.playback_lyrics.fetch_unison') as fetch:
            for change in ({'enabled': False}, {'enabled': 'true'}, {'session': 'old'}, {'title': 'Wrong'}):
                with self.subTest(change=change), self.assertRaises((LibraryError, ConflictError)):
                    self.service.view({**self.body, **change})
            fetch.assert_not_called()
        self.fixture.studio.client._jsonrequest.assert_not_called()

    def test_results_and_missing_responses_are_ram_only_and_never_call_ibroadcast(self):
        for result in (self.result, parse_lrc('', 200)):
            self.service.cache.clear()
            with patch('tagcast.playback_lyrics.fetch_unison', return_value=result) as fetch:
                self.assertEqual(self.service.view(self.body), result)
                self.assertEqual(self.service.view(self.body), result)
                fetch.assert_called_once()
        self.assertEqual(list(self.fixture.studio.home.iterdir()), [])
        self.fixture.studio.client._jsonrequest.assert_not_called()
        self.assertFalse(self.fixture.service.reviews)

    def test_replaced_session_discards_late_lyrics(self):
        def replace(*args):
            self.fixture.studio.playback_session = 'new-session'
            return self.result
        with patch('tagcast.playback_lyrics.fetch_unison', side_effect=replace):
            with self.assertRaises(ConflictError):
                self.service.view(self.body)
        self.assertFalse(self.service.cache)

    def test_error_backoff_and_retry_after_prevent_repeated_external_requests(self):
        error = SourceError('Unavailable')
        error.retry_after = 180
        with patch('tagcast.playback_lyrics.time.monotonic', return_value=100), \
                patch('tagcast.playback_lyrics.fetch_unison', side_effect=error) as fetch:
            for _ in range(2):
                self.assertEqual(self.service.view(self.body)['status'], 'unavailable')
            fetch.assert_called_once()
        self.assertEqual(self.service.backoff["unison"], 280)

    def test_library_replacement_does_not_reuse_previous_cache(self):
        with patch('tagcast.playback_lyrics.fetch_unison', return_value=self.result) as fetch:
            self.service.view(self.body)
            self.fixture.studio.library = copy.copy(self.fixture.studio.library)
            self.service.view(self.body)
            self.assertEqual(fetch.call_count, 2)

    def test_lrclib_is_only_a_consented_missing_result_fallback(self):
        missing = parse_lrc('', 200)
        public = {**self.result, 'source': 'lrclib'}
        for consent, disabled, status in ((False, False, 'missing'), (True, True, 'missing'),
                                           (True, False, 'ready')):
            self.service.cache.clear()
            self.fixture.disabled[:] = ['lrclib'] if disabled else []
            with patch('tagcast.playback_lyrics.fetch_unison', return_value=missing), \
                    patch('tagcast.playback_lyrics.fetch_lrclib_display', return_value=public) as fetch:
                result = self.service.view({**self.body, 'fallback_lrclib': consent})
                self.assertEqual(result['status'], status)
                self.assertEqual(fetch.call_count, int(consent and not disabled))
        self.fixture.studio.client._jsonrequest.assert_not_called()
        self.assertEqual(list(self.fixture.studio.home.iterdir()), [])
        self.assertFalse(self.fixture.service.reviews)

    def test_unison_hit_keeps_priority_but_errors_and_backoff_allow_lrclib(self):
        public = {**self.result, 'source': 'lrclib'}
        with patch('tagcast.playback_lyrics.fetch_lrclib_display', return_value=public) as fallback:
            with patch('tagcast.playback_lyrics.fetch_unison', return_value=self.result):
                self.service.view({**self.body, 'fallback_lrclib': True})
            fallback.assert_not_called()
            self.service.cache.clear()
            with patch('tagcast.playback_lyrics.fetch_unison', side_effect=SourceError('Offline')) as unison:
                self.assertEqual(self.service.view({**self.body, 'fallback_lrclib': True}), public)
                self.service.cache.clear()
                self.assertEqual(self.service.view({**self.body, 'fallback_lrclib': True}), public)
                unison.assert_called_once()
            self.assertEqual(fallback.call_count, 2)

    def test_unavailable_is_not_cached_and_other_provider_backoff_does_not_block_unison(self):
        self.service.backoff['lrclib'] = float('inf')
        with patch('tagcast.playback_lyrics.fetch_unison', return_value=self.result):
            self.assertEqual(self.service.view({**self.body, 'fallback_lrclib': True}), self.result)
        self.service.cache.clear()
        with patch('tagcast.playback_lyrics.fetch_unison', side_effect=SourceError('Offline')):
            self.assertEqual(self.service.view({**self.body, 'fallback_lrclib': True})['status'], 'unavailable')
        self.assertFalse(self.service.cache)
        self.assertIsNone(self.service.active)

    def test_three_quick_track_selections_do_not_queue_behind_old_network_work(self):
        entered, release = threading.Event(), threading.Event()
        bodies = []
        for key in sorted(self.fixture.studio.library.tracks.rows)[:3]:
            track = self.fixture.studio.library.track_view(key)
            bodies.append({**self.body, 'track_id': str(key), 'title': track['title'], 'artist': track['artist']})
        failures = []
        def fetch(track, album, current, policy):
            if track['title'] == bodies[0]['title']:
                entered.set()
                self.assertTrue(release.wait(3))
                current()  # Must be cancelled before another provider request.
            return self.result
        def first():
            try:
                self.service.view(bodies[0])
            except ConflictError:
                failures.append('superseded')
        with patch('tagcast.playback_lyrics.fetch_unison', side_effect=fetch), ThreadPoolExecutor(2) as pool:
            previous = pool.submit(first)
            self.assertTrue(entered.wait(1))
            try:
                for body in bodies[1:]:
                    self.assertEqual(pool.submit(self.service.view, body).result(timeout=1), self.result)
            finally:
                release.set()
            previous.result(timeout=1)
        self.assertEqual(failures, ['superseded'])
        self.assertEqual(len(self.service.cache), 2)
        self.assertIsNone(self.service.active)

    def test_same_track_inflight_requests_share_one_fetch(self):
        entered, release = threading.Event(), threading.Event()
        def fetch(*args):
            entered.set()
            self.assertTrue(release.wait(3))
            return self.result
        with patch('tagcast.playback_lyrics.fetch_unison', side_effect=fetch) as mock, ThreadPoolExecutor(2) as pool:
            first = pool.submit(self.service.view, self.body)
            self.assertTrue(entered.wait(1))
            second = pool.submit(self.service.view, self.body)
            release.set()
            self.assertEqual(first.result(timeout=1), self.result)
            self.assertEqual(second.result(timeout=1), self.result)
            mock.assert_called_once()
        self.assertIsNone(self.service.active)

    def test_disabled_lrclib_cannot_reuse_a_previous_online_result(self):
        body = {**self.body, 'fallback_lrclib': True}
        with patch('tagcast.playback_lyrics.fetch_unison', return_value=parse_lrc('', 200)) as unison, \
                patch('tagcast.playback_lyrics.fetch_lrclib_display',
                      return_value={**self.result, 'source': 'lrclib'}) as fetch:
            self.assertEqual(self.service.view(body)['source'], 'lrclib')
            self.assertEqual(self.service.view(body)['source'], 'lrclib')
            self.assertEqual(unison.call_count, 1)
            self.fixture.disabled.append('lrclib')
            self.assertEqual(self.service.view(body)['status'], 'missing')
            fetch.assert_called_once()

    def test_session_replacement_blocks_the_fallback_before_any_lrclib_request(self):
        def replace(*args):
            self.fixture.studio.playback_session = 'new-session'
            return parse_lrc('', 200)
        with patch('tagcast.playback_lyrics.fetch_unison', side_effect=replace), \
                patch('tagcast.playback_lyrics.requests.Session') as session:
            with self.assertRaises(ConflictError):
                self.service.view({**self.body, 'fallback_lrclib': True})
            session.return_value.__enter__.return_value.get.assert_not_called()
        self.assertFalse(self.service.cache)

    def test_invalid_fallback_consent_is_rejected_before_lookup(self):
        with patch('tagcast.playback_lyrics.fetch_unison') as fetch:
            with self.assertRaises(LibraryError):
                self.service.view({**self.body, 'fallback_lrclib': 'true'})
            fetch.assert_not_called()

    def test_disabling_source_while_fallback_finishes_rejects_the_late_result(self):
        def disable(*args):
            self.fixture.disabled.append('lrclib')
            return {**self.result, 'source': 'lrclib'}
        with patch('tagcast.playback_lyrics.fetch_unison', return_value=parse_lrc('', 200)), \
                patch('tagcast.playback_lyrics.fetch_lrclib_display', side_effect=disable):
            with self.assertRaises(ConflictError):
                self.service.view({**self.body, 'fallback_lrclib': True})
        self.assertFalse(self.service.cache)


class ForkV78LyricsTests(unittest.TestCase):
    """Fork v78: friendlier matching, and the GD Studio fallback for Chinese songs."""

    def match(self, title, artist, returned_title, returned_artist, duration=200, returned_duration=200):
        return _lrclib_match({"trackName": returned_title, "artistName": returned_artist,
                              "albumName": "Album", "duration": returned_duration},
                             {"title": title, "artist": artist, "length": duration}, "Album")

    def test_artist_prefix_clean_dirty_slang_and_a_few_seconds_still_match(self):
        from tagcast.playback_lyrics import lyrics_strip_artist
        self.assertEqual(lyrics_strip_artist("50 Cent - In Da Club", "50 Cent"), "In Da Club")
        self.assertEqual(lyrics_strip_artist("Intro - Outro", "50 Cent"), "Intro - Outro")
        self.assertTrue(self.match("50 Cent - In Da Club (Dirty)", "50 Cent", "In Da Club", "50 Cent"))
        self.assertTrue(self.match("In Da Club", "50 Cent", "In The Club", "50 Cent"))
        self.assertTrue(self.match("Candy Shop [Explicit]", "50 Cent", "Candy Shop", "50 Cent", returned_duration=205))
        self.assertFalse(self.match("In Da Club", "50 Cent", "In Da Club", "Someone Else"))
        self.assertFalse(self.match("In Da Club", "50 Cent", "Wanksta", "50 Cent"))
        self.assertFalse(self.match("In Da Club", "50 Cent", "In Da Club", "50 Cent", returned_duration=215))
        self.assertFalse(self.match("In Da Club (Live)", "50 Cent", "In Da Club", "50 Cent"))

    def test_credit_lines_are_removed_from_chinese_lrc(self):
        from tagcast.playback_lyrics import gdstudio_clean_lrc
        text = "[00:00.00] 作词 : 何启弘\n[00:01.00] 作曲 : 殷文琦\n[00:04.00]\n[00:36.125]前尘往事成云烟\n[04:15.303]\n[04:57.09] 吉他 : 江建民\n[05:01.63] SP : PolyGram"
        self.assertEqual(gdstudio_clean_lrc(text), "[00:36.125]前尘往事成云烟")

    def fetch(self, replies, track):
        from tagcast.playback_lyrics import fetch_gdstudio_lyrics
        session = Mock(headers={})
        calls = []

        def get(url, params=None, **kwargs):
            reply = replies(params)
            response = Mock(status_code=200, headers={"Content-Type": "text/html; charset=utf-8"})
            response.iter_content.return_value = [json.dumps(reply).encode()]
            context = Mock()
            context.__enter__ = Mock(return_value=response)
            context.__exit__ = Mock(return_value=False)
            calls.append(params)
            return context
        session.get.side_effect = get
        with patch("tagcast.playback_lyrics.requests.Session") as create:
            create.return_value.__enter__.return_value = session
            result = fetch_gdstudio_lyrics(track, "Album")
        return result, calls

    def test_gdstudio_needs_the_same_title_and_artist_and_a_length_that_fits(self):
        lrc = "[00:00.00] 作词 : A\n[00:36.1]前尘往事成云烟\n[02:10.5]消散在彼此眼前\n[04:57.09] 吉他 : B"
        hits = [{"id": "1", "name": "别的歌", "artist": ["张学友"], "lyric_id": "1"},
                {"id": "2", "name": "吻别", "artist": ["别人"], "lyric_id": "2"},
                {"id": "3", "name": "吻别", "artist": ["张学友"], "lyric_id": "3"}]

        def replies(params):
            return hits if params["types"] == "search" else {"lyric": lrc, "tlyric": ""}
        result, calls = self.fetch(replies, {"title": "吻別", "artist": "張學友", "length": 260})
        self.assertEqual((result["status"], result["source"], len(result["lines"])), ("ready", "gdstudio", 2))
        self.assertEqual([c["id"] for c in calls if c["types"] == "lyric"], ["3"])
        # A recording far shorter than the lyric's own timing is a different cut: no match.
        result, _ = self.fetch(replies, {"title": "吻别", "artist": "张学友", "length": 100})
        self.assertEqual(result["status"], "missing")
        # Nothing with the right artist: missing, and no lyric is requested.
        result, calls = self.fetch(lambda params: hits[:2], {"title": "吻别", "artist": "张学友", "length": 260})
        self.assertEqual(result["status"], "missing")
        self.assertFalse([c for c in calls if c["types"] == "lyric"])


class ForkV80StreamSessionTests(unittest.TestCase):
    def test_the_stream_connection_is_reused_inside_a_thread_and_not_shared_across_threads(self):
        import threading
        from tagcast.client import _stream_session
        first = _stream_session()
        self.assertIs(first, _stream_session())
        other = []
        thread = threading.Thread(target=lambda: other.append(_stream_session()))
        thread.start(); thread.join()
        self.assertIsNot(first, other[0])


class GdStudioTranslationTests(unittest.TestCase):
    def test_translated_lines_are_matched_by_start_time(self):
        result = playback_lyrics.parse_lrc("[00:10.00]你好\n[00:20.00]世界\n[00:30.00]再见", 100, "gdstudio")
        playback_lyrics.gdstudio_translation(result, "[00:10.30]Hello\n[00:20.00]世界\n[00:55.00]Far away")
        self.assertEqual([line.get("tr") for line in result["lines"]], ["Hello", None, None])

    def test_bad_or_missing_translation_is_ignored(self):
        for raw in (None, "", "no timing here", "[99:99.99]x", 5):
            result = playback_lyrics.parse_lrc("[00:10.00]a\n[00:20.00]b", 100, "gdstudio")
            playback_lyrics.gdstudio_translation(result, raw)
            self.assertTrue(all("tr" not in line for line in result["lines"]))
