"""A release must not carry a different page, package or lockfile version."""

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tools"))
from release_info import main, release_info, wait_for_native_builds  # noqa: E402


class ReleaseInfoTests(unittest.TestCase):
    def test_publication_waits_for_native_build_success(self):
        def response(status, conclusion):
            return json.dumps({"workflow_runs": [{"id": 1, "head_sha": "abc",
                "event": "push", "status": status, "conclusion": conclusion,
                "html_url": "https://github.com/example/build"}]})
        with patch.dict(os.environ, {"GH_REPO": "cyberdeliaAI/tagcast"}), patch("release_info.subprocess.check_output", side_effect=[response("in_progress", None), response("completed", "success")]), patch("release_info.time.sleep") as wait:
            wait_for_native_builds("abc")
        wait.assert_called_once_with(15)

    def test_native_failure_blocks_publication(self):
        response = json.dumps({"workflow_runs": [{"id": 1, "head_sha": "abc",
            "event": "push", "status": "completed", "conclusion": "failure",
            "html_url": "https://github.com/example/build"}]})
        with patch.dict(os.environ, {"GH_REPO": "cyberdeliaAI/tagcast"}), patch("release_info.subprocess.check_output", return_value=response):
            with self.assertRaisesRegex(RuntimeError, "Native builds failed"):
                wait_for_native_builds("abc")

    def fixture(self, version="0.10.1", display="0.10.1"):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        root = Path(directory.name)
        (root / "src/tagcast/static").mkdir(parents=True)
        (root / "pyproject.toml").write_text(f'[project]\nversion = "{version}"\n')
        (root / "src/tagcast/__init__.py").write_text(f'__version__ = "{version}"\n')
        (root / "src/tagcast/static/index.html").write_text(f'<span class="pill">{display}</span>')
        (root / "uv.lock").write_text(f'[[package]]\nname = "tagcast"\nversion = "{version}"\n')
        return root

    def test_stable_and_existing_beta_conventions(self):
        stable = release_info(self.fixture())
        self.assertEqual((stable["tag"], stable["prerelease"]), ("v0.10.1", False))
        beta = release_info(self.fixture("0.9.0b2", "0.9.0 beta 2"))
        self.assertEqual((beta["tag"], beta["notes"], beta["prerelease"]),
                         ("v0.9.0-beta.2", ".github/release-notes/0.9.0-beta.2.md", True))

    def test_mismatched_versions_block_release_preparation(self):
        for name in ("src/tagcast/__init__.py", "src/tagcast/static/index.html", "uv.lock"):
            with self.subTest(name=name):
                root = self.fixture()
                path = root / name
                path.write_text(path.read_text().replace("0.10.1", "0.10.0"))
                with self.assertRaises(ValueError):
                    release_info(root)

    def test_electron_versions_follow_the_same_stable_and_beta_versions(self):
        for version, display, npm_version in (("0.10.1", "0.10.1", "0.10.1"),
                                               ("0.10.1b2", "0.10.1 beta 2", "0.10.1-beta.2")):
            root = self.fixture(version, display)
            (root / "electron").mkdir()
            package = root / "electron/package.json"
            lock = root / "electron/package-lock.json"
            package.write_text(json.dumps({"version": npm_version}))
            lock.write_text(json.dumps({"version": npm_version, "packages": {"": {"version": npm_version}}}))
            self.assertEqual(release_info(root)["version"], version)
            package.write_text('{"version":"0.1.0"}')
            with self.assertRaisesRegex(ValueError, "electron/package.json"):
                release_info(root)
            package.write_text(json.dumps({"version": npm_version}))
            lock.write_text(json.dumps({"version": "0.1.0", "packages": {"": {"version": npm_version}}}))
            with self.assertRaisesRegex(ValueError, "electron/package-lock.json"):
                release_info(root)

    def test_publication_rejects_wrong_branch_or_commit_without_calling_github(self):
        info = release_info(self.fixture())
        for branch, message in (("refs/heads/other", "Publish Tagcast 0.10.1"),
                                ("refs/heads/main", "Publish Tagcast 0.10.0")):
            with self.subTest(branch=branch, message=message), patch("release_info.release_info", return_value=info), patch.object(sys, "argv", ["release_info.py", "--publish"]), patch.dict(os.environ, {"GITHUB_EVENT_NAME": "push", "GITHUB_REF": branch, "GITHUB_SHA": "abc"}), patch("release_info.subprocess.check_output", return_value=message), patch("release_info.subprocess.run") as github:
                with self.assertRaises(ValueError):
                    main()
                github.assert_not_called()
